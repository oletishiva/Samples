package steps;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyFeatureStepdefs {
	
	@Before
    public void beforeScenario(Scenario scenario) {
        if (scenario.getName().equals("My First Scenario")) {
            Reporter.assignAuthor("Vimalraj");
        }
    }
	
	@Given("^I have  (\\d+) cukes in my bellies$")
	public void i_have_cukes_in_my_belly(int arg1) throws Throwable {
		Reporter.addStepLog("My test addStepLog message");
        Reporter.addScenarioLog("This is scenario log");
	   
	}

	@Then("^I print$")
	public void i_print() throws Throwable {
	    
	}

	@Given("^I have (\\d+) cukes in my bellies$")
	public void i_have_cukes_in_my_bellies(int arg1) throws Throwable {
		System.out.format("Cukes: %n\n", arg1);
	   
	}

	@When("^I login with credentials$")
	public void i_login_with_credentials(DataTable arg1) throws Throwable {
	   
	}

}
