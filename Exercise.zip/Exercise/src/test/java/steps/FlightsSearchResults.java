package steps;

import com.clearTrip.pages.actions.FlightSearchResultsPageActions;

import cucumber.api.java.en.Then;

public class FlightsSearchResults {
	
	FlightSearchResultsPageActions searchActions=new FlightSearchResultsPageActions();
	
	@Then("^I wait For Results to Apper on the Screen$")
	public void i_wait_For_Results_to_Apper_on_the_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^I read (\\d+) rowData$")
	public void i_read_rowData(int row) throws Throwable {
	   
		searchActions.getRowDetails(row);
	}

}
