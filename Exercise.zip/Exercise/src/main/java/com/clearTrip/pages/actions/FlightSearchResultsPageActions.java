package com.clearTrip.pages.actions;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.clearTrip.pages.locators.FlightSearchResultsPageLocators;
import com.clearTrip.pages.locators.FlightsSearchPageLocators;
import com.clearTrip.utils.SeleniumDriver;

public class FlightSearchResultsPageActions {
	
	FlightSearchResultsPageLocators flightSearchResultsPageLoc=null;
	
	public  FlightSearchResultsPageActions()
	{
		flightSearchResultsPageLoc=new FlightSearchResultsPageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), flightSearchResultsPageLoc);
	}
	
	public void getRowDetails(int row) throws Throwable
	{
		if(flightSearchResultsPageLoc.SearchResults_FromFlightsListView.isDisplayed())
			System.out.println("found");
		else
			System.out.println("not found");
		WebElement element=flightSearchResultsPageLoc.SearchResults_FromFlightsListView.findElement(By.xpath("li["+row+"]"));
		List<String>rowData=getWebTableHeaderData(element);
	}
	
	
	public java.util.List<String> getWebTableHeaderData(WebElement element) throws Throwable {
        //thdata=table header data
        //WebElement tableRow = SeleniumDriver.getDriver().findElement(by);
        java.util.List<String> tableHeaderData = new ArrayList<String>();
        List<WebElement> colData = element.findElements(By.tagName("th"));
        System.out.println("table column size:" + colData.size());
        for (int i = 0; i < colData.size(); i++) {
            String str = colData.get(i).getText();
            System.out.println(colData.get(i).getAttribute("class")+":" + str);
            tableHeaderData.add(str);
        }

        return tableHeaderData;

    }

}
