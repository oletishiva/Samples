package com.clearTrip.pages.locators;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.clearTrip.utils.SeleniumDriver;

public class FlightSearchResultsPageLocators {
	
	@FindBy(xpath="//div[@class='colZero leg col12']//ul[@class='listView flights']")
	public WebElement SearchResults_FromFlightsListView;
	
	
	
	

}
