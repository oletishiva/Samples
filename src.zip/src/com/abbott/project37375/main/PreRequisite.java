package com.abbott.project37375.main;

import org.junit.Test;


public class PreRequisite extends BaseHelper {
	
	@Test
	public void runPrerequisite(){
	

		setStepID("App installed and launched. File Name: "+getapkFileName()+" & "+"Application Version: ");
		createPropertyFiles();
		changeLanguageAndRegioninDevice(client);
		install(client);	
		launch(client);
		capturescreenshot(client, getStepID()+ getAppversion(), true);
	}

}
