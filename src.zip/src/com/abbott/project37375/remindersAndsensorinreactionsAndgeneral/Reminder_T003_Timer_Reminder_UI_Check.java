package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;


public class Reminder_T003_Timer_Reminder_UI_Check extends TestReminderHelper {
	@Test
	public void test_T003_Timer_Reminder_UI_Check() throws Exception {
		
		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		currentSystemTime(client);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "reminders");
		if (!client.isElementFound("NATIVE",
				"xpath=//*[contains(@text,'No active reminders.') and @hidden='false']",
				0)) {
			startUp(client);
			navigateToScreen(client, "reminders");
		}

		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS920_SDAISRS1156
		 * @Expected Scan Sensor reminder displays a Toggle button to enable
		 *           & disable the timer reminder.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step1);
		selectingSASMode(client, "MOCK_1");
		navigateToScreen(client, "reminders");
		verifyRemindersScanSensor(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS920_SDAISRS1156
		 * @Expected Scan Sensor reminder displays a Toggle button
		 *           which is in enable state
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step2);
		enableORdisableScanSensor(client,false);
		setHourAndscanSensorTimerReminder(client, "1 hr");
		verifyScanSensorStatus(client, true,"59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1184
		 * @Expected Scan Sensor reminder displays a Toggle button which
		 *           is in disabled state and countdown timer is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step3);
		enableORdisableScanSensor(client,false);
		verifyScanSensorStatus(client, false,"59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS920
		 * @Expected Scan Sensor reminder displays a Toggle button which
		 *           is in enabled state and countdown timer is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step4);
		enableORdisableScanSensor(client,true);
		verifyScanSensorStatus(client, true,"59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS922
		 * @Expected Hours displayed from 1hr to 12 hrs with the interval 1 during 24 hr time format
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step5);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		clickScanSensorandVerifyHours(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS922
		 * @Expected Hours displayed from 1hr to 12 hrs with the interval 1 during 12 hr time format
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step6);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "reminders");
		clickScanSensorandVerifyHours(client);
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS922_SDAIUIRS923
		 * @Expected Scan Sensor reminder displays a Toggle button which
		 *           is in enabled state and countdown timer is displayed as blank
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step7);
		setHourAndscanSensorTimerReminder(client, "12 hrs");
		advanceTime(client, 11, 59);
		moveApptoBackground(client);
		verifyScanSensorNotification(client, false);
		reLaunch(client);
		verifyScanSensorStatus(client, true,"--:--");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS922_SDAIUIRS923
		 * @Expected Scan Sensor reminder displays a Toggle button which
		 *           is in enabled state and countdown timer is displayed as blank
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step8);
		currentSystemTime(client);
		setHourAndscanSensorTimerReminder(client, "12 hrs");
		advanceTime(client, 11, 59);
		reLaunch(client);
		verifyTimerExpired(client, "Timer Expired");
		navigateToScreen(client, "reminders");
	 //TODO
		//verifyScanSensorNotificationDialog(client,true);
		verifyScanSensorStatus(client, true,"--:--");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS922_SDAIUIRS923
		 * @Expected Scan Sensor reminder displays a countdown timer
		 *           which starts from 11:59:XX
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step9);
		currentSystemTime(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		scanMockWithBGTypeAndVerifyDeaultReminder(client, "Realtime", true, "11:59:");
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "reminders");
		verifyScanSensorStatus(client, true,"11:59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS922_SDAIUIRS923
		 * @Expected Scan Sensor reminder displayed a countdown timer
		 *           which starts from 5:5X:XX
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step10);
		advanceTime(client, 6, 0);
		launch(client);
		navigateToScreen(client, "home");
		navigateToScreen(client, "reminders");
		verifyScanSensorStatus(client, true,"5:58:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS922_SDAISRS1156_SDAIUIRS923
		 * @Expected Scan Sensor reminder displays a countdown timer
		 *           which starts from 11:59:XX
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step11);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		scanMockWithBGTypeAndVerifyDeaultReminder(client, "Historic", true,"11:59:");
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "reminders");
		verifyScanSensorStatus(client, true,"11:59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS922_SDAIUIRS923
		 * @Expected Scan Sensor reminder displays a Toggle button which
		 *           is in disabled state and countdown timer is not displayed as blank
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step12);
		enableORdisableScanSensor(client,false);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		scanMockWithBGTypeAndVerifyDeaultReminder(client, "Historic", false,null);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "reminders");
		verifyScanSensorStatus(client, false,"11:58:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS922,SDAIUIRS923
		 * @Expected Scan Sensor TIMERS reminder displayed a Toggle button which
		 *           is in enabled state and countdown timer is also displayed
		 *           as blank
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step13);
		enableORdisableScanSensor(client,true);
		currentSystemTime(client);
		setHourAndscanSensorTimerReminder(client, "1 hr");
		advanceTime(client, 0, 59);
		launch(client);
		navigateToScreen(client, "reminders");
		//TODO
		//verifyScanSensorNotificationDialog(client,true);
		verifyScanSensorStatus(client, true,"--:--");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1256
		 * @Expected Default Timer Reminder setting resets the Scan Sensor reminder for 1hr for Next Reminder. 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC003_Timer_Reminder_UI_Check_Step14);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		scanMockWithBGTypeAndVerifyDeaultReminder(client, "Realtime", true,"59:");
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "reminders");
		verifyScanSensorStatus(client, true,"59:");
		capturescreenshot(client, getStepID(), true);
				
		/**
		 * @Expected Clean up Process
		 * 
		 */
		
		currentSystemTime(client);
		launch(client);

	}

	

}
