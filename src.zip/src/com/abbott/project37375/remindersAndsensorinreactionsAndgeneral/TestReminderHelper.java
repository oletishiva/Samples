package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.junit.Assert;

import com.abbott.project37375.main.BaseHelper;
import com.abbott.project37375.main.LibrelinkConstants;
import com.experitest.client.Client;


public class TestReminderHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to get the current hours
	 *	 
	 * @return hrs
	 * 		hrs is returned     
	 */
	public int getCurrentHours() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH");
		String formattedDate = dateFormat.format(new Date()).toString();
		int hrs = Integer.parseInt(formattedDate);
		return hrs;
	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 * 
	 * Method to wait for the notifications
	 *
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 */
	public void waitForNotification(Client client) {
		
		client.waitForElement("NATIVE", "xpath=//*[@contentDescription='Alarm Expired']", 0, 160000);
		
	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to wait for the notification dialog
	 *
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 */
	//TODO
	public void waitForNotificationDialog(Client client) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Reminder' and ../parent::*[@class='LibreLink.LLCustomDialog']]", 0, 240000);
	
	}
	
	/**
	 * Author: ShabinaSherif   
	 * 
	 * Method to get the current minutes
	 *
	 * @return mins
	 * 		Mins is returned
	 */
	public int getCurrentMinutes() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("mm");
		String formattedDate = dateFormat.format(new Date()).toString();
		int mins = Integer.parseInt(formattedDate);
		return mins;
	}


	/**
	 * Author: ShabinaSherif/Ilangovan
	 * 
	 * Method to verify the repeating options status
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param isChecked
	 *        true/false
	 */
	public void verifyRepeatingOptions(Client client, boolean isChecked) {
       	     
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatAll' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatMon' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatTues' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatWed' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatThur' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatFri' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@id='alarmRepeatSat' and @checked='" + isChecked+ "']", 0);
		client.verifyElementFound("NATIVE",	"xpath=//*[@id='alarmRepeatSun' and @checked='" + isChecked+ "']", 0);
       	
		
		
	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 * 
	 * Method to verify Repeating Options are visible or not
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param isNotVisible
	 *        true/false
	 */
	public void verifyRepeatingOptionsNotVisible(Client client, boolean isNotVisible) {
		String daysArray[] = new String[] { "All", "Monday","Tuesday", "Wednesday","Thursday","Friday","Saturday","Sunday" };

		for (int i=0;i<daysArray.length;i++){
			client.verifyElementNotFound("NATIVE", "xpath=//*[@top='false' and @parentHidden='"+isNotVisible+"' and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0);
		}
	}

	/**
	 * Author: ShabinaSherif /Ilangovan
	 * 
	 * Method to verify Reminders Page UI
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyRemindersPage(Client client) {
		client.verifyElementFound("NATIVE", "text=Reminders", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'No active reminders.') and @hidden='false']", 0);
		client.verifyElementFound("NATIVE", "text=Scan Sensor", 0);
		client.verifyElementFound("NATIVE", "text=Timers", 0);
		//TODO
		//client.verifyElementFound("NATIVE", "text=Reminders", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='android.support.v7.widget.AppCompatImageView' and ./following-sibling::*[@text='Timers']]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='false']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Add Reminder']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='android.support.v7.widget.AppCompatImageView' and ./preceding-sibling::*[@text='--:--']]", 0);
	}

	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to click the add reminder button
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void clickAddReminder(Client client) {
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Add Reminder' and @enabled='true']", 0);
		waitFor(client,1);
		client.click("NATIVE", "xpath=//*[@text='Add Reminder' and @enabled='true']", 0, 1);
		
			
	}


	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to verify the default Reminder
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyDefaultReminder(Client client) {
		clickAddReminder(client);
		client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmName' and @text='My Reminder' and @focused='true']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@text='Repeating' and @checked='false']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Cancel' and @onScreen='true']",0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Done' and @enabled='true']",0);
		
	}
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to add the reminder for a given time
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param name
	 *        send the name for reminder
	 * @param hrs
	 *        set the hours
	 * @param mins
	 *        set the minutes
	 *            
	 */
	public void addReminderandSetAlarm(Client client, String name,int hrs, int mins,String ampm) {
		clickAddReminder(client);
		enterReminderName(client,name);
		reminderSetTime(client, hrs, mins,ampm);
		

	}



	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to enter Reminder Name
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          Name to be entered
	 *            
	 */
	public void enterReminderName(Client client, String name) {
		if (client.isElementFound("NATIVE", "xpath=//*[@hint='Reminder Name']")) {
			client.elementSendText("NATIVE", "xpath=//*[@hint='Reminder Name']", 0, name);
			client.closeKeyboard();
		}
	}

	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to select the repeating option
	 * 
	 * @param client
	 *			Integrate SeeTestAutomation 
	 * @param dayName
	 *          dayName to be select/unselect
	 * @param check
	 *            true/false
	 * 
	 */
	public void selectRepeatingOption(Client client, String day, boolean isChecked) {
			
		if(client.isElementFound("NATIVE", "xpath=//*[@text='"+day+"']")){
			client.click("NATIVE", "xpath=//*[@text='"+day+"']", 0, 1);
		 
		}
		else{
			client.verifyElementFound("NATIVE", "xpath=//*[@text='" + day+ "' and @checked='" + isChecked + "']", 0);
		}
			
			
		}

		

	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to verify whether specific repeating option is checked/unchecked
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param dayName
	 *          dayName status to be checked
	 * @param check
	 *            true/false
	 *            
	 */
	public void verifySingleRepeatingOption(Client client, String dayName, boolean check) {
		client.verifyElementFound("NATIVE","xpath=//*[@text='"+dayName+"'  and @checked='" + check+ "']", 0);
		
	}
		

	/**
	 * Author: ShabinaSherif/Ilangovan
	 *            
	 * Method to select/unselect the repeating option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param enable
	 *          true/false
	 *            
	 */
	public void clickRepeatingOption(Client client,boolean disable) {
		if (client.isElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='false']", 0)) {
			client.click("NATIVE", "xpath=//*[@id='alarmRepeatSwitch']", 0, 1);
			client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='true']", 0);
			client.sleep(1000);
			client.closeKeyboard();
		}
		else{	
			client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='true']", 0);
		}
		
	}
	/**
	 * Author: Ilangovan
	 *            
	 * Method to select/unselect the repeating option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param enable
	 *          true/false
	 *            
	 */
	
	public void clickRepeatingOptiondisable(Client client) {
		if (client.isElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='true']", 0)) {
			client.click("NATIVE", "xpath=//*[@id='alarmRepeatSwitch']", 0, 1);
			client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='false']", 0);
			client.sleep(1000);
			
		}
		else{	
			client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='false']", 0);
		}
				client.closeKeyboard();
	}
	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to swipe down and select the reminder
	 * 
	 * @param client
	 *			Integrate SeeTestAutomation
	 * @param reminderName
	 *          reminderName to be selected
	 * @param click
	 *            true/false
	 *            
	 */
	public void selectReminder(Client client, String reminderName, boolean click) {
		if(!client.isElementFound("NATIVE","xpath=//*[@text='"+reminderName+"'and @onScreen='true']",0)){
			client.elementSwipeWhileNotFound("NATIVE", "id=reminderList","Down", 300, 300, "NATIVE", "text=" + (reminderName), 0, 1000, 6,false);
			}
		if
			(!client.isElementFound("NATIVE","xpath=//*[@text='"+reminderName+"'and @onScreen='true']",0)){
				client.elementSwipeWhileNotFound("NATIVE", "id=reminderList","Up", 300, 300, "NATIVE", "text=" + (reminderName), 0, 1000, 6,false);
			
		}
		if(click){
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@text='"+reminderName+"'and @onScreen='true']", 0, 1);
		}

		waitFor(client,1);
	}

	
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to navigate top of the Reminder screen
	 * 
	 * @param client
	 *		Integrate SeeTestAutomation
	 * 
	 */
	public void navigateToReminderTop(Client client) {
		if(!client.isElementFound("NATIVE", "xpath=//*[@text='Scan Sensor' and @top='true']", 0))
			client.swipeWhileNotFound("Up", 500, 1000, "NATIVE", "xpath=//*[@text='Scan Sensor' and @top='true']", 0, 1000, 3, false);

	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 *   
	 * Method to edit the Existing Reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder
	 * @param hrs
	 *          select hours
	 * @param mins
	 *          select the minutes
 	 * @param newName
	 *          select the new name for reminder
	 *            
	 */
	public void editReminder(Client client, String name, int hrs, int mins, String newName,String ampm) {

		selectReminder(client,name,true);
		enterReminderName(client,newName);
		reminderSetTime(client,hrs,mins,ampm);
	}


	/**
	 * Author: Ilangovan
	 *            
	 * Method to Start or cancel the reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param click
	 *          true/false to start/cancel
	 *          
	 */

	public void startReminder(Client client, boolean click,String name) {
		client.elementSwipeWhileNotFound("NATIVE", "id=reminderList", "up",	0, 2000, "NATIVE", "text=Alarms", 0, 1000, 10, false);
		if (client.isElementFound("NATIVE", "xpath=//*[@text='" + name	+ "' and @top='true']", 0)) {
			client.clickIn("NATIVE", "text=" + (name), 0, "Right", "NATIVE","class=android.support.v7.widget.SwitchCompat", 0, 0, 0, 1);
		} else {

			client.elementSwipeWhileNotFound("NATIVE", "id=reminderList","Down", 500, 500, "NATIVE", "text=" + (name), 0, 1000, 7,false);
			client.clickIn("NATIVE", "text=" + (name), 0, "Right", "NATIVE","class=android.support.v7.widget.SwitchCompat", 0, 0, 0, 1);
		}
	}
		
	

	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to delete all the reminders
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void deleteAllReminders(Client client) {
		int count = client.getElementCount("NATIVE", "class=LibreLink.ReminderTableCell");
		for (int i=1;i<count;i++){
			client.elementSwipe("NATIVE", "class=LibreLink.ReminderTableCell", i, "Right", 0, 500);
			client.waitForElement(
					"NATIVE",
					"xpath=//*[@class='UISwipeActionStandardButton']",
					0, 500);
			client.click(
					"NATIVE",
					"xpath=//*[@class='UISwipeActionStandardButton']",
					0, 1);
			waitFor(client,1);
		}

	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 *  
	 * Method to verify Delete reminder option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *          
	 */

	public void verifyDeleteReminder(Client client, String name) {
		selectReminder(client,name,false);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Right", 0, 1000);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 500);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Left", 0, 500);
		waitFor(client,1);
		client.verifyElementNotFound(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				1);
	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 * 
	 * Method to delete the reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *            
	 */

	public void deleteReminder(Client client, String name) {
		selectReminder(client,name,false);
		client.elementSwipeWhileNotFound("NATIVE", "id=reminderList", "down",300, 300, "NATIVE", "text=" + (name), 0, 1000, 5, false);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Left", 0, 1000);
		client.waitForElement("NATIVE","xpath=//*[@knownSuperClass='android.widget.ImageButton' and @backColor='0xE0E0E0' and @top='true']",	0, 500);
		client.verifyElementFound("NATIVE","xpath=//*[@knownSuperClass='android.widget.ImageButton' and @backColor='0xE0E0E0' and @top='true']",0);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Right", 100, 500);
		client.sleep(1000);
		client.verifyElementNotFound("NATIVE","xpath=//*[@knownSuperClass='android.widget.ImageButton' and @backColor='0xE0E0E0' and @top='true']",1);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Left", 100, 500);
		client.waitForElement("NATIVE","xpath=//*[@knownSuperClass='android.widget.ImageButton' and @backColor='0xE0E0E0' and @top='true']",0, 500);
		client.click("NATIVE","xpath=//*[@knownSuperClass='android.widget.ImageButton' and @backColor='0xE0E0E0' and @top='true']",0, 1);
		client.verifyElementNotFound("NATIVE", "text=" + (name), 1);
	}



	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to verify Reminder 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          reminder name
	 * @param time
	 *			reminder time
	 * @param isRepeatEnabled
	 *          true/false
	 *            
	 */

		public void verifyReminder(Client client, String name, String time,	boolean check) {
			String DeviceVer = client.run("adb shell getprop ro.build.version.release ");
			if (DeviceVer.contains("5.")){
			if (getLanguage().contains("U.S.")&&(getLanguage().contains("United States")) ){
				time = time.replace("PM", "pm");
				time = time.replace("AM", "am");
			}else if  (getLanguage().contains("U.K.")
					&& getCountryCode().contains("United Kingdom")){
				time = time.replace("PM", "p.m.");
				time = time.replace("AM", "a.m.");
				
			}
			}
			else{
				if (getLanguage().contains("U.S.")&&(getLanguage().contains("United States")) ){
					time = time.replace("PM", "pm");
					time = time.replace("AM", "am");
				}else if  (getLanguage().contains("U.K.")
						&& getCountryCode().contains("United Kingdom")){
					time = time.replace("PM", "pm");
					time = time.replace("AM", "am");
					
				}
			}
			if (client.isElementFound("NATIVE", "xpath=//*[@text='" + name+ "' and @top='true']", 0)) {
				client.verifyIn("NATIVE", "text=" + (name), 0, "Left","NATIVE", "text=" + (time), 0, 0);

				if (check) {
					verifyRepeatOption(client, name ,time);
				}
			
			} else {
				client.runNativeAPICall("NATIVE", "xpath=//*[@id='reminderList']",0, "view.smoothScrollToPosition(0);");
				client.elementSwipeWhileNotFound("NATIVE", "id=reminderList","Down", 300, 300, "NATIVE", "text=" + (name), 0, 1000, 6,false);
				client.verifyIn("NATIVE", "text=" + (name), 0, "Left","NATIVE", "text=" + (time), 0, 0);
				if (check) {
					verifyRepeatOption(client, name,time);
				}
			}

		}



	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Reminder with Repeat option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 */
	public void verifyRepeatOption(Client client, String name,String time) {
	
		client.verifyIn("NATIVE","text=" + name,0,"Right","NATIVE","xpath=//*[@knownSuperClass='android.widget.LinearLayout' and @enabled='true']",0, 0);
	}

	


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param clearDialog
	 *          true/false
	 *            
	 */
	//TODO
	public void verifyReminderNotificationDialog(Client client, String name, boolean clearDialog) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reminder']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"+name+"' and @class='UITextView']", 0);
		if(clearDialog){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0, 1);	
			
		}
	}

	
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *            
	 */
	//TODO
	public void verifyReminderStatuswithReload(Client client, String name) {
		if(client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reload' and @hidden='false' and ./following-sibling::*[contains(@accessibilityLabel,'"+name+"')]]", 0)){
			Assert.assertEquals("1", returnSwitchStatus(client,name));
		}else{
			Assert.assertEquals("0", returnSwitchStatus(client,name));
		}

		
	}
	
	
	/**
	 * Author: ShabinaSherif /Ilangovan
	 *            
	 * Method to verify Reminder notification 
	 * 
	 * @param client
	 * 			  Integrate SeeTestAutomation
	 * @param name
	 *            choose the reminder name
	 * @param openReminder
	 *            true/false
	 *
	 */
	public void verifyReminderNotification(Client client, String Remidername, boolean openReminder) {
		
		//client.verifyElementFound("NATIVE", "xpath=//*[@id='icon' and @width>0 and ./parent::*[@id='icon_group' and ./following-sibling::*[./*[./*[@text='Alarm Expired']]]]]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Alarm Expired']", 0);
		client.verifyElementFound("NATIVE",  "xpath=//*[@class='android.widget.LinearLayout' and @width>0 and @height>0 and ./*[@text='"+Remidername+"']]",  0);
		client.click("NATIVE", "xpath=//*[@class='android.widget.LinearLayout' and @width>0 and @height>0 and ./*[@text='"+Remidername+"']]", 0, 1);
		
	}


	/**
	 * Author: ShabinaSherif /Ilangovan
	 * 
	 * Method to verify scan sensor notification 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param openReminder
	 *          true/false
	 */
	public void verifyScanSensorNotification(Client client, boolean openReminder) {
		client.sendText("{NOTIFICATION}");
		client.verifyElementFound("NATIVE", "xpath=//*[@id='title' and @text='Timer Expired']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@id='big_text' and @text='Scan Sensor']", 0);
		if(openReminder){
			client.elementSwipe("NATIVE", "xpath=//*[contains(@text,'Timer Expired, Scan Sensor')]", 0, "Left", 0, 500);
			waitFor(client,5);
		}else{
			clearSingleNotification(client,"Scan Sensor");
			closeNotification(client);
		}

	}


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder switch is enabled/disabled
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *         	reminder name
	 * @param isEnabled
	 *         true/false
	 *         
	 */
	public void verifyReminderStatus(Client client, String name, boolean isEnabled) {
		
		selectReminder(client,name,false);
		if(isEnabled){
			client.verifyIn("NATIVE","text=" + name,0,"Right","NATIVE",	"xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='true']",
					0, 0);
		}else{
			client.verifyIn("NATIVE","text=" + name,0,"Right","NATIVE","xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='false']",
					0, 0);
		}

	}

	
	

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to create reminder with advanced time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param time
	 *          set the advanced minute
	 *            
	 */
	public void addReminderWithAdvancedTime(Client client, String name, Integer time,String ampm) {

		clickAddReminder(client);
		enterReminderName(client,name);
		advanceReminderTimer(client, time,ampm);
		
		
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to set reminder time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hrs
	 *          set the hours
	 * @param mins
	 *          set the minutes
	 *
	 */
	public void reminderSetTime(Client client, int hrs, int mins, String ampm) {
		if (client.isElementFound("NATIVE", "xpath=//*[@id='alarmTime']", 0)) {
			client.click("NATIVE", "xpath=//*[@id='alarmTime']", 0, 1);
			client.runNativeAPICall("NATIVE",
					"xpath=//*[@id='mdtp_time_picker']", 0,
					"view.setTime(new com.wdullaer.materialdatetimepicker.time.Timepoint("
							+ hrs + "," + mins + "))");
			if (ampm != null) {
				if (ampm.equalsIgnoreCase("AM")) {
					client.runNativeAPICall("NATIVE","xpath=//*[@id='mdtp_time_picker']", 0,"view.setAmOrPm(0)");
				} else if (ampm.equalsIgnoreCase("PM")) {
					client.runNativeAPICall("NATIVE","xpath=//*[@id='mdtp_time_picker']", 0,"view.setAmOrPm(1)");
				}
			}
		}
		client.click("NATIVE", "xpath=//*[@id='mdtp_ok']", 0, 1);
		
	}
	/**
	 * Author: Ilangovan
	 *            
	 * Method to click Add Reminder 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hrs
	 *          set the hours
	 * @param mins
	 *          set the minutes
	 *
	 */

	public void clickAddremainderButton(Client client){
		
		client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmDoneButton']",0);
		client.click("NATIVE", "xpath=//*[@id='alarmDoneButton']", 0, 1);
	}
	
	/**
	 * Author: Ilangovan
	 *            
	 * Method to click Cancel Reminder 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hrs
	 *          set the hours
	 * @param mins
	 *          set the minutes
	 *
	 */

public void clickCancelremainderButton(Client client){
		
		client.verifyElementFound("NATIVE", "xpath=//*[@id='alarmCancelButton' and @enabled='true']",0);
		client.click("NATIVE", "xpath=//*[@id='alarmCancelButton' and @enabled='true']", 0, 1);
	}
	
	/**
	 * Author: ShabinaSherif 
	 *
	 * Method to advance the Reminder Time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param addTime
	 *          set the advanced time
	 *            
	 */
	public void advanceReminderTimer(Client client, Integer addTime,String ampm) {

		int hr = getCurrentHours();
		int min1 = getCurrentMinutes();
		int min;
		int hour;
		int minute = min1 + addTime;
		if (minute > 60) {
			hour = hr + 1;
			min = minute - 60;
		} else if (minute < 60) {
			hour = hr;
			min = minute;
		} else {
			hour = hr + 1;
			min = 00;
		}
		if(hour>=24){
			hour=hour-24;
		}
		reminderSetTime(client,hour,min,ampm);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to edit the existing Reminder With advanced Time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder to be edited
	 * @param time
	 *          set the advance time
	 *            
	 */

	public void editReminderWithAdvancedTime(Client client, String name, Integer time,String ampm) {
		navigateToReminderTop(client);
		
		selectReminder(client,name,true);
		enterReminderName(client,name);
		advanceReminderTimer(client, time, ampm);
		
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Repeating Options visibility
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param isEnabled
	 *          true/false
	 *            
	 */
	public void verifyRepeatingOptionsAvailability(Client client, boolean isEnabled) {

		clickRepeatingOption(client, isEnabled);
		String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='All']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");

		if(isEnabled){
			verifyRepeatingOptionsNotVisible(client, false);
			if(checkedStatus.equals("1")){
				verifyRepeatingOptions(client,true);}
			else{
				verifyRepeatingOptions(client,false);
			}
		}
		else{
			verifyRepeatingOptionsNotVisible(client, true);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to click on all check box
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void selectAllCheckBox(Client client) {
		if(client.isElementFound("NATIVE", "xpath=//*[@id='alarmRepeatSwitch' and @checked='false']", 0)){
		client.click("NATIVE","xpath=//*[@id='alarmRepeatAll']", 0, 1);
		verifyRepeatingOptions(client, true);
		}
		client.click("NATIVE","xpath=//*[@id='alarmRepeatAll']", 0, 1);

	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to click on all the days except All
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void selectAlldays(Client client) {
		String daysArray[] = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

		for (int i=0;i<daysArray.length;i++){

			String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
			if(checkedStatus.equals("0")){
				client.click("NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0, 1);
			}
		}
		verifyRepeatingOptions(client, true);
	}


	/**
	 * Author: ShabinaSherif/Ilangovan
	 *            
	 * Method to verify enable or disable reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param enable
	 *          true/false
	 *            
	 */
	public void enableordisableReminder(Client client, String name, boolean enable) {
		navigateToReminderTop(client);
		selectReminder(client,name,false);
		String enabledStatus = returnSwitchStatus(client,name);
		if((enabledStatus.equals("1") && !enable) || (enabledStatus.equals("0") && enable) ){
			client.click("NATIVE",
					"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, 1);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify Reminder Scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void verifyRemindersScanSensor(Client client) {
		
		client.waitForElement("NATIVE", "xpath=//*[@text='Scan Sensor']", 0, 1000);
		client.verifyElementFound("NATIVE", "xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='false']", 0);
		//client.verifyIn("NATIVE", "xpath=//*[@class='android.widget.LinearLayout' and @width>0 and ./*[@class='com.librelink.app.ui.widget.CountDownTextView'] and ./*[@class='android.support.v7.widget.AppCompatTextView']]", 0, "Inside", "NATIVE"," xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='false']", 0, 0);
		

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to Enable or Disable the Scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param enable
	 *          true/false
	 *            
	 */

	public void enableORdisableScanSensor(Client client, boolean enable) {
		if(client.isElementFound("NATIVE", "xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='false']")){
		client.waitForElement("NATIVE", "xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='false']", 0, 1000);
		client.click("NATIVE","xpath=//*[@knownSuperClass='android.widget.CompoundButton']", 0, 1);
		}
		else{
			client.verifyElementFound("NATIVE", "xpath=//*[@knownSuperClass='android.widget.CompoundButton' and @checked='true']", 0);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to Verify Scan Sensor Reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hour
	 *          select the reminder hour
	 *            
	 */

	public void setHourAndscanSensorTimerReminder(Client client, String hour) {
		clickScanSensor(client);
		selectScanSensorTime(client,hour);
		client.click("NATIVE", "xpath=//*[@id='text1']", 0, 1);
		client.click("NATIVE", "xpath=//*[@id='timerStartButton']", 0, 1);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to click scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void clickScanSensor(Client client) {

			if (client.isElementFound("NATIVE", "xpath=//*[@text='Scan Sensor' and @enabled='true']", 0)) {
				client.click("NATIVE", "xpath=//*[@text='Scan Sensor' and @enabled='true']", 0, 1);
			}
	
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to select scan sensor time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hr
	 *          select the reminder hour
	 *            
	 */

	public void selectScanSensorTime(Client client, String hour) {
		client.isElementFound("NATIVE", "xpath=//*[@text='Scan Sensor']", 0);
		client.click("NATIVE", "xpath=//*[@text='Scan Sensor']", 0, 1);
		client.click("NATIVE", "xpath=//*[@id='timerDuration']", 0, 1);
		client.sleep(1000);
		
		if(client.isElementFound("NATIVE", "xpath=//*[@text='"+ hour+"' and @onScreen='true']")){
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"+ hour+"' and @onScreen='true']", 0);
			
		}
		else{
			 client.runNativeAPICall("NATIVE", "xpath=//*[contains(@class,'DropDownListView')]", 0, "view.smoothScrollToPosition(0);");
			client.swipeWhileNotFound("Down", 1000, 500, "NATIVE", "xpath=//*[@text='"+ hour+"' and @onScreen='true']", 0, 1000, 5, true);
			
		}
		}
		
	

	/**
	 * Author: ShabinaSherif 
	 *  
	 * Method to click scan Sensor and verify Hours
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void clickScanSensorandVerifyHours(Client client) {

		clickScanSensor(client);
		client.click("NATIVE", "xpath=//*[@text='Scan Sensor']", 0, 1);
		client.sleep(1000);
		client.click("NATIVE", "xpath=//*[@id='timerDuration']", 0, 1);
		if (client.swipeWhileNotFound("Up", 1000, 500, "NATIVE", "text=1 hr",
				0, 1000, 3, false)) {
			client.verifyElementFound("NATIVE", "text=1 hr", 0);
		}
		for (int i = 2; i <= 12; i++) {
			String text = "text" + "=" + Integer.toString(i) + " " + "hrs";
			;
			if (client.isElementFound("NATIVE", text, 0) == false) {
				client.elementSwipe(
						"NATIVE",
						"xpath=//*[contains(@class,'DropDownListView')]",
						0, "Down", 0, 500);

			}
			client.waitForElement("NATIVE", text, 0, 5000);
			client.verifyElementFound("NATIVE", text, 0);

		}

	}



	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify scan sensor notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param clearDialog
	 *          true/false
	 *            
	 */
	public void verifyScanSensorNotificationDialog(Client client, boolean clearDialog) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Timer Expired']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Scan Sensor' and @class='UITextView']", 0);
		if(clearDialog){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0, 1);	
			waitFor(client,1);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to return reminder switch status 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @return isSelected
	 * 			Return switch status           
	 */

	public String returnSwitchStatus(Client client, String name) {
		String isSelected = client.runNativeAPICall("NATIVE", "xpath=//*[@class='android.widget.LinearLayout' and ./following-sibling::*[@text='"+name+"']]", 0, "view.smoothScrollToPosition(0);");
		
		return isSelected;
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify scan sensor reminder status
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param countdown
	 *          set time
	 * @param isEnabled
	 *          true/false
	 *            
	 */

	public void verifyScanSensorStatus(Client client, boolean isEnabled, String time) {
		client.verifyElementFound("NATIVE", "text=Reminders", 0);
		if (isEnabled) {
			client.verifyElementFound("NATIVE","xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='true']",0);
			String t1 = client.elementGetText("NATIVE","xpath=//*[@class='com.librelink.app.ui.widget.CountDownTextView' and ./following-sibling::*[@text]]",0);
			client.sleep(5000);
			String t2 = client.elementGetText("NATIVE","xpath=//*[@class='com.librelink.app.ui.widget.CountDownTextView' and ./following-sibling::*[@text]]",0);
			String t3 = t2.substring(0, t2.length() - 2);
			String newtime=time.substring(0,time.length()-2);

		if (!t1.equals(t2)) {
				Assert.assertTrue(t3.contains(newtime));

				System.out.println("Scan Sensor TIMERS reminder displayed a countdown timer which started from "
						+ t3 + "XX");
			}

		} else {
			client.verifyElementFound("NATIVE",	"xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='false']",0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='--:--']", 0);
		}
          System.out.println("************* pass**************");
	}


		/**
		 * Author: ShabinaSherif 
		 * 
		 * Method for an reminder content to vanish
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void reminderAlarmContentvanish(Client client) {
			
			String content = client.elementGetText("NATIVE", "id=nextReminderText",	0);
			client.waitForElementToVanish("NATIVE", "text=" + content, 0, 9000);


		}
		
		/**
		 * Author: ShabinaSherif 
		 * 
		 * Method for an reminder content to vanish
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void reminderTimerContentvanish(Client client) {
			client.waitForElementToVanish("NATIVE",
					"xpath=//*[contains(@text,'Next Reminder')]", 0, 90000);
			if(client.isElementFound("NATIVE", "xpath=//*[contains(@text,'Next Reminder: 00:00')]", 0)){
				launch(client);
			}
		}
			
		
		/**
		 * Author: ShabinaSherif
		 * 
		 * Method to select and verify Reminder With special Characters
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void selectandVerifyReminderWithSpecialCharacters(Client client) {
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME,true);
			enterReminderName(client,LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME);
			clickAddremainderButton(client);
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME,false);
			client.verifyElementFound("NATIVE", "text=" + LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME, 0);

		}

		/**
		 * Author: ShabinaSherif /Ilangovan
		 *            
		 * Method to verify Next Reminder with BackGround Color
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * @param name
		 *          reminder name
		 * @param time
		 *          reminder time
		 *            
		 */

		public void verifyNextReminderwithBackGroundColor(Client client,
				String name, String time) {

			client.verifyElementFound("NATIVE",	"xpath=//*[@id='nextReminderText' and contains(@text,'" + time
					+ ", " + name + "')]", 0);
			client.verifyElementFound("NATIVE","xpath=//*[@id='nextReminderText' and @backColor='0x138BE8']",0);

		}


		/**
		 * Author: ShabinaSherif 
		 *            
		 * Method to select and verify Reminder With 50+ Characters
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */

		public void selectandVerifyreminderWithFiftyPlusCharacters(Client client) {
			enterReminderName(client,LibrelinkConstants.FIFTYPLUSCHARACTER_REMINDER_NAME);
			advanceReminderTimer(client, 5,"am");
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME,false);
			client.verifyElementFound("NATIVE", "text=" + LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME, 0);
			client.verifyElementNotFound("NATIVE","text=" + LibrelinkConstants.FIFTYPLUSCHARACTER_REMINDER_NAME, 0);
		}


		/**
		 * Author: ShabinaSherif
		 *            
		 * Method to return the day of the week
		 * 
		 * @param day
		 *            Choose day of week
		 * @return day
		 * 			returns day of the Week           
		 */

		public int dayoftheWeek(String day) {
			if(day.equals("Monday")){
				return Calendar.MONDAY;
			}else if(day.equals("Tuesday")){
				return Calendar.TUESDAY;
			} else if(day.equals("Wednesday")){
				return Calendar.WEDNESDAY;
			}else if(day.equals("Thursday")){
				return Calendar.THURSDAY;
			}else if(day.equals("Friday")){
				return Calendar.FRIDAY;
			}else if(day.equals("Saturday")){
				return Calendar.SATURDAY;
			}else if(day.equals("Sunday")){
				return Calendar.SUNDAY;
			} else return 0;
		}

			

		/**
		 * Author: Ilangovan
		 *            
		 * 
		 * Select upcoming tuesday with time 7:29 pm
		 * @param client
		 * @throws ParseException
		 */
		

		public static Calendar thisWeek(int dow) {

			Calendar date = Calendar.getInstance();
			int diff = dow - date.get(Calendar.DAY_OF_WEEK);
			if (!(diff > 7)) {
				diff += 7;
			}
			date.add(Calendar.DAY_OF_MONTH, diff);
			return date;
		}

		/**
		 * Author: Ilangovan
		 *            
		 * 
		 * Verify the Reminder Notification
		 * 
		 * @param client
		 * @throws ParseException
		 */
		
		
		public void verifyWaitReminderRecursive(Client client, String name) {
			closeApplication(client);
			closeDebugDrawer(client);
			openNotification(client);
              VerifyReminder(client,"Before Dinner") ;
			client.verifyElementFound("TEXT",""+name, 0);
			closeNotification(client);

			backToReminder(client);
			client.elementSwipeWhileNotFound("NATIVE", "id=reminderList", "Down",
					300, 300, "NATIVE", "text=" + (name), 0, 1000, 5, false);
			client.verifyIn(
					"NATIVE",
					"text=" + name,
					0,
					"Right",
					"NATIVE",
					"xpath=//*[@knownSuperClass='android.widget.ImageView' and @enabled='true']",
					0, 0);

		}
		
		/**
		 * Author: Ilangovan
		 *            
		 * 
		 * Click on back Reminder 
		 * @param client
		 * @throws ParseException
		 */
		

		public void backToReminder(Client client) {

			if (client.isElementFound("NATIVE", "xpath=//*[@id='action_reminder' and @onScreen='true']")) {
				client.click("NATIVE", "id=action_reminder", 0, 1);
			}

		}
		
		/**
		 * Author: Ilangovan
		 *            
		 * 
		 * Verify the Notification 
		 * @param client
		 * @throws ParseException
		 */
			
public void verifyTimerExpired(Client client, String name) {
	client.sleep(30000);
	navigateToScreen(client, "home");
	closeDebugDrawer(client);
	navigateToScreen(client, "reminders");
	client.sleep(1000);
	client.waitForElementToVanish("NATIVE","xpath=//*[contains(@text,'Next Reminder')]", 0, 90000);
	if(client.isElementFound("NATIVE", "xpath=//*[contains(@text,'Next Reminder: 00:00')]", 0)){
	launch(client);
			}
	client.sendText("{NOTIFICATION}");
	client.verifyElementFound("TEXT",""+name, 0);
				closeNotification(client);

				if (client.isElementFound("NATIVE", "id=action_reminder")) {
					client.click("NATIVE", "id=action_reminder", 0, 1);
				}
				client.verifyElementFound("NATIVE", "xpath=//*[@text='--:--']", 0);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='true']",
						0);

			}

/**
 * Author: Ilangovan
 *            
 * 
 * Select Scan Sensor 
 * @param client
 * @throws ParseException
 */



public void scanMockWithBGTypeAndVerifyDeaultReminder(Client client,
		String type, boolean isEnabled, String time) {
	client.swipe("Right", 0, 500);
	client.verifyElementFound("NATIVE", "id=debug_sensor_add_data", 0);
	client.click("NATIVE", "id=debug_sensor_add_data", 0, 1);
	if (client.waitForElement("NATIVE", "text=Add Sensor Data", 0, 10000)) {
		if(type.equals("Historic")){
			client.verifyElementFound("NATIVE", "text=Realtime", 0);
			client.click("NATIVE", "text=Realtime", 0, 1);
			client.click("NATIVE", "xpath=//*[@text='Add']", 0, 1);
			client.click("NATIVE", "id=debug_sensor_add_data", 0, 1);
		}

		client.verifyElementFound("NATIVE", "text=" + type, 0);
		client.click("NATIVE", "text=" + type, 0, 1);
		client.click("NATIVE", "xpath=//*[@text='Add']", 0, 1);
	}
	if (client.waitForElement("NATIVE", "id=debug_sensor_scan", 0, 10000)) {

		client.click("NATIVE", "id=debug_sensor_scan", 0, 1);
		client.waitForElement("NATIVE", "id=debug_sensor_scan_skip", 0,
				10000);

		client.click("NATIVE", "xpath=//*[@text='Scan Now']", 0, 1);
	}

	client.waitForElement("NATIVE", "text=My Glucose", 0, 5000);
	client.click("NATIVE", "contentDescription=Navigate up", 0, 1);
	closeDebugDrawer(client);
	client.waitForElement("NATIVE", "text=Ready to Scan", 0, 10000);
	client.verifyElementFound("NATIVE", "id=action_reminder", 0);
	client.click("NATIVE", "id=action_reminder", 0, 1);
	client.waitForElement("NATIVE", "text=Reminders", 0, 5000);
	displaySensorTimer(client, isEnabled, time);
}

/**
 * Author: Ilangovan
 *            
 * 
 * Verify the Scan Sensor status
 * @param client
 * @throws ParseException
 */

public void displaySensorTimer(Client client, boolean isEnabled, String time) {


	client.verifyElementFound("NATIVE", "text=Reminders", 0);
	if (isEnabled) {
		client.verifyElementFound("NATIVE","xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='true']",0);
		String t1 = client
				.elementGetText("NATIVE","xpath=//*[@class='com.librelink.app.ui.widget.CountDownTextView' and ./following-sibling::*[@text]]",	0);
		client.sleep(5000);
		String t2 = client
				.elementGetText("NATIVE","xpath=//*[@class='com.librelink.app.ui.widget.CountDownTextView' and ./following-sibling::*[@text]]",0);
		String t3 = t2.substring(0, t2.length() - 2);
		String newtime=time.substring(0,time.length()-2);


		if (!t1.equals(t2)) {
			Assert.assertTrue(t3.contains(newtime));

			System.out
			.println("Scan Sensor TIMERS reminder displayed a countdown timer which started from "
					+ t3 + "XX");
		}

	} else {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='false']",
				0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='--:--']", 0);
	}

}
/**
 * Author: Ilangovan
 *            
 * 
 * Disable/Enable for  Scan Sensor 
 * @param client
 * @throws ParseException
 */

public void disableScanSensor(Client client) {
	client.waitForElement("NATIVE", "text=Scan Sensor", 0, 5000);
	if (client
			.isElementFound(
					"NATIVE",
					"xpath=//*[@class='android.support.v7.widget.SwitchCompat' and @checked='true']")) {
		client.click(
				"NATIVE",
				"xpath=//*[@class='android.support.v7.widget.SwitchCompat']",
				0, 1);

	}
	
	
}

/**
 * Author: Ilangovan
 *            
 * 
 * Select upcoming monday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisMonday(Client client) throws ParseException {
	String format = String.format("%ta, %<tb %<te, %<tY",
		thisWeek(Calendar.MONDAY));
String newFormat = format.substring(5);
DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
		Locale.ENGLISH);

Date date = originalFormat.parse(newFormat);
String DeviceVer = client
		.run("adb shell getprop ro.build.version.release ");
if (DeviceVer.contains("5.")) {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
	String YYYYMMDD = sdf.format(date);
	System.out.println(YYYYMMDD);
	client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
}
else{
	SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
	String MMDDYY = altsdf.format(date);
	System.out.println(MMDDYY);
	client.run("adb shell su -c 'date " + MMDDYY + "'");
	client.run("adb shell su -c 'date " + MMDDYY + "'");
	client.sleep(40000);
	openBackgroundApp(client);

}
client.sleep(10000);

}

/**
 * Author: ilangovan
 *            
 * 
 * Select upcoming wednesday with time 7:29 pm
 * @param client
 * @throws ParseException
 */

public void thisTuesday(Client client) throws ParseException {
	client.sleep(1000);
	String format = String.format("%ta, %<tb %<te, %<tY",
			thisWeek(Calendar.TUESDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);

	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}
   



/**
 * Author: Ilangovan
 *            
 * 
 * Select upcoming wednesday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisWednesday(Client client) throws ParseException {

	String format = String.format("%ta, %<tb %<te, %<tY",
			thisWeek(Calendar.WEDNESDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);

	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}

/**
 * Author: Ilangovan
 *            
 * 
 *  Select upcoming thrusday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisThrusday(Client client) throws ParseException {
	client.sleep(1000);
	String format = String.format("%ta, %<tb %<te, %<tY",
			thisWeek(Calendar.THURSDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);
	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}
/**
 * Author: Ilangovan
 *            
 * 
 *  Select upcoming friday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisFriday(Client client) throws ParseException {
	client.sleep(1000);
	String format = String.format("%ta, %<tb %<te, %<tY",
			thisWeek(Calendar.FRIDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);
	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}
/**
 * Author: Ilangovan
 *            
 * 
 * Select upcoming saturday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisSaturday(Client client) throws ParseException {
	client.sleep(1000);
	String format = String.format("%ta, %<tb %<te, %<tY",
			thisWeek(Calendar.SATURDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);
	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}
/**
 * Author: Ilangovan
 *            
 * 
 * Select upcoming sunday with time 7:29 pm
 * @param client
 * @throws ParseException
 */
public void thisSunday(Client client) throws ParseException {
	client.sleep(1000);
	String format = String.format("%ta, %<tb %<te, %<tY",
			secondWeek(Calendar.SUNDAY));
	String newFormat = format.substring(5);
	DateFormat originalFormat = new SimpleDateFormat("MMMM dd, yyyy",
			Locale.ENGLISH);
	Date date = originalFormat.parse(newFormat);
	String DeviceVer = client
			.run("adb shell getprop ro.build.version.release ");
	if (DeviceVer.contains("5.")) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.1928ss");
		String YYYYMMDD = sdf.format(date);
		System.out.println(YYYYMMDD);
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
		client.run("adb shell su -c 'date -s " + YYYYMMDD + "'");
	}
	else{
		SimpleDateFormat altsdf = new SimpleDateFormat("MMdd1928YY.ss");
		String MMDDYY = altsdf.format(date);
		System.out.println(MMDDYY);
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.run("adb shell su -c 'date " + MMDDYY + "'");
		client.sleep(40000);
		openBackgroundApp(client);

	}
	client.sleep(10000);

}
/**
 * Author: Ilangovan
 *            
 * 
 * Set Second week on calendar  
 * @param client
 * @throws ParseException
 */

public static Calendar secondWeek(int dow) {
	Calendar date = Calendar.getInstance();
	int diff = dow - date.get(Calendar.DAY_OF_WEEK);
	if (!(diff > 0)) {
		diff += 14;
	}
	date.add(Calendar.DAY_OF_MONTH, diff);
	return date;
}


}




