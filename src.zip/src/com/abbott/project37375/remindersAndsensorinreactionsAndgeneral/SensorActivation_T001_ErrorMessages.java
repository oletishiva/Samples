package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;

public class SensorActivation_T001_ErrorMessages
extends SensorHelper {

	@Test
	public void test_SensorActivation_T001_ErrorMessages() throws Exception {

		
		
		startUp(client);
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAUIRS1174
		 * @Expected HomeScreen shows CHECK GLUCOSE screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step1);
		selectingSASMode(client, "MOCK_1");
		//TODO
		//editConfiguration(client,-1, 0, 0,"1/14");
		//verifyPageTitles(client,"CHECK GLUCOSE");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAUIRS1174
		 * @Expected HomeScreen shows Apply New Sensor screen is displayed and Scan New Sensor button is displayed on Next screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
	
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step2);
		debugDrawerClearData(client);
		//TODO
		//editConfiguration(client, -15,-1, 0,"1/14");
		//clickOnButtonOption(client,"Next",true);		
		//verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAUIRS1084
		 * @Expected Sensor Expired dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step3);
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,0,0);
		scanMockSensor(client,"EXPIRED");
		verifySensorDialogScreen(client,"sensorExpired","sensorExpiredContent");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAUIRS1084
		 * @Expected App returns back to Home screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step4);
		clickOnButtonOption(client,"OK",true);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		capturescreenshot(client, getStepID(), true);
		debugDrawerClearData(client);         
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAUIRS1085
		 * @Expected Sensor Already Used dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step5);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		clickOnButtonOption(client,"Yes",true);
		openDebugDrawer(client);
	scanMockSensor(client,"ALREADY_STARTED");
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifySensorDialogScreen(client,"error_sensor_already_started_title","error_sensor_already_started_msg");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifySensorDialogScreen(client,"error_sensor_already_started_title","error_sensor_already_started_msg_llj");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAUIRS1085
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step6);
		clickOnButtonOption(client,"OK",true);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAUIRS1087
		 * @Expected Scan Error dialog is displayed for Response Corrupt error
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step7);
		openDebugDrawer(client);
		scanMockSensor(client,"RESPONSE_CORRUPT");
		verifySensorDialogScreen(client,"error_sensor_corrupt_title","error_sensor_corrupt_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAUIRS1087
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step8);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAUIRS1088
		 * @Expected Replace Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step9);
		openDebugDrawer(client);
     	scanMockSensor(client,"TERMINATED");
		verifySensorDialogScreen(client,"error_sensor_terminated_title","error_sensor_terminated_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAUIRS1088
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step10);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAUIRS1089
		 * @Expected Replace Sensor dialog is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step11);
		openDebugDrawer(client);
		scanMockSensor(client,"REMOVED");
		verifySensorDialogScreen(client,"error_sensor_removed_title","error_sensor_removed_msg");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAUIRS1089
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step12);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
	
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAUIRS1090
		 * @Expected Incompatible Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step13);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_COMPATIBLE");
		verifySensorDialogScreen(client,"error_sensor_incompatible_title","error_sensor_incompatible_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAUIRS1090
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step14);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAUIRS1083
		 * @Expected Scan Error dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step15);
		openDebugDrawer(client);
		scanMockSensor(client,"TRANSMISSION_ERROR");
		verifySensorDialogScreen(client,"error_sensor_transmission_title","error_sensor_transmission_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAUIRS1083
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_ErrorMessages_Step16);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
	}

}
