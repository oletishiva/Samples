package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;


public class Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check extends TestReminderHelper {

	@Test
	public void test_T002_Alarm_Reminder_UI_RepeatingOptions_Check() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "reminders");
		if (!client.isElementFound("NATIVE",
				"xpath=//*[contains(@text,'No active reminders.') and @hidden='false']",
				0)) {
			startUp(client);
			navigateToScreen(client, "reminders");
		}
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS916
		 * @Expected The below checkboxes are displayed and not checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step1);
		clickAddReminder(client);
		clickRepeatingOption(client, true);
		verifyRepeatingOptions(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step2);
		selectAllCheckBox(client);
		capturescreenshot(client, getStepID(), true);
		selectAllCheckBox(client);
		client.click("NATIVE", "xpath=//*[@id='alarmCancelButton' and @enabled='true']", 0, 1);
		clickAddReminder(client);
		
		
		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS916
		 * @Expected check boxes are not displayed when repeating option is disabled
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step3);
		clickRepeatingOptiondisable(client);
		verifyRepeatingOptionsNotVisible(client,true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS916
		 * @Expected Check boxes are displayed and checked when repeating option is enabled again
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step4);
		clickRepeatingOption(client, true);
		selectRepeatingOption(client,"All",true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS916
		 * @Expected Monday and All options checkbox are only unchecked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step5);
		selectRepeatingOption(client,"Monday",false);
		verifySingleRepeatingOption(client,"Monday",false);
		verifySingleRepeatingOption(client,"All",false);
		verifySingleRepeatingOption(client,"Tuesday",true);
		verifySingleRepeatingOption(client,"Wednesday",true);
		verifySingleRepeatingOption(client,"Thursday",true);
		verifySingleRepeatingOption(client,"Friday",true);
		verifySingleRepeatingOption(client,"Saturday",true);
		verifySingleRepeatingOption(client,"Sunday",true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step6);
		//selectRepeatingOption(client,"Monday",true);
		selectRepeatingOption(client,"All",true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS916
		 * @Expected checkboxes are not checked when every single day option is unchecked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step7);
		selectRepeatingOption(client,"All",false);
		verifyRepeatingOptions(client, false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked when every single day option is checked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/

		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step8);
		selectRepeatingOption(client,"All",true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step9);
		enterReminderName(client,"Before Dinner");
		advanceReminderTimer(client, 2,null);
		clickAddremainderButton(client);
		thisMonday(client);
		reminderAlarmContentvanish(client);
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step10);
		thisTuesday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step11);
		thisWednesday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step12);
		thisThrusday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step13);
		thisFriday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step14);
		thisSaturday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step15);
		thisSunday(client);
		reminderAlarmContentvanish(client);
		startReminder(client,true,"Before Dinner");
		capturescreenshot(client, getStepID()+"_Displaying Notification", true);
		//TODO
		//verifyReminderNotificationDialog(client, "Before Dinner",true);
		//TODO
		//verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID()+"_After clicking OK for the notification", true);

	
		
		/**
		 * 
		 * @stepId Clean up
		 * @Reqt
		 * @Expected
		 * @Dependancy NA
		 **/

		selectingSASMode(client,"DEFAULT");
	    currentSystemTime(client);
	}

	

}