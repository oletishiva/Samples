package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;


import java.text.ParseException;
import com.abbott.project37375.main.BaseHelper;
import com.experitest.client.Client;

public class SensorHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif (Completed)/NagarajuKasarla
	 * 
	 * verify Sensor Dialog Screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param errortitle
	 * 			send error title
	 * @param errormessage
	 * 	        send error message
	 */
	public void verifySensorDialogScreen(Client client,String errortitle,String errormessage) {
		client.verifyElementFound("NATIVE","text=${"+errortitle+"}", 0);
		client.verifyElementFound("NATIVE","text=${"+errormessage+"}", 0);
		clickOnButtonOption(client,"OK",false);
		}

	/**
	 * Author:NagarajuKasarla/Ilangovan
	 * 
	 * verify HomePage With ScanData
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param lastScan
	 *           sending lastScan value
	 * @param average
	 *        	 sending average value
	 */
	public void verifyHomePageWithScanData(Client client, String lastScan,
			String averagescan, String numerator, String denominator) {
		client.waitForElement("NATIVE", "xpath=//*[@text='LAST 24 HOURS']", 0, 10000);
		//TODO
		//client.verifyElementFound("NATIVE", "xpath=//*[@text='CHECK GLUCOSE']", 0);
		if (client.isElementFound("NATIVE",
				"xpath=//*[@id='data_value' and ./parent::*[@id='last_scan']]",
				0)) {

			client.verifyElementFound("NATIVE",
					"contentDescription=Last Scan: " + lastScan, 0);
			client.verifyElementFound(	"NATIVE","xpath=//*[@text='"+ numerator	+ "' and ./parent::*[./parent::*[./parent::*[@id='last_scan']]]]",0);
			client.verifyElementFound("NATIVE","xpath=//*[@text='"+ denominator+ "' and ./parent::*[./parent::*[./parent::*[@id='last_scan']]]]",0);
		}
		if (client.isElementFound("NATIVE",	"xpath=//*[@id='data_value' and ./parent::*[@id='average']]",
						0)) {
			client.verifyElementFound("NATIVE", "contentDescription=Average: "
					+ averagescan, 0);
			client.verifyElementFound("NATIVE","xpath=//*[@text='"+ numerator+ "' and ./parent::*[./parent::*[./parent::*[@id='average']]]]",
							0);
			client.verifyElementFound("NATIVE","xpath=//*[@text='"+ denominator+ "' and ./parent::*[./parent::*[./parent::*[@id='average']]]]",
							0);
		}
		
	}

	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * verify NOT ACTIVE Sensor Screen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */
	public void verifyNotActiveSensorScreen(Client client) {
		client.verifyElementFound("NATIVE",	"text=${error_sensor_not_active_title}", 0);
		client.verifyElementFound("NATIVE",	"xpath=//*[contains(@text,'Starting a new Sensor will end the Sensor you are currently using.')]", 0);
		client.verifyElementFound("NATIVE",	"xpath=//*[contains(@text,'Would you like to start the new one now?')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='No']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Yes']", 0);
	}

	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * verify event log content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation Error Title Error Description
	 * @param errTitle
	 *         verifying error Title
	 * @param errDesc
	 *  	   verifying error description
	 */
	public void verifyEventLogContent(Client client, String errTitle,
			String errDesc) {
		if(!client.isElementFound("NATIVE", "text=${" + errTitle + "}", 0)){
		client.elementSwipeWhileNotFound("NATIVE", "id=eventList","Down", 500, 500, "NATIVE", "text=${" + errTitle + "}", 0, 1000, 6,false);
		}
		client.verifyElementFound("NATIVE", "text=${" + errTitle + "}", 0);
		client.verifyElementFound("NATIVE", "text=${" + errDesc + "}", 0);

	}

	/**
	 * Author: ShabinaSherif/Ilangovan
	 * 
	 * verify event log content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation Error Title Error Description
	 * 
	 */
	public void eventlogScrollUp(Client client) {
		client.runNativeAPICall("NATIVE", "xpath=//*[@id='eventList']", 0,
				"view.smoothScrollBy(-9999999, 0);");
    }


	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Screen NotFound
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param screen
	 * 			ScreenName
	 */
	public void verifyScreenNotFound(Client client,String screen) {
		client.verifyElementNotFound("NATIVE","xpath=//*[@text='"+screen+"']", 0); 	
	}
	
	/**
	 * Author: NagarajuKasarla
	 * 
	 * Add And Verify Historical And RealtimeData
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @throws ParseException 
	 * 
	 */
	public void addAndVerifyHistoricalAndRealtimeData(Client client) throws ParseException {
		selectingSASMode(client, "MOCK_1");
		debugDrawerClearData(client);
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","100",true,9,00);
		bgValueWithStaticTime(client,"Historic","120",true,9,15);
		bgValueWithStaticTime(client,"Realtime","130",false,0,0);
		scanMockSensor(client, null);
		clickBackFromMyGlucose(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
	}
	
	/**
	 * Author: Ilangovan
	 * 
	 *         Verify Sensor Screen With Other NFCApp
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void verifySensorScreenWithOtherNFCApp(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@id='button1' and @text='${ok}']", 0, 2000);
		client.verifyElementFound("NATIVE", "text=${errorOtherNfcInstalled}", 0);
		client.verifyElementFound("NATIVE","text=${error_sensor_corrupt_title}", 0);
		client.verifyElementNotFound("NATIVE","xpath=//*[@id='icon'and @hidden='false']", 0);
		client.verifyElementFound("NATIVE", "text=${ok}", 0);
	}
}
