package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;

public class SensorActivation_T002_TranmissionError
extends SensorHelper {

	@Test
	public void test_T002_Mock1UI_TranmissionError_with_NFCApp_installed() throws Exception {
		/**
		 * @stepId Pre-Condition Install the other NFC app
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */
		installUninstallOtherNFCAPP(client, true);

		try {
			/**
			 * 
			 * @stepId Step 1
			 * @Reqt SDAUIRS1174
			 * @Expected HomeScreen shows Scan Sensor
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.SensorActivation_T002_TranmissionError_Step1);
			
			selectingSASMode(client, "MOCK_1");
			debugDrawerClearData(client);
			editConfiguration(client, -30, 0, 0,"1/14");
			//verifyPageTitles(client, "scanSensor");
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 2
			 * @Reqt SDAUISRS1083
			 * @Expected Transmission Error with other NFC app installed dialog
			 *           is displayed
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.SensorActivation_T002_TranmissionError_Step2);
			openDebugDrawer(client);
			scanMockSensor(client, "TRANSMISSION_ERROR");
			verifySensorScreenWithOtherNFCApp(client);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 3
			 * @Reqt SDAUISRS1083
			 * @Expected HomeScreen shows Scan Sensor
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.SensorActivation_T002_TranmissionError_Step3);
			clickOnButtonOption(client,"OK",true);
			//verifyPageTitles(client, "scanSensor");
			capturescreenshot(client, getStepID(), true);

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			//installUninstallOtherNFCAPP(client, false);
			//launch(client);
			throw e;
		}

		//installUninstallOtherNFCAPP(client, false);
		//startUp(client);

	}
}
