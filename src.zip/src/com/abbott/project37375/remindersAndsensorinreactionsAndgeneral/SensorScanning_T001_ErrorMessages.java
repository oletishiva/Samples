package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;



public class SensorScanning_T001_ErrorMessages
extends SensorHelper {

	@Test
	public void test_SensorScanning_T001_Mock1UI_ErrorMessages() throws Exception {

		/**
		 * @stepId Pre-Condition Update the Time Format
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */
		setTheDateAndTime(client, 20, 03, 2018, "12:00");
		startUp(client);
		
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step1);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt  SDAUIRS1097 
		 * @Expected A dialog for SensorRfTransmissionError is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step2);
		openDebugDrawer(client);
		scanMockSensor(client,"TRANSMISSION_ERROR");
		verifySensorDialogScreen(client,"error_sensor_transmission_title","error_sensor_transmission_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAUIRS1097
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step3);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAUIRS1096
		 * @Expected A dialog for SensorNotActive is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step4);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		verifyNotActiveSensorScreen(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAUIRS1096
		 * @Expected App returns to Home screen, My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step5);
		clickOnButtonOption(client,"No",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAUIRS1096
		 * @Expected App returns to 'Scan New Sensor' screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step6);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		clickOnButtonOption(client,"Yes",true);
		closeDebugDrawer(client);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAUIRS1096
		 * @Expected App shows Home screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step7);
		verifyPageTitles(client, "scanNewSensor");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"Cancel",true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAUIRS1103_SDAISRS330
		 * @Expected A dialog for SensorTemperatureTooHigh is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step8);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMP_HIGH");
		verifySensorDialogScreen(client,"error_sensor_too_hot_title","error_sensor_too_hot_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAUIRS1103_SDAISRS330 
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step9);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAUIRS1104_SDAISRS330
		 * @Expected A dialog for SensorTemperatureTooLow is shown 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step10);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMP_LOW");
		verifySensorDialogScreen(client,"error_sensor_too_cold_title","error_sensor_too_cold_msg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAUIRS1104_SDAISRS330
		 * @Expected Sensor Error dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step11);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAUIRS1105 SDAISRS827 
		 * @Expected A dialog for SensorTemporaryProblem  is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step12);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMPORARY_PROBLEM");
		verifySensorDialogScreen(client,"error_sensor_temporary_problem_title","error_sensor_temporary_problem_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAUIRS1105
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step13);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAUIRS1108
		 * @Expected A dialog for SensorNotCompatible  is shown 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step14);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_COMPATIBLE");
		verifySensorDialogScreen(client,"error_sensor_incompatible_title","error_sensor_incompatible_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAUIRS1108
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step15);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAUIRS1101
		 * @Expected A dialog for SensorInWarmup  is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step16);
		openDebugDrawer(client);
		scanMockSensor(client,"IN_WARMUP");
		verifySensorDialogScreen(client,"error_sensor_inwarmup_title","error_sensor_inwarmup_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAUIRS1101
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step17);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAUIRS1099
		 * @Expected A dialog forResponseCorrupt is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step18);
		openDebugDrawer(client);
		scanMockSensor(client,"RESPONSE_CORRUPT");
		verifySensorDialogScreen(client,"error_sensor_corrupt_title","error_sensor_corrupt_msg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAUIRS1099
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step19);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDASRS257_SDASRS368
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step20);
		clickOnSettingsMenu(client, "help");
		navigateToSubMenuScreens(client,"eventLog");
		verifyEventLogContent(client, "error_sensor_corrupt_title","error_sensor_corrupt_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_inwarmup_title","error_sensor_inwarmup_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_incompatible_title","error_sensor_incompatible_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_temporary_problem_title","error_sensor_temporary_problem_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_too_cold_title","error_sensor_too_cold_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_too_hot_title","error_sensor_too_hot_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_not_active_title","error_sensor_not_active_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_transmission_title","error_sensor_transmission_msg");
		eventlogScrollUp(client);
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
	}

	

}
