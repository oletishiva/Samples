package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;


public class SensorScanning_T002_ErrorMessages
extends SensorHelper {

	@Test
	public void test_SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State() throws Exception {

		/**
		 * @stepId Pre-Condition Update the Time Format
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */
		startUp(client);
		setTheDateAndTime(client, 20, 03, 2018, "12:00");
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step1);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAUIRS1098
		 * @Expected Replace Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step2);
		openDebugDrawer(client);
		scanMockSensor(client,"TERMINATED");
		verifySensorDialogScreen(client,"error_sensor_terminated_title","error_sensor_terminated_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAUIRS1098
		 * @Expected App returns to Home screen, My glucose screen is not displayed On clicking OK with sensor ended
		 *           message
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step3);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
		closeDebugDrawer(client);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDASRS257
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step4);
		clickOnSettingsMenu(client, "help");
		navigateToSubMenuScreens(client,"eventLog");
		verifyEventLogContent(client,"error_sensor_terminated_title","error_sensor_terminated_msg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step5);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAUIRS1102
		 * @Expected Sensor Expired dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step6);
		openDebugDrawer(client);
		scanMockSensor(client,"EXPIRED");
		verifySensorDialogScreen(client,"error_sensor_expired_title","sensorExpiredContent");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAUIRS1102
		 * @Expected HomeScreen is displayed, My glucose screen is not displayed On clicking OK with sensor ended
		 *           message
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step7);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
	

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDASRS257
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step8);
		clickOnSettingsMenu(client, "help");
		navigateToSubMenuScreens(client,"eventLog");
		verifyEventLogContent(client,"sensorExpired","sensorExpiredContent");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step9);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAUIRS1106
		 * @Expected Check Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step10);
		openDebugDrawer(client);
		scanMockSensor(client,"INSERTION_FAILURE");
		verifySensorDialogScreen(client,"error_sensor_insertion_failure_title","error_sensor_insertion_failure_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAUIRS1102
		 * @Expected HomeScreen is displayed, My glucose screen is not displayed On clicking OK with sensor ended
		 *           message
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step11);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
		closeDebugDrawer(client);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDASRS257
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step12);
		clickOnSettingsMenu(client, "help");
		navigateToSubMenuScreens(client,"eventLog");
		verifyEventLogContent(client,"error_sensor_insertion_failure_title","error_sensor_insertion_failure_msg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step13);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAUIRS1107
		 * @Expected Replace Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step14);
		openDebugDrawer(client);
		scanMockSensor(client,"REMOVED");
		verifySensorDialogScreen(client,"error_sensor_removed_title","error_sensor_removed_msg");	
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAUIRS1107
		 * @Expected HomeScreen is displayed, My glucose screen is not displayed On clicking OK with sensor ended
		 *           message
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step15);
		clickOnButtonOption(client,"OK",true);
		closeDebugDrawer(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110", "mg", "dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2","mmol","L");
		}
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDASRS257
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State_Step16);
		clickOnSettingsMenu(client, "help");
		navigateToSubMenuScreens(client,"eventLog");
		verifyEventLogContent(client,"error_sensor_removed_title","error_sensor_removed_msg");	
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
	}

	
	
	
}
