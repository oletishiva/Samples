package com.abbott.project37375.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;

public class SensorScanning_T003_TransmissionError
extends SensorHelper {

	@Test
	public void test_T002_Mock1UI_TransmissionError_with_NFCApp_installed() throws Exception {

		/**
		 * @stepId Pre-Condition Install the other NFC app
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */

		installUninstallOtherNFCAPP(client, true);
		
		try {

			/**
			 * 
			 * @stepId Step 1
			 * @Reqt
			 * @Expected HomeScreen shows Ready to scan
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
		//	setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_TransmissionError_with_NFCApp_installed_Step1);
			changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		//	setTheTime(client, "12", "00");
			selectingSASMode(client, "MOCK_1");
			debugDrawerClearData(client);
			openDebugDrawer(client);
			addAndVerifyHistoricalAndRealtimeData(client);
					
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 2
			 * @Reqt SDAUISRS1097
			 * @Expected Transmission Error with other NFC app installed dialog
			 *           is displayed
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/

		//	setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_TransmissionError_with_NFCApp_installed_Step2);
			openDebugDrawer(client);
			scanMockSensor(client, "TRANSMISSION_ERROR");
			verifySensorScreenWithOtherNFCApp(client);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 3
			 * @Reqt SDAUISRS1097
			 * @Expected HomeScreen is displayed on clicking OK
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/

			//setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_TransmissionError_with_NFCApp_installed_Step3);
			clickOnButtonOption(client,"OK",true);
			capturescreenshot(client, getStepID(), true);
			closeDebugDrawer(client);

			/**
			 * 
			 * @stepId Step 4
			 * @Reqt SDAUSRS257
			 * @Expected Event log should display the error messages
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
		//	setStepID(LibrelinkConstants.SensorScanning_T002_Mock1UI_TransmissionError_with_NFCApp_installed_Step4);
			clickOnSettingsMenu(client, "help");
			navigateToSubMenuScreens(client,"eventLog");
			verifyEventLogContent(client, "error_sensor_corrupt_title","errorOtherNfcInstalled");
			capturescreenshot(client, getStepID(), true);

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			installUninstallOtherNFCAPP(client, true);
			launch(client);
			throw e;
		}

		
		startUp(client);

	}

}
