package com.abbott.project37375.notesAndlogbook;

import org.junit.Test;
import com.abbott.project37375.main.LibrelinkConstants;


public class Notes_T001_Adding_Remove_attributes extends NoteHelper {
	String logbookDate = null;

	@Test
	public void test_T001_Adding_Remove_attribute() throws Exception {


		/**
		 * 
		 * @stepId Pre Condition
		 * @Reqt
		 * @Expected Package Name need to be updated as per build and set the
		 *           time to current time
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setAndGetCarbUnit(client, "grams");
		loadTestData(client, "MOCK_2", "ADC",  "1dayLow2High.json");

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAUIRS893
		 * @Expected Add Note Page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step1);
		navigateToScreen(client, "Logbook");
		logbookDate = getCalendarDateForLogbook(client);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		createNewNote(client,00,30,null);
		verifyPageTitles(client, "Add Note");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAUIRS850
		 * @Expected The Note entry displayed the date and time of a Note
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step2);
		verifyAddNotePageDateTime(client,logbookDate,"00:30");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAUIRS897
		 * @Expected Verify The Note dialog provides a means to add the Food attribute
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step3);
		selectAndVerifyNoteAttribute(client, "cbox_food_note", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAUIRS898
		 * @Expected Breakfast, Lunch, Dinner or Snack options are displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step4);
		verifyFoodAttributeContent(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Breakfast
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step5);
		client.click("NATIVE", "xpath=//*[@id='text1' and @text='Breakfast']", 0, 1);
		setAndGetCarbAmount(client, "400");
		verifyFoodEntry(client, "Breakfast", "grams", "400");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAUIRS904
		 * @Expected The Note entry provides a means to add the Exercise
		 *           attribute of a note is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step6);
		selectAndVerifyNoteAttribute(client, "cbox_exercise_note", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAUIRS905
		 * @Expected Low, Medium , High Intensity are displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step7);
		verifyExerciseContents(client);
		capturescreenshot(client, getStepID(), true);
		client.click("NATIVE", "xpath=//*[@id='spinner_exercise_intensity']",0, 1);
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with exercise attribute Low intensity with
		 *           no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step8);
		addNoteForExercise(client, "lowIntensity", 0, 0);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "00:30");
		verifyFoodInLogBookDetailPage(client, "breakfast", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Lunch .
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step9);
		createNewNote(client,02,00,null);
		clickAndSetFoodAttribute(client, "lunch", "400");
		verifyFoodEntry(client, "Lunch", "grams", "400");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with exercise attribute Medium intensity																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														ity
		 *           with no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step10);
		addNoteForExercise(client, "mediumIntensity", 0, 0);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "02:00");
		verifyFoodInLogBookDetailPage(client, "lunch", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Dinner
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step11);
		createNewNote(client,3,30,null);
		clickAndSetFoodAttribute(client, "dinner", "400");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "03:30");
		verifyFoodInLogBookDetailPage(client, "dinner", "grams", "400");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected The Note edited with exercise attribute High intensity with
		 *           no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step12);
		clickCreatedNote(client, "03:30");
		editNotefromLogBookDetail(client);
		addNoteForExercise(client, "highIntensity", 0, 0);
		clickOnButtonOption(client, "Done", true);
		verifyFoodInLogBookDetailPage(client, "dinner", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAUIRS1134
		 * @Expected The Note can't created with food attribute 100.5 or
		 *           401grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step13_1);
		createNewNote(client,5,00,null);
		clickAndSetFoodAttribute(client, "snack", "401");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);

		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step13_2);
		clickAndSetFoodAttribute(client, "snack", "99.5");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "Cancel", true);
		waitFor(client, 2);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected New Note created with food attribute Snack 400 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step14);
		createNewNote(client,5,00,null);
		clickAndSetFoodAttribute(client, "snack", "400");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "05:00");
		verifyFoodInLogBookDetailPage(client, "snack", "grams", "400");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected Verify Min Carb amount 0 grams is set for Lunch
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step15);
		createNewNote(client,6,30,null);
		clickAndSetFoodAttribute(client, "lunch", "0");
		verifyFoodEntry(client, "Lunch", "grams", "0");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with exercise attribute Low '12' hrs '59'
		 *           mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step16);
		addNoteForExercise(client, "lowIntensity", 12, 59);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "06:30");
		verifyFoodInLogBookDetailPage(client, "lunch", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 12, 59);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected New Note created with food attribute Dinner 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step17);
		createNewNote(client,8,00,null);
		clickAndSetFoodAttribute(client, "dinner", "0");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "08:00");
		verifyFoodInLogBookDetailPage(client, "dinner", "grams", "0");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with exercise attribute Medium '12' hrs
		 *           '59' mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step18);
		editNotefromLogBookDetail(client);
		addNoteForExercise(client, "mediumIntensity", 12, 59);
		clickOnButtonOption(client, "Done", true);
		verifyFoodInLogBookDetailPage(client, "dinner", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 12, 59);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAUIRS1134
		 * @Expected The Note can't created with food attribute 100.5 or
		 *           401grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step19_1);
		createNewNote(client,9,30,null);
		clickAndSetFoodAttribute(client, "lunch", "401");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);

		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step19_2);
		clickAndSetFoodAttribute(client, "lunch", "99.5");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected New Note created with food attribute Snack 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step20);
		clickAndSetFoodAttribute(client, "snack", "0");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "09:30");
		verifyFoodInLogBookDetailPage(client, "snack", "grams", "0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with exercise attribute High '12' hrs '59'
		 *           mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step21);
		clickCreatedNote(client, "09:30");
		editNotefromLogBookDetail(client);
		addNoteForExercise(client, "highIntensity", 12, 59);
		clickOnButtonOption(client, "Done", true);
		verifyFoodInLogBookDetailPage(client, "snack", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 12, 59);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1134
		 * @Expected New Note created with food attribute Breakfast 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step22);
		createNewNote(client,11,00,null);
		clickAndSetFoodAttribute(client, "breakfast", "0");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "11:00");
		verifyFoodInLogBookDetailPage(client, "breakfast", "grams", "0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 23
		 * @Reqt SDAUIRS902
		 * @Expected Long-Acting Insulin attribute cab be selected from note entry.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step23);
		createNewNote(client,13,30,null);
		selectAndVerifyNoteAttribute(client, "cbox_slow_insulin_note", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 24
		 * @Reqt SDAUIRS900
		 * @Expected Note entry provides a means to add the Rapid-Acting Insulin
		 *           attribute of a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step24);
		unSelectNoteAttribute(client, "cbox_slow_insulin_note");
		selectAndVerifyNoteAttribute(client, "cbox_fast_insulin_note", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 25
		 * @Reqt SDAUIRS849_SDAUIRS901_SDAUIRS1201
		 * @Expected New Note created with Rapid-Acting Insulin attribute 0.1
		 *           units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step25);
		addNoteForInsulin(client,"Rapid", "0.1");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "13:30");
		verifyInsulinLogBookDetailPage(client, "Rapid", "0.1");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 26
		 * @Reqt SDAUIRS849_SDAUIRS901_SDAUIRS903_SDAUIRS1201_SDAUIRS1202
		 * @Expected New Note created with both Insulin attribute 200 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step26);
		createNewNote(client,15,00,null);
		selectNoteAttribute(client, "cbox_fast_insulin_note");
		addNoteForInsulin(client,"Rapid", "200");
		selectNoteAttribute(client, "cbox_slow_insulin_note");
		addNoteForInsulin(client,"Long", "200");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "15:00");
		verifyInsulinLogBookDetailPage(client, "Rapid", "200");
		verifyInsulinLogBookDetailPage(client, "Long", "200");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 27
		 * @Reqt SDAUIRS901_SDAUIRS903_SDAUIRS1201_SDAUIRS1202
		 * @Expected New Note created with both Insulin attribute 199.9 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step27);
		createNewNote(client,16,30,null);
		selectNoteAttribute(client, "cbox_fast_insulin_note");
		addNoteForInsulin(client,"Rapid", "199.9");
		selectNoteAttribute(client, "cbox_slow_insulin_note");
		addNoteForInsulin(client,"Long", "199.9");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "16:30");
		verifyInsulinLogBookDetailPage(client, "Rapid", "199.9");
		verifyInsulinLogBookDetailPage(client, "Long", "199.9");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 28
		 * @Reqt SDAUIRS903 SDAUIRS1202
		 * @Expected New Note created with Long-Acting Insulin attribute 0.1
		 *           unit
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step28);
		createNewNote(client,18,00,null);
		selectNoteAttribute(client, "cbox_slow_insulin_note");
		addNoteForInsulin(client,"Long", "0.1");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "18:00");
		verifyInsulinLogBookDetailPage(client, "Long", "0.1");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 29
		 * @Reqt SDAUIRS901_SDAUIRS903_SDAUIRS1201_SDAUIRS1202
		 * @Expected The Note can't be created with Insulin attribute '0' ,
		 *           '200.1', '5.01'
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_1);
		createNewNote(client,18,00,null);
		selectNoteAttribute(client, "cbox_slow_insulin_note");
		addNoteForInsulin(client,"Long", "0");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_2);
		addNoteForInsulin(client,"Long", "200.1");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_3);
		addNoteForInsulin(client,"Long", "5.01");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_4);
		unSelectNoteAttribute(client, "cbox_slow_insulin_note");
		selectNoteAttribute(client, "cbox_fast_insulin_note");
		addNoteForInsulin(client,"Rapid", "0");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_5);
		addNoteForInsulin(client,"Rapid", "200.1");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_6);
		addNoteForInsulin(client,"Rapid", "5.01");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "Cancel", true);

		/**
		 * 
		 * @stepId Step 30
		 * @Reqt SDAUIRS1179
		 * @Expected Rapid-Acting Insulin attribute is removed from the edited note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step30);
		clickCreatedNote(client, "15:00");
		editNotefromLogBookDetail(client);
		unSelectNoteAttribute(client, "cbox_fast_insulin_note");
		clickOnButtonOption(client, "Done", true);
		verifyInsulinLogBookDetailPage(client, "Long", "200");
		verifyInsulinNotFound(client, "Rapid", "200");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 31
		 * @Reqt SDAUIRS1180
		 * @Expected Long-Acting Insulin attribute from note is removed from the edited note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step31);
		clickCreatedNote(client, "16:30");
		editNotefromLogBookDetail(client);
		unSelectNoteAttribute(client, "cbox_slow_insulin_note");
		clickOnButtonOption(client, "Done", true);
		verifyInsulinLogBookDetailPage(client, "Rapid", "199.9");
		verifyInsulinNotFound(client, "Long", "199.9");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 32
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with food attribute Lunch 0 svg(or ptn for UK) and with
		 *           Exercise attribute High Intensity 2 hrs
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step32);
		setAndGetCarbUnit(client, "servings");
		navigateToScreen(client, "Logbook");
		createNewNote(client,20,00,null);
		clickAndSetFoodAttribute(client, "lunch", "0");
		addNoteForExercise(client, "highIntensity", 2, 0);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "20:00");
		verifyFoodInLogBookDetailPage(client, "lunch", "servings", "0.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 2, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 33
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with food attribute Breakfast 0 svg(or ptn for UK) and
		 *           with Exercise attribute Medium 1 hour
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step33);
		createNewNote(client,21,30,null);
		clickAndSetFoodAttribute(client, "breakfast", "0");
		addNoteForExercise(client, "mediumIntensity", 1, 0);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "21:30");
		verifyFoodInLogBookDetailPage(client, "breakfast", "servings", "0.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 1, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 34
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with food attribute Snack 0 svg(or ptn for UK) and with
		 *           Exercise attribute Low 12 hrs
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step34);
		createNewNote(client,23,30,null);
		clickAndSetFoodAttribute(client, "snack", "0");
		addNoteForExercise(client, "lowIntensity", 12, 0);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "23:30");
		verifyFoodInLogBookDetailPage(client, "snack", "servings", "0.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 12, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 35
		 * @Reqt SDAUIRS850
		 * @Expected The Note entry displays today at 23:00
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step35);
		logbookDate = getCalendarDateForLogbook(client);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		createNewNote(client,23,00,null);
		verifyPageTitles(client, "Add Note");
		verifyAddNotePageDateTime(client, logbookDate, "23:00");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 36
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135
		 * @Expected _New Note created with food attribute Dinner 0 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step36);
		clickAndSetFoodAttribute(client, "dinner", "0");
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "23:00");
		verifyFoodInLogBookDetailPage(client, "dinner", "servings", "0.0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 37
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135
		 * @Expected The Note can't created with food attribute '0.4' , '40.1',
		 *           '40.5' servings(or portions for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_1);
		createNewNote(client,23,30,null);
		clickAndSetFoodAttribute(client, "breakfast", "0.4");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_2);
		clickAndSetFoodAttribute(client, "breakfast", "40.5");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_3);
		clickAndSetFoodAttribute(client, "breakfast", "40.1");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_4);
		clickAndSetFoodAttribute(client, "dinner", "0.4");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_5);
		clickAndSetFoodAttribute(client, "dinner", "40.5");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_6);
		clickAndSetFoodAttribute(client, "dinner", "40.1");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "Cancel", true);

		/**
		 * 
		 * @stepId Step 38
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905 SDAUIRS906
		 * @Expected New Note created with food attribute Lunch 40 svg(or ptn for UK) & with
		 *           Exercise attribute High 1 min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step38);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "21:30");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "lunch", "40");
		addNoteForExercise(client, "highIntensity", 0, 1);
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "21:30");
		verifyFoodInLogBookDetailPage(client, "lunch", "servings", "40.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 0, 1);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 39
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with food attribute Dinner 40 svg(or ptn for UK) & with
		 *           Exercise attribute medium 59 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step39);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "15:00");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "dinner", "40");
		addNoteForExercise(client, "mediumIntensity", 0, 59);
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "15:00");
		verifyFoodInLogBookDetailPage(client, "dinner", "servings", "40.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 0, 59);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 40
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135_SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with food attribute Snack 40 svg(or ptn for UK) and with
		 *           Exercise attribute Low 11 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step40);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "13:59");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "snack", "40");
		addNoteForExercise(client, "lowIntensity", 0, 11);
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "13:59");
		verifyFoodInLogBookDetailPage(client, "snack", "servings", "40.0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 0, 11);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 41
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135
		 * @Expected New Note created with food attribute Breakfast 40 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step41);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "18:30");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "breakfast", "40");
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "18:30");
		verifyFoodInLogBookDetailPage(client, "breakfast", "servings", "40.0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 42
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135
		 * @Expected New Note created with food attribute Breakfast 10.5 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step42);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "breakfast", "10.5");
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "11:30");
		verifyFoodInLogBookDetailPage(client, "breakfast", "servings", "10.5");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 43
		 * @Reqt SDAUIRS894_SDAUIRS907
		 * @Expected Note at 11:30 is edited with Comment of 256 characters 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step43);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		editNotefromLogBookDetail(client);
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		clickOnButtonOption(client, "Done", true);
		verifyNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 44
		 * @Reqt SDAUIRS899_SDAUIRS848_SDAUIRS1135
		 * @Expected New Note created with food attribute Lunch 39.5 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step44);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "07:59");
		editNotefromLogBookDetail(client);
		clickAndSetFoodAttribute(client, "lunch", "39.5");
		clickOnButtonOption(client, "Done", true);
		clickOnBackOrMenuIcon(client);
		clickCreatedNote(client, "07:59");
		verifyFoodInLogBookDetailPage(client, "lunch", "servings", "39.5");
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 45
		 * @Reqt SDAUIRS907
		 * @Expected Note at 7:59 is edited with Comment including 256 characters 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step45);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "07:59");
		editNotefromLogBookDetail(client);
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS + "A");
		clickOnButtonOption(client, "Done", true);
		verifyNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 46
		 * @Reqt SDAUIRS907
		 * @Expected Comment with special characters displayed in the
		 *           Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step46);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "03:59");
		editNotefromLogBookDetail(client);
		scrollToBottomAddNotePage(client);
		enterNotesComments(client, LibrelinkConstants.SPL_COMMENTS);
		clickOnButtonOption(client, "Done", true);
		verifyNotesComments(client, LibrelinkConstants.SPL_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);


		/**
		 * 
		 * @stepId Step 47
		 * @Reqt SDAUIRS893
		 * @Expected The Logbook List View provides a means to invoke the Note
		 *           entry feature to add a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step47);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		createNewNote(client,3,00,null);
		verifyPageTitles(client, "Add Note");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 48
		 * @Reqt SDAUIRS907
		 * @Expected Comment with numbers, upper case, lower case characters,
		 *           spaces, 3 Line returns displayed in the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step48);
		//TODO
		/*enterNotesComments(client, LibrelinkConstants.NEW_LINE_COMMENTS);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "03:00");
		verifyNotesComments(client, LibrelinkConstants.NEW_LINE_COMMENTS_SPACE);
		capturescreenshot(client, getStepID(), true);
		clickOnBackOrMenuIcon(client);*/

		/**
		 * 
		 * @stepId Step 49
		 * @Reqt SDAUIRS1178
		 * @Expected The Food attribute of the edited note(11:30) is removed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step49);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		capturescreenshot(client, getStepID().replace("Step49", "Step49.1")+"_Before Removing Food attribute", true);
		editNotefromLogBookDetail(client);
		unSelectNoteAttribute(client, "cbox_food_note");
		clickOnButtonOption(client, "Done", true);
		verifyNoFoodInLogBookDetailPage(client, "Food");
		capturescreenshot(client, getStepID().replace("Step49", "Step49.2"), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 50
		 * @Reqt SDAUIRS1181
		 * @Expected The Exercise attribute of the edited note(21:30) is removed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step50);
		clickCalanderRightButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		clickCreatedNote(client, "21:30");
		capturescreenshot(client, getStepID().replace("Step50", "Step50.1")+"_Before Removing Exercise attribute", true);
		editNotefromLogBookDetail(client);
		unSelectNoteAttribute(client, "cbox_exercise_note");
		clickOnButtonOption(client, "Done", true);
		verifyExerciseIntensityRemovedInLogBookDetailPage(client, "Medium");
		capturescreenshot(client, getStepID().replace("Step50", "Step50.2"), true);
		clickOnBackOrMenuIcon(client);

		/**
		 * 
		 * @stepId Step 51
		 * @Reqt SDAUIRS905_SDAUIRS906
		 * @Expected New Note created with High Intensity 1 hr and 1 min at 23:30
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step51);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		createNewNote(client,23,00,null);
		addNoteForExercise(client, "highIntensity", 1, 1);
		clickOnButtonOption(client, "Done", true);
		clickCreatedNote(client, "23:00");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 1, 1);
		capturescreenshot(client, getStepID(), true);


		selectingSASMode(client, "DEFAULT");
		currentSystemTime(client);
	}


}
