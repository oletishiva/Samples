package com.abbott.project37375.firsttimestartupAndsettingsAndhelp;


import org.junit.Test;

import com.abbott.project37375.main.LibrelinkConstants;


public class Help_T002_Help_SendingTroubleShootingData extends HelpHelper {

	
	@Test
	public void test_T002_Help_SendingTroubleShooting() throws Exception {

		

	/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAUIRS1162
		 * @Expected Send Troubleshooting data link is displayed in Event Log
		 *           view
		 * @Dependancy NA
		 * 
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step1);
		clearData(client);
		selectNetworkMode(client, "Use Real Servers");
		createDefaultAccount(client,"Adult");
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		scanMockSensor(client,"TERMINATED");
		clickOnButtonOption(client,"OK",true);
		clickOnSettingsMenu(client, "Help");
		navigateToSubMenuScreens(client,"Event Log");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAUIRS1162
		 * @Expected Send Troubleshooting data view is displayed with 'View
		 *           Privacy notice', 'Agree' and 'Decline' buttons.
		 * @Dependancy NA
		 * 
		 **/
		
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step2);
		clickOnButtonOption(client, "Send Troubleshooting Data", true);
		verifyTroubleshootingDataPage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 3
		 * @Reqt SDAUIRS1162
		 * @Expected App returns to 'Event Log' screen entered.
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step3);
		clickOnButtonOption(client, "Decline", true);
		verifyPageTitles(client, "Event Log");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAUIRS1162
		 * @Expected Privacy Notice screen displayed.
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step4);
		clickOnButtonOption(client, "Send Troubleshooting Data", true);
		clickOnButtonOption(client, "View Privacy Notice", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 5
		 * @Reqt SDAUIRS1162,SDASRS1172,SDASRS1181
		 * @Expected Error message 'Incorrect case number or verification code'
		 *           pop up screen.
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step5);
		clickOnBackOrMenuIcon(client);
		clickOnButtonOption(client, "Agree", true);
		verifySendTroubleshootingDataPage(client);
		sendTroubleshootingDataPage(client, "12345678", "87654321");
		verifyTroubleshootingError(client,"logUploadErrorTypo");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 6
		 * @Reqt SDAUIRS1162,SDASRS1172,SDASRS1181
		 * @Expected Error message 'Incorrect case number or verification code'
		 *           pop up screen.
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step6);
		sendTroubleshootingDataPage(client, "12345678", "45326785");
		verifyTroubleshootingError(client,"logUploadErrorTypo");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 7
		 * @Reqt SDAUIRS1162,SDASRS1172,SDASRS1181
		 * @Expected Error message 'Incorrect case number or verification code'
		 *           pop up screen.
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step7);
		sendTroubleshootingDataPage(client, "44335566", "87654321");
		verifyTroubleshootingError(client,"logUploadErrorTypo");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 8
		 * @Reqt SDAUIRS1162,SDASRS1172,SDASRS1181
		 * @Expected notification 'Error Sending Troubleshooting... Tap to
		 *           retry' is triggered
		 * 
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step8);
		setNetworkData(client, "off");
		sendTroubleshootingDataPage(client, "44335566", "45326785");
		waitFor(client,5);
		verifyErrorSendingNotification(client, false);
		capturescreenshot(client, getStepID(), true);
		closeNotification(client);

		/**
		 *
		 * @stepId Step 9
		 * @Reqt SDAUIRS1162,SDAUIRS1183
		 * @Expected The troubleshooting data are sent to server
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.Help_T002_Help_SendingTroubleShootingData_Step9);
		setNetworkData(client, "on");
		clearData(client);
		selectNetworkMode(client, "Use Real Servers");
		defaultsignIn(client, getEmail(),LibrelinkConstants.CURRENT_PASSWORD);
		clickOnSettingsMenu(client, "Help");
		navigateToSubMenuScreens(client,"Event Log");
		clickOnButtonOption(client, "Send Troubleshooting Data", true);
		clickOnButtonOption(client, "Agree", true);
		sendTroubleshootingDataPage(client, "44335566", "45326785");
		waitFor(client,5);
		verifyPageTitles(client, "Event Log");
		capturescreenshot(client, getStepID(), true);


		
	}
}
