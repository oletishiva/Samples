package com.abbott.project37375.firsttimestartupAndsettingsAndhelp;

import org.junit.Assert;

import com.abbott.project37375.main.BaseHelper;
import com.experitest.client.Client;

public class HelpHelper extends BaseHelper {


	/**
	 * Author: Ilangovan 
	 * 
	 * Verify Application Version
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */

	public void verifyApplicationVersion(Client client) {

		client.verifyElementFound("NATIVE", "xpath=//*[@text='Software Version:']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@id='softwareVersion'] ", 0);
		String appversion = client.elementGetText("NATIVE","xpath=//*[@id='softwareVersion']", 0);
		Assert.assertEquals(appversion.replace("-", "."),getAppversion().replace("-", "."));
	}


	/**
	 * Author: Ilangovan 
	 * 
	 * Verify UDI information
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyUDI(Client client) {

		if (getCountryCode().equals("United States")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@id='udiLabel' and @onScreen='true']", 0);
			String appUdi= client.elementGetText("NATIVE", "xpath=//*[@id='udiValue' and @onScreen='true']", 0).replaceAll("\\s", "");
			Assert.assertEquals(appUdi.replace("-", "."),getAppudi().replace("-", "."));
		} else if (getCountryCode().equals("United Kingdom")) {
			client.verifyElementNotFound("NATIVE",  "xpath=//*[@text='UDI:' and @onScreen='true']", 0);

		}
	}

	/**
	 * Author: Ilangovan 
	 * 
	 * Verify CE and Website Information
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyCEWebSite(Client client) {

		if (getCountryCode().equals("United States")) {
			client.swipeWhileNotFound("Down", 100, 500, "NATIVE", "xpath=//*[@id='ceMark' and @onScreen='true']", 0, 1000, 5, true);
			client.verifyElementNotFound("NATIVE", "xpath=//*[@id='ceMark' and @onScreen='true']", 0);
		} else if (getCountryCode().equals("United Kingdom")) {
			client.swipeWhileNotFound("Down", 100, 500, "NATIVE", "xpath=//*[@id='ceMark' and @onScreen='true']", 0, 1000, 5, true);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='CELogo' and @onScreen='true']", 0);

		}
		client.verifyElementFound("NATIVE", "xpath=//*[@id='customerSupport' and @text='"+getLangPropValue("supportWebsiteValue")+"']", 0);
		client.verifyElementFound("NATIVE", "text=${patentWebsiteLabel}", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"+getLangPropValue("patentWebsiteValue")+"' and @onScreen='true']", 0);
		client.click("NATIVE", "xpath=//*[@id='customerSupport' and @text='"+getLangPropValue("supportWebsiteValue")+"']", 0, 1);
		waitFor(client,2);
	}


	/**
	 * Author: Ilangovan 
	 * 
	 * verify user's manual Guide
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyUsersManualGuide(Client client) {	
		waitForProgress(client);
		client.waitForElementToVanish("NATIVE","text=${helpItemTitleUserGuide}",0, 80000);
		waitFor(client,30);
		client.verifyElementFound("NATIVE", "text=${helpItemTitleUserGuide}", 0);

	}


	/**
	 * Author: Ilangovan
	 * 
	 * Verify How to Apply new sensor steps
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyHowToApplyNewSensorSteps(Client client) {
		client.waitForElement("NATIVE", "text=${applySensorTextStep1}", 0, 1000);
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep1}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep1}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep2}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep2}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep3}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep3}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep4}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep4}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep5}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep5}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep6}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep6}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep7}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep7}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep8}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep8}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep9}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep9}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep10}", 0);
		client.verifyElementFound("NATIVE", "text=${applySensorTextStep10}", 0);

	}



	/**
	 * Author: Ilangovan
	 * 
	 * Verify  How to Scan a sensor Pages
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyHowToScanSensorPages(Client client) {
		client.waitForElement("NATIVE", "text=${scanSensorTitle}", 0, 10000);
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep1}", 0);
		client.verifyElementFound("NATIVE", "text=${scanSensorTextStep1}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep2}", 0);
		client.verifyElementFound("NATIVE", "text=${scanSensorTextStep2}", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep3}", 0);
		client.verifyElementFound("NATIVE", "text=${scanSensorTextStep3}", 0);
	}
	

		/**
		 * Author: Ilangovan
		 * 
		 * Verify Troubleshooting Data PAge
		 * @param client


		 */

		public void verifyTroubleshootingDataPage(Client client) {
			client.waitForElement("NATIVE","text=Sending troubleshooting data helps Customer Service answer your questions.",0, 10000);
			client.verifyElementFound("NATIVE","text=The Privacy Notice you previously accepted describes what troubleshooting data includes.",0);
			client.verifyElementFound("NATIVE",	"text=Do you agree to send your troubleshooting data?", 0);
			client.verifyElementFound("NATIVE", "text=View Privacy Notice", 0);
			client.verifyElementFound("NATIVE", "text=Decline", 0);
			client.verifyElementFound("NATIVE", "text=Agree", 0);
		}


		
		/**
		 * Author: Ilangovan
		 * 
		 * Verify Librelink Event log Screen
		 * @param client


		 */
		public void verifyEventLogScreen(Client client) {
			client.verifyElementFound("NATIVE", "text=Event Log", 0);

		}
		
		
		/**
		 * Author: Ilangovan
		 * 
		 * Verify Send Troubleshooting Data PAge
		 * @param client


		 */
		public void verifySendTroubleshootingDataPage(Client client)
		{
			client.verifyElementFound("NATIVE","text=Please enter the case number and verification code provided by Customer Service.",0);
			client.verifyElementFound("NATIVE", "text=Case Number", 0);
			client.verifyElementFound("NATIVE", "text=Verification Code", 0);
			client.verifyElementFound("NATIVE", "text=Send", 0);

		}

		/**
		 * Author: Ilangovan
		 * 
		 * Send Troubleshooting Data PAge
		 * @param client

		 * @param CN
		 *            enter the case number
		 * @param VC
		 *            enter the verification Code

		 */
		public void sendTroubleshootingDataPage(Client client, String CN, String VC)
		{

			client.click("NATIVE", "id=case_number", 0, 1);

			client.elementSendText("NATIVE", "id=case_number", 0, CN);
			client.click("NATIVE", "id=access_code", 0, 1);
			client.elementSendText("NATIVE", "id=access_code", 0, VC);
			client.closeKeyboard();
			client.click("NATIVE", "text=Send", 0, 1);


		}

		/**
		 * Author: Ilangovan
		 * 
		 * Verify Troubleshooting error
		 * @param client


		 */
		public void verifyTroubleshootingError(Client client,String ErrorVerification) {
			client.verifyElementFound("NATIVE","text=${"+ErrorVerification+"}",0);
			client.closeKeyboard();

		}
		/**
		 * Author: Ilangovan
		 * 
		 * Turn on/off Network Data
		 * @param client

		 * @param mode
		 *            set the on /off mode

		 */
		public void setNetworkData(Client client, String mode) {
				if (mode.equalsIgnoreCase("on")) {
				if (getDeviceOSVer().contains("7.")) {
					client.run("adb shell su -c 'svc wifi enable'");
				}else{
					client.run("adb shell settings put global airplane_mode_on 0");
					client.run("adb shell am broadcast -a android.intent.action.AIRPLANE_MODE");
					
				}
				client.sleep(30000);

			}
			if (mode.equalsIgnoreCase("Off")) {
				if (getDeviceOSVer().contains("7.")) {
					client.run("adb shell su -c 'svc wifi disable'");
				}else{
					client.run("adb shell settings put global airplane_mode_on 1");
					client.run("adb shell am broadcast -a android.intent.action.AIRPLANE_MODE");
					
				}

			}
			client.sleep(30000);

		}

		/**
		 * Author: Ilangovan
		 * 
		 * Verify Error Sending Notification
		 * 
		 * @param client
		 */
		public void verifyErrorSendingNotification(Client client, boolean clickMsg) {
			client.sendText("{NOTIFICATION}");
			client.verifyElementFound("TEXT", "Error Sending Troubleshoot", 0);
			client.verifyElementFound("TEXT", "Tap to retry.", 0);
			client.click("TEXT","Tap to retry.", 0, 1);
			navigateToSubMenuScreens(client,"eventLog");
		}
		
		
	
		
		/**
		 * Author: Ilangovan
		 * 
		 * Method to Startup to navigate to HomeScreen
		 * 
		 * @param client
		 *            Integrate SeeTestAutomation
		 * 
		 * @param email
		 *            Enter email
		 * @param pwd
		 *            Enter Password
		 */
		public void defaultsignIn(Client client, String email, String pwd) {
			signInClick(client, email, pwd, true);
			clickOnButtonOption(client, "OK", true);
			termsOfPageAndPrivacyNoticeAccept(client,"Terms of Use");
			termsOfPageAndPrivacyNoticeAccept(client,"Privacy Notice");
			defaultSettings(client, "grams");			
		}


}
