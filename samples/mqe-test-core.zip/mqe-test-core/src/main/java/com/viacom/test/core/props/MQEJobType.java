package com.viacom.test.core.props;

public enum MQEJobType {
	
  CHROME ("chrome"),
  FIREFOX ("firefox"),
  SAFARI ("safari"),
  IEXPLORE ("internet explorer"),
  EDGE ("MicrosoftEdge");

  private final String value;

  private MQEJobType(String value) {
    this.value = value;
  }

  public String value() {
    return value;
  }
  
}
