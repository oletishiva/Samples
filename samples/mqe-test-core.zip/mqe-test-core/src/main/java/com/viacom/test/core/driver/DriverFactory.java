package com.viacom.test.core.driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.ServerSocket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.lightbody.bmp.BrowserMobProxyServer;

import org.littleshoot.proxy.HttpFiltersSource;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;

import com.viacom.test.core.browserstack.BrowserstackCredentialManager;
import com.viacom.test.core.browserstack.BrowserstackTunnelsManager;
import com.viacom.test.core.lab.ActiveBrowserManager;
import com.viacom.test.core.lab.ActiveDeviceManager;
import com.viacom.test.core.lab.AvailableDevicePoller;
import com.viacom.test.core.lab.GlobalAbort;
import com.viacom.test.core.lab.GlobalInstall;
import com.viacom.test.core.lab.GridManager;
import com.viacom.test.core.lab.LabDeviceManager;
import com.viacom.test.core.lab.TestDeviceInfo;
import com.viacom.test.core.props.BrowserType;
import com.viacom.test.core.props.DesktopOSType;
import com.viacom.test.core.props.DeviceCategory;
import com.viacom.test.core.props.MobileOS;
import com.viacom.test.core.proxy.ProxyManager;
import com.viacom.test.core.sauce.SauceCredentialManager;

import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.RandomData;
import com.viacom.test.core.util.TestRun;

public class DriverFactory {

	// DRIVERS
	private static ThreadLocal<RemoteWebDriver> webDriver = new ThreadLocal<RemoteWebDriver>();
    private static ThreadLocal<AppiumDriver<MobileElement>> appiumDriver = new ThreadLocal<AppiumDriver<MobileElement>>();
    private static ThreadLocal<AndroidDriver<MobileElement>> androidDriver = new ThreadLocal<AndroidDriver<MobileElement>>();
    private static ThreadLocal<IOSDriver<MobileElement>> iOSDriver = new ThreadLocal<IOSDriver<MobileElement>>();
    
    // ACTIVE DEVICE
    private static List<String> allDevices = new ArrayList<String>();
    private static ThreadLocal<MobileOS> activeMobileOS = new ThreadLocal<MobileOS>();
    private static ThreadLocal<String> activeBrowser = new ThreadLocal<String>();
    private static ThreadLocal<BrowserType> activeBrowserType = new ThreadLocal<BrowserType>();
    private static ThreadLocal<DesktopOSType> activeDesktopOSType = new ThreadLocal<DesktopOSType>();
    private static ThreadLocal<String> activeMobileOSVersion = new ThreadLocal<String>();
    private static ThreadLocal<DeviceCategory> activeDeviceCategory = new ThreadLocal<DeviceCategory>();
    private static ThreadLocal<String> activeDeviceID = new ThreadLocal<String>();
    private static ThreadLocal<String> activeMachineIP = new ThreadLocal<String>();
    private static ThreadLocal<String> activeMachineName = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceName = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceProxyPort = new ThreadLocal<String>();
    private static ThreadLocal<String> activeAppPackage = new ThreadLocal<String>();
    private static ThreadLocal<Boolean> resetDeviceNode = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return true;
    	}
    };
    
    private static ThreadLocal<List<HttpFiltersSource>> filters = new ThreadLocal<List<HttpFiltersSource>>() {
    	protected List<HttpFiltersSource> initialValue() {
    		return null;
    	}
    };
    
    private static ThreadLocal<Boolean> specificDevice = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    
    private static ThreadLocal<Boolean> checkProxyLogsOnStartup = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    
    private static ThreadLocal<Boolean> labAppInstallOnStartup = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    private static ThreadLocal<Boolean> installOnTest = new ThreadLocal<Boolean>();
    private static ThreadLocal<String> installAppPackageID = new ThreadLocal<String>();
    
    private static ThreadLocal<Integer> localDebugProxyPort = new ThreadLocal<Integer>() {
    	protected Integer initialValue() {
    		return null;
    	}
    };
    private static Set<String> unHealthyDevices = new HashSet<String>();
    
    /**********************************************************************************************
     * Initiates a new instance of Remote WebDriver.
     * 
     * @param capabilities - {@link DesiredCapabilities} - The capability object of the desired webdriver session.
     * @author Brandon Clark created February 1, 2016
     * @version 1.3 June 6, 2016
     ***********************************************************************************************/
    public static void initiateWebDriver(DesiredCapabilities capabilities) {
    	TestRun.setMobile(false);
    	
    	// get the hub url and set the appropriate runtime environment (Sauce, Browserstack, QA Lab)
    	getHubAddress();
    	if (TestRun.isLabRun() && GridManager.isQALabHub()) {
    		Boolean sessionSuccess = false;
    		
    		// clear out any version capability passed in
    		capabilities.setVersion("");
    		
    		// set the browser info
    		activeBrowser.set(capabilities.getBrowserName());
			// set the browser type
			if (activeBrowser.get().toLowerCase().contains("explorer")) {
				activeBrowserType.set(BrowserType.IEXPLORE);
			} else if (activeBrowser.get().toLowerCase().contains("edge")) {
				activeBrowserType.set(BrowserType.EDGE);
			} else if (activeBrowser.get().toLowerCase().contains("firefox")) {
				activeBrowserType.set(BrowserType.FIREFOX);
			} else if (activeBrowser.get().toLowerCase().contains("chrome")) {
				activeBrowserType.set(BrowserType.CHROME);
			} else if (activeBrowser.get().toLowerCase().contains("safari")) {
				activeBrowserType.set(BrowserType.SAFARI);
			}
			
			// Set the desktop os type
			String platform = capabilities.getPlatform().toString().toLowerCase();
			if (platform.contains("mac")) {
				activeDesktopOSType.set(DesktopOSType.MAC);
			} else if (platform.contains("win")) {
				activeDesktopOSType.set(DesktopOSType.WINDOWS);
			}
			
    		for (int farmIter = 0; farmIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; farmIter++) {
    			if (capabilities.getCapability(Constants.MACHINE_NAME) == null 
    					|| capabilities.getCapability(Constants.MACHINE_NAME) == "") {
    				 // no specific device identified by the user grab one from the farm
    				
        			synchronized (DriverFactory.class) {
        				List<String> allMachines = LabDeviceManager.getAllMachineIPAddresses();
        				Set<String> allInactiveMachines = ActiveBrowserManager.getInactiveBrowserNodes();
        				
        				// fail the tests if the execution has taken a significant number of previously healthy machines down
        				if (allInactiveMachines.size() >= Constants.INACTIVE_DEVICE_MAX) {
        					throw new RuntimeException("Too many unhealthy machines!");
        				}
        				
        				while (capabilities.getCapability(CapabilityType.VERSION) == "") {
        					for (String machineIP : allMachines) {
            					// set the active machine info
        						activeMachineIP.set(machineIP);
            					activeMachineName.set(LabDeviceManager.getMachineName(activeMachineIP.get()));
        	        	    	
        	        	    	// is the machine active/enabled on the farm
    	        	    		if (LabDeviceManager.isMachineNodeActive(activeMachineIP.get())) {
    	        	    			// does the machine node match the requested os
    	        	    			if (LabDeviceManager.getMachineOSType(activeMachineIP.get()).equals(activeDesktopOSType.get())) {
    	        	    				// does the machine node have the requested browser type
    	        	    				if (LabDeviceManager.hasBrowserNodeType(activeMachineIP.get(), activeBrowserType.get())) {
    	        	    					// is the browser node active/enabled
    	        	    					if (LabDeviceManager.isBrowserNodeActive(activeMachineIP.get())) {
    	        	    						// is the node currently in use
                        						if (!LabDeviceManager.isBrowserNodeInUse(activeMachineIP.get(), activeBrowserType.get())) {
                        							// is the machine currently active in the test session
                        							if (!allInactiveMachines.contains(activeMachineIP.get())) { 
                        								// BROWSER NODE AVAILABLE FOR TEST
                                						ActiveBrowserManager.setActiveBrowserNode(activeMachineIP.get(), activeBrowserType.get());
                                        	        	capabilities.setCapability(CapabilityType.VERSION, activeMachineName.get().replace("_", "-") + ".local");
                                        	        	ActiveBrowserManager.setActiveBrowserNode(activeMachineIP.get(), activeBrowserType.get());
                                        	        	LabDeviceManager.setBrowserNodeInUse(activeMachineIP.get(), activeBrowserType.get(), true);
                                        	        	break;
                        							}
                            	        	    }
    	        	    					}
    	        	    				}
    	        	    			}
            					}
            	        	}
        					
        					// TODO poller logic goes here
        				}
        			}
            	} else {
            		// specific machine identified by the user!
            		activeMachineName.set(capabilities.getCapability(Constants.MACHINE_NAME).toString());
        			activeMachineIP.set(LabDeviceManager.getMachineIP(activeMachineName.get()));
        			
        	    	// check if the requested browser node is in use and poll until available
        	    	while (LabDeviceManager.isBrowserNodeInUse(activeMachineIP.get(), activeBrowserType.get()) ) {
        	    		// TODO poller logic goes here
        	    	}
        	    	
        	    	ActiveBrowserManager.setActiveBrowserNode(activeMachineIP.get(), activeBrowserType.get());
    	        	capabilities.setCapability(CapabilityType.VERSION, activeMachineName.get().replace("_", "-") + ".local");
    	        	ActiveBrowserManager.setActiveBrowserNode(activeMachineIP.get(), activeBrowserType.get());
        			LabDeviceManager.setBrowserNodeInUse(activeMachineIP.get(), activeBrowserType.get(), true);
    	        	
            		specificDevice.set(true);
            	}
    			
        		for (int machineIter = 0; machineIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; machineIter++) {
        			// attempt to start a session
        			try {
        				// get an unused proxy port if the browser supports it
            			synchronized (DriverFactory.class) {
        					try {
            	            	ServerSocket serverSocket = new ServerSocket(0);
            	                activeDeviceProxyPort.set(String.valueOf(serverSocket.getLocalPort()));
            	                serverSocket.close();
            	            } catch (Exception e) {
            	                Logger.logConsoleMessage("Failed to generate proxy ports/tunnel identifiers.");
            	                e.printStackTrace();
            	            }
        				}
   
        				// start the proxy
        				ProxyManager.setProxyServer(Integer.parseInt(activeDeviceProxyPort.get()));
        				ProxyManager.startProxyServer();
        				try { Thread.sleep(1000); } catch (InterruptedException e) { }
            			
        				// assign the proxy in the browser (if the browser supports it)
        				if (activeBrowserType.equals(BrowserType.CHROME)) {
        					Proxy seleniumProxy = new Proxy();
            	            String serverAddress = Constants.LAB_WEBDRIVER_HUB_IP + ":" 
            				    + activeDeviceProxyPort.get();
            	            seleniumProxy.setHttpProxy(serverAddress).setSslProxy(serverAddress)
            	                .setFtpProxy(serverAddress);
            	            capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
        				} else {
        					// TODO these are instances where we will need to use proxifier and
        					// set the proxy by querying the node's assigned proxy port...
        				}
        				
            			// set any proxy rewrites prior to session startup
            			if (filters.get() != null) {
            				for (HttpFiltersSource filter : filters.get()) {
            					ProxyManager.getProxyServer().addHttpFilterFactory(filter);
                			}
            			}
            			
        				// start the session
            			webDriver.set(new RemoteWebDriver(new URL(getHubAddress()), capabilities));
                        DriverManager.setWebDriver(webDriver.get());
                        
            			// check machine network connectivity
            			if (checkProxyLogsOnStartup.get()) {
            				// TODO
            			}
            			
            			// command to verify driver is up and responding
            			DriverManager.getWebDriver().getWindowHandle();
            			
            			// set the browser node in use
            			Logger.logMessage("Webdriver session successfully created on '" + activeMachineName.get() + "'" 
                        		+ " for browser '" + activeBrowser.get() + "' on '" + activeMachineIP.get() + "'.");
                        sessionSuccess = true;
                        break;
                    } catch (Exception e) {
                    	e.printStackTrace();
                    	
                    	// stop the driver (if necessary)
                    	try {
                    		if (DriverManager.getWebDriver() != null) {
                        		if (DriverManager.getWebDriver().getSessionId() != null) {
                        			DriverManager.getWebDriver().quit();
                        		}
                        	}
                    	} catch (Exception e2) {
                    		Logger.logConsoleMessage("Failed to terminate driver.");
                    		e2.printStackTrace();
                    	}
                    	
                    	try {
							Thread.sleep(Constants.DRIVER_RECYLE_TIMEOUT_MS);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
                    	
                    	// if the user specified a specific machine don't perform multiple attempts
                    	if (specificDevice.get()) {
                    		break;
                    	}
                    	
                    	if (machineIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
                    		// unhealthy machine, remove from the active lab machine list
                    		Logger.logMessage("A session failed to be spun up on lab machine '" + activeMachineName.get() 
                    				+ "' with session ip '" + activeMachineIP.get() + "' for browser '" + activeBrowser.get() 
                    				+ "'. This machine has been removed from the active machine farm.");
                    		try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    		LabDeviceManager.setBrowserNodeInUse(activeMachineIP.get(), activeBrowserType.get(), false);
                    	} else {
                    		Logger.logMessage("Failed to start Webdriver session on attempt '" + machineIter 
                    			+ "' for machine '" + activeMachineName.get() + "' with ip '" + activeMachineIP.get() + "' for browser '" 
                    			+ activeBrowser.get() + "'. Retrying...");
                    		Logger.logMessage(e.getMessage());
                    		
                    		try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    		
                    		// kill the problematic machine node
                    		if (resetDeviceNode.get()) {
                    			/* TODO - multiple sessions on the same machine - can't just kill the node
                    			    research what we can implement here...
                        		*/
                    		} else {
                    			try { Thread.sleep(Constants.DRIVER_NODE_RECYLE_PAUSE_MS); } catch (InterruptedException e2) { }
                    		}
                    	}
                    }
        		}
    			
        		if (sessionSuccess || specificDevice.get()) {
    				break;
    			}
        		
        		if (farmIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
        			Logger.logConsoleMessage("FAILED TO START WEBDRIVER SESSION AFTER MULTIPLE ATTEMPTS ON MULTIPLE MACHINES!");
        		} else {
        			Logger.logConsoleMessage("Failed to start Webdriver session on lab machine '" + activeMachineName.get() + "' after multiple "
        				+ "attempts. Retrying on a different machine...");
        		} 
    		}
    	} else { // LOCAL TEST RUN OR CLOUD BASED WEB EXECUTION (sauce or browserstack)
    		try {
    			TestRun.setMobile(false);
    			if (!TestRun.isSauceRun()) {
    				if (localDebugProxyPort.get() != null) {
        				activeDeviceProxyPort.set(localDebugProxyPort.get().toString());
        			} else {
        				// get an unused proxy port
        				synchronized (DriverFactory.class) {
        					try {
            	            	ServerSocket serverSocket = new ServerSocket(0);
            	                activeDeviceProxyPort.set(String.valueOf(serverSocket.getLocalPort()));
            	                serverSocket.close();
            	            } catch (Exception e) {
            	                Logger.logConsoleMessage("Failed to generate proxy ports/tunnel identifiers.");
            	                e.printStackTrace();
            	            }
        				}
        			}
    				
    				// start the proxy
    				ProxyManager.initAllProxyServers(Arrays.asList(Integer.parseInt(activeDeviceProxyPort.get())));
    				ProxyManager.enableMITM();
    				ProxyManager.setProxyServer(Integer.parseInt(activeDeviceProxyPort.get()));
    				ProxyManager.startProxyServer();
    				try { Thread.sleep(1000); } catch (InterruptedException e) { }
    			}
		    	
    			if (TestRun.isBrowserstackRun()) {
    				// assign and start the tunnel
    				String tunnelID = RandomData.getCharacterString(50);
    				capabilities.setCapability("browserstack.local", "true");
    				capabilities.setCapability("browserstack.localIdentifier", tunnelID);
    				BrowserstackTunnelsManager.startTunnel(Integer.parseInt(activeDeviceProxyPort.get()), tunnelID);
    			}
    			
		    	// set the driver instance
		        webDriver.set(new RemoteWebDriver(new URL(getHubAddress()), capabilities));
		        DriverManager.setWebDriver(webDriver.get()); 
            } catch (Exception e) {
            	Logger.logConsoleMessage("Failed to spin up a Webdriver session.");
            	e.printStackTrace();
            } 
    	}
    }
    
    /**********************************************************************************************
     * Initiates a new instance of Appium driver and the corresponding iOSDriver or AndroidDriver
     * 
     * @param mobileOS - {@link MobileOS} - The device mobile OS (iOS or Android).
     * @param deviceCategory - {@link DeviceCategory} - The device category to run against (Phone or Tablet).
     * @param capabilities - {@link DesiredCapabilities} - The capability object of the desired appium session.
     * @author Brandon Clark created February 1, 2016
     * @version 1.4 November 28, 2016
     ***********************************************************************************************/
    public static void initiateAppiumDriver(MobileOS mobileOS, DeviceCategory deviceCategory, DesiredCapabilities capabilities) {
    	// set the mobile os and the device category
    	TestRun.setMobile(true);
    	
    	// set if it's an emulator run or not
    	if (mobileOS.value().contains("_Sim")) {
    		TestRun.setSimulatorRun(true);
    	}
    	
    	// set if it's mobile web or not
    	if (capabilities.getBrowserName().equals("Safari") || capabilities.getBrowserName().equals("Chrome")) {
    		TestRun.setMobileWebRun(true);
    	}
    	
    	if (mobileOS != null && deviceCategory != null) {
    	    TestRun.setMobileOS(mobileOS);
    	    activeMobileOS.set(mobileOS);
    	    TestRun.setDeviceCategory(deviceCategory);
    	    activeDeviceCategory.set(deviceCategory);
    	    
    	    // indicate if the test is selendroid
    	    if (capabilities.getCapability(MobileCapabilityType.AUTOMATION_NAME) != null) {
    	    	if (capabilities.getCapability(MobileCapabilityType.AUTOMATION_NAME) == "Selendroid") {
    	    		TestRun.setSelendroidRun(true);
    	    	}
    	    }
    	}
    	
    	// get the hub url and set the appropriate runtime environment (Sauce, Browserstack, QA Lab)
    	String hubUrl = getHubAddress();
    	if (TestRun.isLabRun() && GridManager.isQALabHub()) {
    		Boolean sessionSuccess = false;
    		
    		for (int farmIter = 0; farmIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; farmIter++) {
    			// check if the user explicitly indicated a target device
        		if (capabilities.getCapability(Constants.DEVICE_ID) == null 
    					|| capabilities.getCapability(Constants.DEVICE_ID) == "") {
        			// no device specified, grab a free device from the farm
        			
        			List<String> allUserExcludedDevices = new ArrayList<String>(Arrays.asList(""));
    				
    				// exclude any versions the user didn't specify. TODO want to tear all this out and have
    				// everything be a custom MQE capability that gets passed instead of custom methods within the driver
    				String[] targetVersions = null;
    				if (capabilities.getCapability("setTargetDeviceVersions") != null) {
    					targetVersions = capabilities.getCapability("setTargetDeviceVersions").toString()
        						.replaceAll(" ", "").split(",");
    					
    					if (targetVersions != null) {
    						for (String deviceID : LabDeviceManager.getAllDeviceIDs(mobileOS)) {
    							Boolean targetDeviceOS = false;
    							String deviceOS = LabDeviceManager.getDeviceOSVersion(LabDeviceManager
                						.getDeviceMachineIPAddress(deviceID), mobileOS);
    							for (String targetVersion : targetVersions) {
    								if (deviceOS.contains(targetVersion)) {
    									targetDeviceOS = true;
    									break;
    								}
    							}
    							if (!targetDeviceOS) {
    								allUserExcludedDevices.add(deviceID);
    							}
    						}
        				}
    				}
    				
    				// add any devices the user explicitLy indicated they wanted to exclude
    				if (capabilities.getCapability("excludedDevices") != null) {
    					List<String> explicitExcludedDevices = new ArrayList<String>(Arrays.asList(capabilities.getCapability("excludedDevices")
                			    .toString().split(",")));
    					
    					for (String explicitDevice : explicitExcludedDevices) {
    						allUserExcludedDevices.add(explicitDevice);
    					}
    				}
    				
    				// exclude iOS 10 devices if the user didn't specify they be included
    				// NOTE - this will go away in the future as the mandate has been passed to teams
    				// to update their projects for ios 10 immediately!!!
    				Boolean includeIOS10 = true;
    				if (capabilities.getCapability("includeiOS10Devices") == null) {
    					includeIOS10 = false;
    				} else {
    					if (capabilities.getCapability("includeiOS10Devices").toString().equals("false")) {
    						includeIOS10 = false;
    					}
    				}
    				if (!includeIOS10) {
    					for (String deviceID : LabDeviceManager.getAllDeviceIDs(mobileOS)) {
    						if (LabDeviceManager.getDeviceOSVersion(LabDeviceManager
    							.getDeviceMachineIPAddress(deviceID), mobileOS).contains("10.")) {
    							allUserExcludedDevices.add(deviceID);
    						}
    					}
    				}
    				
    				// fail the tests if the execution has taken a significant number of previously healthy devices down
    				Integer unhealthyDeviceCount = unHealthyDevices.size();
    				if (unhealthyDeviceCount >= Constants.INACTIVE_DEVICE_MAX) {
    					GlobalAbort.terminateTestSuite("TOO MANY UNHEALTHY DEVICES DURING THE COURSE OF THE EXECUTION! Failing test run until maintenance "
    						+ "jobs can resolve!");
    				}
        			
    				Boolean deviceAvailable = false;
    				while (!deviceAvailable) {
    					synchronized (DriverFactory.class) {
    						List<String> currDeviceFarm = new ArrayList<String>();
    						if (allDevices.isEmpty()) {
    							currDeviceFarm = LabDeviceManager.getAllDeviceIDs(activeMobileOS.get());
    						} else {
    							currDeviceFarm = allDevices;
    						}
    						for (String deviceID : currDeviceFarm) {
    							// get the device info
    							activeDeviceID.set(deviceID);
    							HashMap<String, String> deviceInfo = TestRun.isIos() ? LabDeviceManager.getIOSDeviceInfo(activeDeviceID.get()) 
    								: LabDeviceManager.getAndroidDeviceInfo(activeDeviceID.get());
            					// set the active device info
            					activeMachineIP.set(deviceInfo.get("machine_ip"));
            					activeMobileOSVersion.set(deviceInfo.get("device_os_version"));
            					activeDeviceName.set(deviceInfo.get("device_name"));
        	        	    	activeDeviceProxyPort.set(deviceInfo.get("device_proxy_port"));
        	        	    	activeMachineName.set(LabDeviceManager.getDeviceMachineName(activeDeviceID.get()));
        	        	    	
        	        	    	// set the app package (if testing a native app)
        	        	    	if ((activeMobileOS.get().equals(MobileOS.IOS) || activeMobileOS.get().equals(MobileOS.IOS_SIM)) && !TestRun.isMobileWeb()) {
        	        	    		activeAppPackage.set(capabilities.getCapability(MobileCapabilityType.APP).toString());
        	        	    	} else if ((activeMobileOS.get().equals(MobileOS.ANDROID) || activeMobileOS.get().equals(MobileOS.ANDROID_SIM)) && !TestRun.isMobileWeb()) {
        	        	    		if (capabilities.getCapability(AndroidMobileCapabilityType.APP_PACKAGE) != null) {
        	        	    			activeAppPackage.set(capabilities.getCapability(AndroidMobileCapabilityType.APP_PACKAGE).toString());
        	        	    		}
        	        	    	}
        	        	    	
        	        	    	// set requisite device name and version (if ios simulator)
        	        	    	if (activeMobileOS.get().equals(MobileOS.IOS_SIM)) {
        	        	    		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, activeDeviceName.get());
        	        	    		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, activeMobileOSVersion.get());
        	        	    		capabilities.setCapability("waitForAppScript", "$.delay(1000); true;");
        	        	    	}
        	        	    	
        	        	    	// is device active/enabled
        	        	    	Boolean active = deviceInfo.get("device_status").contains("active");
        	        	    	
        	        	    	// is the device currently not in use
        	        	    	Boolean inUse = Boolean.parseBoolean(deviceInfo.get("device_in_use"));
        	        	    	
        	        	    	// is the device currently healthy in the test session
        	        	    	Boolean unhealthy = unHealthyDevices.contains(activeDeviceID.get());
        	        	    	
        	        	    	// is the device the right category
        	        	    	Boolean rightCategory = deviceInfo.get("device_category").equalsIgnoreCase(activeDeviceCategory.get().value());
        	        	    	
        	        	    	// user exclude device
        	        	    	Boolean excluded = allUserExcludedDevices.contains(activeDeviceID.get());
        	        	    	
        	        	    	// DEVICE IS A MATCH!
        	        	    	if (active && !inUse && !unhealthy && rightCategory && !excluded) {
        	        	    		// DEVICE AVAILABLE FOR TEST
    								ActiveDeviceManager.setActiveDevice(activeDeviceID.get());
            	        	    	ActiveDeviceManager.addActiveDevice(activeDeviceID.get());
            	        	    	LabDeviceManager.setDeviceInUse(activeDeviceID.get(), true);
            	        	    	LabDeviceManager.setDeviceUseDuration(activeDeviceID.get(), System.currentTimeMillis());
            	        	    	capabilities.setCapability(MobileCapabilityType.VERSION, activeDeviceID.get());
            	        	    	deviceAvailable = true;
            	        	    	TestDeviceInfo.initDeviceInfo(activeMobileOS.get(), activeDeviceCategory.get(), activeMachineName.get(), deviceInfo);
            	        	    	break;
        	        	    	}
        					}
    					}
    					
    					if (!deviceAvailable) {
    						AvailableDevicePoller.pollFarmForDevice(activeMobileOS.get(), activeDeviceID.get(), activeMachineIP.get(), false);
    	        		}	
    				}
            } else {
            	// specific device identified by the user!
            	synchronized (DriverFactory.class) {
            		activeDeviceID.set(capabilities.getCapability(Constants.DEVICE_ID).toString());
            		HashMap<String, String> deviceInfo = TestRun.isIos() ? LabDeviceManager.getIOSDeviceInfo(activeDeviceID.get()) 
            			: LabDeviceManager.getAndroidDeviceInfo(activeDeviceID.get());
					activeMachineIP.set(deviceInfo.get("machine_ip"));
    				activeDeviceName.set(deviceInfo.get("device_name"));
	        	    activeDeviceProxyPort.set(deviceInfo.get("device_proxy_port"));
	        	    if (activeMobileOS.get().equals(MobileOS.IOS)) {
	        	    	activeAppPackage.set(capabilities.getCapability(MobileCapabilityType.APP).toString());
	        	    } else {
	        	    	if (capabilities.getCapability(AndroidMobileCapabilityType.APP_PACKAGE) != null) {
	        	    		activeAppPackage.set(capabilities.getCapability(AndroidMobileCapabilityType.APP_PACKAGE).toString());
	        	    	}
	        	    }
	        	    activeMachineName.set(LabDeviceManager.getDeviceMachineName(activeDeviceID.get()));
	        	    	
	        	    // check if the requested device is in use and poll until available
	        	    while (LabDeviceManager.isDeviceInUse(activeDeviceID.get())) {
	        	    	AvailableDevicePoller.pollFarmForDevice(activeMobileOS.get(), activeDeviceID.get(), activeMachineIP.get(), true);
	        	    }
    					
            		ActiveDeviceManager.setActiveDevice(activeDeviceID.get());
            	    ActiveDeviceManager.addActiveDevice(activeDeviceID.get());
            	    LabDeviceManager.setDeviceInUse(activeDeviceID.get(), true);
            	    LabDeviceManager.setDeviceUseDuration(activeDeviceID.get(), System.currentTimeMillis());
                	capabilities.setCapability(MobileCapabilityType.VERSION, activeDeviceID.get());
                	specificDevice.set(true);
            	}
            }
    			
        	for (int deviceIter = 0; deviceIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; deviceIter++) {
        		// attempt to start a session
        		try {
        			// clean the log
        			LabDeviceManager.cleanAppiumLog(activeMobileOS.get(), activeMachineIP.get());
        				
        			// wake up the android device
        			if (mobileOS == MobileOS.ANDROID) {
        				LabDeviceManager.unlockDevice(activeMachineIP.get());
        			}
        				
        			// set and start the proxy for the device prior to the app startup
        			LabDeviceManager.killDeviceProxyPort(activeMachineIP.get(), mobileOS);
        			Thread.sleep(1000);
        			ProxyManager.initAllProxyServers(Arrays.asList(Integer.parseInt(activeDeviceProxyPort.get())));
        			ProxyManager.enableMITM();
        			ProxyManager.setProxyServer(Integer.parseInt(activeDeviceProxyPort.get()));
        			ProxyManager.startProxyServer();
            			
            		// set any proxy rewrites prior to session startup
            		if (filters.get() != null) {
            			for (HttpFiltersSource filter : filters.get()) {
            				ProxyManager.getProxyServer().addHttpFilterFactory(filter);
                		}
            		}
            			
        			// install the app as the user has indicated
        			Boolean installSuccess = false;
        			if (labAppInstallOnStartup.get()) {
        				installSuccess = GlobalInstall.installApp(installOnTest.get(), activeDeviceID.get(), 
        					installAppPackageID.get());
        			}
        				
        			// fail if the install failed
        			if (labAppInstallOnStartup.get() && !installSuccess) {
        				throw new RuntimeException("App failed to install on device '" + activeDeviceID.get() + "'");
        			}
        				
        			// selendroid app install handling
        			if (TestRun.isSelendroid()) {
        				capabilities.setCapability(MobileCapabilityType.APP, GlobalInstall.getNodeAppFile());
        			}
        				
            		// iOS 10 handling
            		if (activeMobileOS.get().equals(MobileOS.IOS)) {
            			if (LabDeviceManager.getDeviceOSVersion(activeMachineIP.get(), MobileOS.IOS)
    	        	    	.contains("10.")) {
            				TestRun.setIOS10(true);
    	        	    	capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
    	        	    	capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
    	        	    	capabilities.setCapability("bundleId", capabilities.getCapability(MobileCapabilityType.APP));
	        	    		capabilities.setCapability(MobileCapabilityType.APP, "");
    	        	    } else {
    	        	    	TestRun.setIOS10(false);
    	        	    }
            		}
            			
            		// start the session
            		if (capabilities.getCapability(MobileCapabilityType.VERSION) == null) {
            			Logger.logConsoleMessage("Attempting to start a session without a device id identified, "
            			    + "either explicitly by the user or via the virtual device farm. The grid will "
            			    + "attempt to find any matching device but there's no guarantee it will meet "
            			    + "the requested runtime requirements.");
            		}
            		initAppiumDrivers(hubUrl, capabilities);
							
            		// check that the grid distributed the test to the correct machine node
            		String gridSessionIP = GridManager.getRunningSessionIP();
            		if (!gridSessionIP.toString().equals(activeMachineIP.get())) {
            			resetDeviceNode.set(false);
            			throw new RuntimeException("The grid incorrectly distributed the session to '" 
            				+ gridSessionIP + "' instead of '" + activeMachineIP.get() + "'.");
            		}
            			
            		// check app network connectivity (if the user indicated)
            		if (checkProxyLogsOnStartup.get()) {
            			new FluentWait<WebDriver>(DriverManager.getAppiumDriver()).withTimeout(Constants.PROXY_LOG_TIMEOUT_S, TimeUnit.SECONDS)
                	        .withMessage("Proxy connection not established on device '" + activeDeviceID.get() + "' with proxy port '" 
            				    + activeDeviceProxyPort.get() + "' on machine '" + activeMachineIP.get() + "'.")
                	        .pollingEvery(Constants.PROXY_LOG_POLLING_MS, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>() {
                	        	@Override public Boolean apply(WebDriver input) {
                	        		return ProxyManager.getLogEntries().size() > 0;
                	        	}
                	    });
            		}
            			
            		Logger.logMessage("Appium session successfully created for an " + activeMobileOS.get().toString() 
                        + " " + activeDeviceCategory.get().toString() + " device with device id '" + activeDeviceID.get() 
                        + "' on '" + activeMachineIP.get() + "' with proxy port '" + activeDeviceProxyPort.get() + ".");
                        
                    sessionSuccess = true;
                    break;
        		} catch (Exception e) {
        			// stop the driver (if necessary)
                    try {
                    	if (DriverManager.getAppiumDriver() != null) {
                        	if (DriverManager.getAppiumDriver().getSessionId() != null) {
                        		DriverManager.getAppiumDriver().quit();
                        	}
                        }
                    } catch (Exception e2) {
                    	Logger.logConsoleMessage("Failed to terminate driver.");
                    	e2.printStackTrace();
                    }
                    	
                    try {
						Thread.sleep(Constants.DRIVER_RECYLE_TIMEOUT_MS);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
                    	
                    // if the user specified a specific device don't perform multiple attempts
                    if (specificDevice.get()) {
                    	break;
                    }
                    	
                    if (deviceIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
                    	// unhealthy device, remove from the active lab device list
                    	Logger.logMessage("A session failed to be spun up on lab machine '" + activeMachineName.get() 
                    		+ "' with session ip '" + activeMachineIP.get() + "' for device '" + activeDeviceName.get() 
                    		+ "' with id '" + activeDeviceID.get() + "'. This device has been removed from "
                    		+ "the active device farm.");
                    	ActiveDeviceManager.removeActiveDeviceID(activeDeviceID.get());
                    	unHealthyDevices.add(activeDeviceID.get());
                    	LabDeviceManager.setDeviceInUse(activeDeviceID.get(), false);
                        LabDeviceManager.setDeviceUseDuration(activeDeviceID.get(), 0L);
                        try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    } else {
                    	Logger.logMessage("Failed to start Appium session on attempt '" + deviceIter 
                    		+ "' for device '" + activeDeviceID.get() + "' on machine '" + activeMachineIP.get() + "'. Resetting remote "
                    		+ "node and retrying...");
                    	Logger.logMessage(e.getMessage());
                    	e.printStackTrace();
                    		
                    	// kill the proxy server
                    	try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    		
                    	// kill the problematic machine node
                    	if (resetDeviceNode.get()) {
                    		try {
                    			GridManager.resetRemoteMobileNode(activeMobileOS.get(), activeMachineIP.get());
                        	} catch (Exception e2) {
                        		Logger.logConsoleMessage("Failed to reset remote node.");
                        		e2.printStackTrace();
                        	}
                    	} else {
                    		try { Thread.sleep(Constants.DRIVER_NODE_RECYLE_PAUSE_MS); } catch (InterruptedException e1) {}
                    	}
                    }
                }
        	}
    			
        	if (sessionSuccess || specificDevice.get()) {
    			break;
    		}
        		
        	if (farmIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
        		Logger.logConsoleMessage("FAILED TO START APPIUM SESSION AFTER MULTIPLE ATTEMPTS ON MULTIPLE DEVICES!");
        	} else {
        		Logger.logConsoleMessage("Failed to start Appium session on lab device with id '" + activeDeviceID.get() + "' after multiple "
        			+ "attempts. Retrying on a different device...");
        	} 
    	}
    } else { // LOCAL TEST RUN (DEBUG)
    	try {
    		if (localDebugProxyPort.get() != null) {
    			// set and start the proxy for the device prior to the app startup
    			ProxyManager.initAllProxyServers(Arrays.asList(localDebugProxyPort.get()));
    			ProxyManager.enableMITM();
    			ProxyManager.setProxyServer(localDebugProxyPort.get());
    			ProxyManager.startProxyServer();
    		}
    	} catch (Exception e) { }
    		
    	try {
			if (filters.get() != null) {
				HashMap<Integer, BrowserMobProxyServer> integerBrowserMobProxyServerHashMap = ProxyManager.getAllProxyServers();

				for (Integer integer : integerBrowserMobProxyServerHashMap.keySet()) {
					for (HttpFiltersSource filter : filters.get()) {
						integerBrowserMobProxyServerHashMap.get(integer).addHttpFilterFactory(filter);
					}
				}
			}

			// ios 10 handling
			if (capabilities.getCapability("automationName") != null) {
				if (capabilities.getCapability("automationName").equals("XCUITest")) {
					TestRun.setIOS10(true);
					capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
					capabilities.setCapability("bundleId", capabilities.getCapability("app"));
    	    		capabilities.setCapability("app", "");
				} else {
					TestRun.setIOS10(false);
				}
			}
				
			initAppiumDrivers(hubUrl, capabilities);
        } catch (Exception e) {
            Logger.logConsoleMessage("Failed to spin up a local Appium session.");
            e.printStackTrace();
        } 
    	} // TODO - margins off...
    }
    
    /**********************************************************************************************
     * Enables the 'proxy log entries > 0' check performed at driver spinup to help ensure the user gets a device
     * with a valid internet/proxy connection prior to test start. NOTE - some of our test rig internal apps don't
     * make any calls on app open so this additional proxy check is disabled by default.
     * 
     * @author Brandon Clark created July 17, 2016
     * @version 1.0 July 17, 2016
     ***********************************************************************************************/
    public static void enableProxyCheckAtAppiumStartup() {
    	checkProxyLogsOnStartup.set(true);
    }
    
    /**********************************************************************************************
     * Applies a list of HttpFiltersSource Proxy rewrites to the proxy session BEFORE the driver is initiated, allowing
     * for traffic capture/manipulation of actions on application startup.
     * 
     * @param rewriteFilters - {@link List<HttpFiltersSource} - A list of HttpFiltersSource BrowserMobProxy rewrite objects
     * @author Brandon Clark created July 17, 2016
     * @version 1.0 July 17, 2016
     ***********************************************************************************************/
    public static void setRewritesAtStartup(List<HttpFiltersSource> rewriteFilters) {
    	filters.set(rewriteFilters);
    }
    
    public static void enableLabAppInstall(Boolean installOnTest, String appPackageID) {
    	labAppInstallOnStartup.set(true);
    	DriverFactory.installOnTest.set(installOnTest);
    	installAppPackageID.set(appPackageID);
    }
    
    public static void setLocalDebugProxyPort(Integer debugProxyPort) {
    	localDebugProxyPort.set(debugProxyPort);
    }
    
    private static String getHubAddress() {
    	String hubUrl = null;
    	
    	// is sauce
    	try {
    		if (TestRun.isSauceRun()) {
    			hubUrl = "http://" + SauceCredentialManager.getSauceUsername() + ":" + SauceCredentialManager.getSauceKey() + "@ondemand.saucelabs.com:80/wd/hub";
    			TestRun.setBrowserstackRun(false);
    			TestRun.setLabRun(false);
    		}
    	} catch (NullPointerException e) {
    		TestRun.setSauceRun(false);
    	}
    	
    	// is browserstack
    	try {
    		if (TestRun.isBrowserstackRun()) {
    			hubUrl = "https://" + BrowserstackCredentialManager.getBrowserstackUsername() + ":" + BrowserstackCredentialManager.getBrowserstackKey() 
    	    		    + "@hub-cloud.browserstack.com/wd/hub";
    			TestRun.setSauceRun(false);
    			TestRun.setLabRun(false);
    		}
    	} catch (NullPointerException e) {
    		TestRun.setBrowserstackRun(false);
    	}
    	
    	// is MQE lab run
    	if (!TestRun.isSauceRun() && !TestRun.isBrowserstackRun()) {
    		MobileOS mobileOS = null;
    		if (TestRun.isMobile()) {
    			mobileOS = TestRun.getMobileOS();
    		}
    		hubUrl = "http://" + GridManager.getGridHubIP() + ":" + GridManager.getGridHubPort(mobileOS) + "/wd/hub";
    		TestRun.setLabRun(true);
    	}
    	return hubUrl;
    }
    
    @SuppressWarnings("unchecked")
	private static void initAppiumDrivers(String hubUrl, DesiredCapabilities capabilities) throws Exception {
    	if (TestRun.isAndroid() || TestRun.isAndroidSim()) {
    		if (TestRun.isSelendroid()) {
    			appiumDriver.set(new SelendroidDriver(new URL(hubUrl), capabilities));
    		} else {
    			appiumDriver.set(new AndroidDriver<MobileElement>(new URL(hubUrl), capabilities));
    		}
    		DriverManager.setAppiumDriver(appiumDriver.get());
            androidDriver.set((AndroidDriver<MobileElement>) appiumDriver.get());
            DriverManager.setAndroidDriver(androidDriver.get());
        } else {
            appiumDriver.set(new IOSDriver<MobileElement>(new URL(hubUrl), capabilities));
            DriverManager.setAppiumDriver(appiumDriver.get());
            iOSDriver.set((IOSDriver<MobileElement>) appiumDriver.get());
            DriverManager.setIOSDriver(iOSDriver.get());
        }
    }
    
}
