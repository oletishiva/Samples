package com.viacom.test.core.performance;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.Transfer.TransferState;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.viacom.test.core.lab.CommandExecutor;
import com.viacom.test.core.lab.GridManager;
import com.viacom.test.core.lab.LabDeviceManager;
import com.viacom.test.core.props.DesktopOSType;
import com.viacom.test.core.proxy.ProxyManager;
import com.viacom.test.core.report.FileZipper;
import com.viacom.test.core.report.SplunkManager;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.RandomData;

import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.proxy.CaptureType;

public class JMeterManager {

	// TODO - right now this is not thread safe - but it should be... Replace static variables with ThreadLocal instances
    private static String testLocation;
    private static String reportDirLocation;
    private static String reportDashboardDirLocation;
    private static String logLocation;
    private static File currentHarLog = null;
    private static List<File> harLogFiles = new ArrayList<File>();
    private static List<String> summaryEntries = new ArrayList<String>();
    private static List<String> iterativeSummaryEntries = new ArrayList<String>();
    
    private static Integer threadCount = 0;
    private static Integer duration = 0;
    private static Integer trueDuration = 0;
    private static Integer loopCount = 0;
    
	private static String s3ProjectBucketName;
	private static String s3ReportDir;
	private static String s3ReportUrl;
	
	private static Boolean runCompleted = false;
	private static Integer finalThreadCount = null;
	private static Boolean runLocal = null;
	
	private static String newRelicAppId = null;
	private static String newRelicAPIKey = null;
	
	private static BrowserMobProxyServer proxyServer = null;
	
	private static final Integer CALC_WAIT_SEC = 30;
	private static final Integer CALC_WAIT_MS = 30000;
	
	public static void executeJMeterTest() {
		if (testLocation == null) {
			throw new RuntimeException("Test location is not set.");
		}
		
		if (reportDirLocation == null) {
			throw new RuntimeException("Report directory not set.");
		}
		
		if (!jMeterTestExists()) {
			throw new RuntimeException("JMeter .jmx test file does not exist at '" + testLocation + "'. Did you set your test location?");
		}
		
		// set the loop count if indicated by the user
		if (loopCount != 0 && duration == 0) {
			updateContinueForever(false);
			updateScheduled(false);
			updateLoopCount();
		}
				
		// set the duration if indicated by the user
		if (loopCount == 0 && duration != 0) {
			updateContinueForever(true);
			setLoopCount(-1);
			updateLoopCount();
			updateScheduled(true);
			updateDuration();
			updateStartupDelay(0);
		}
				
		// set the thread count if indicated by the user
		if (threadCount != 0) {
			updateThreadCount();
		}
				
		// check that the user indicated an appropriate loop count
		if (loopCount != 0 && duration == 0) {
			if (exceedsLoopLimit(Constants.JMETER_LOOP_COUNT_LIMIT)) {
				throw new RuntimeException("The JMeter test exceeds the maximum loop limit of '" + Constants.JMETER_LOOP_COUNT_LIMIT + "'. "
						+ "The test must have a reasonable execution cycle.");
			}
		}
				
		// check that the user indicated an appropriate schedule duration
		if (loopCount == 0 && duration !=0) {
			if (exceedsDurationLimit(Constants.JMETER_DURATION_LIMIT)) {
				throw new RuntimeException("The JMeter test exceeds the maximum duration of '" + Constants.JMETER_DURATION_LIMIT + "' seconds. "
						+ "The test must have a reasonable execution cycle.");
			}
		}
				
		// check that the default loop/schedule is reasonable if the user doesn't indicate them
		if (loopCount == 0 && duration == 0) {
			if (!JMeterManager.isScheduled()) {
				if (continueForever()) {
					throw new RuntimeException("The JMeter test is set to loop forever. The test must have a finite execution cycle.");
				} else if (exceedsLoopLimit(Constants.JMETER_LOOP_COUNT_LIMIT)) {
					throw new RuntimeException("The JMeter test exceeds the maximum loop limit of '" + Constants.JMETER_LOOP_COUNT_LIMIT + "'. "
							+ "The test must have a reasonable execution cycle.");
				}
			} else {
				if (exceedsDurationLimit(Constants.JMETER_DURATION_LIMIT)) {
					throw new RuntimeException("The JMeter test exceeds the maximum duration of '" + Constants.JMETER_DURATION_LIMIT + "' seconds. "
							+ "The test must have a reasonable execution cycle.");
				}
			}
		}
		
		// check that the test limits thread limit is not exceeded TODO - research and config this limit
		Integer threadLimit = Constants.JMETER_AGENT_THREAD_LIMIT;
		if (GridManager.isQALabHub()) {
			threadLimit = (Constants.JMETER_AGENT_THREAD_LIMIT * LabDeviceManager.getAllMachineIPAddresses().size());
		}
		if (exceedsThreadLimit(threadLimit)) {
			throw new RuntimeException("The JMeter test exceeds the maximum thread limit of '" + threadLimit + "'.");
		}
		
		// apply the beanshell assertion data for detailed data logging and splunking
		insertJMeterBeanShell();
		
		// run the test
		runJMetertest();
	}
	
	public static void setTestLocation(String pathToJMeterTest, String pathToReportDir) {
		// check if the file is zipped up
		if (!new File(pathToJMeterTest).getAbsolutePath().endsWith(".zip")) {
			throw new RuntimeException("The requested JMeter test is not a zip file. Please zip up the .jmx test (and any associated files) and re-run.");
		}
		
		// set and clean the report dirs
		reportDirLocation = pathToReportDir;
		reportDashboardDirLocation = reportDirLocation + "dashboard";
		cleanReportDir(reportDirLocation);
		cleanReportDir(reportDashboardDirLocation);
		
		// download the test file if necessary, or copy it to where it needs to be from a project location
		String filePath = pathToJMeterTest;
		
		if (pathToJMeterTest.contains(Constants.HTTP)) {
			// The test location is a url - download the .zip file
			String dateFileName = reportDirLocation + new SimpleDateFormat(Constants.PACKAGE_DATE_FORMAT).format(new Date());
			filePath = dateFileName + Constants.ZIP_EXT;
			
			Logger.logConsoleMessage("Downloading test file from '" + pathToJMeterTest + "' to '" + filePath + "'.");
			String command = "curl --connect-timeout 30 --max-time 120 -o " + filePath + " -L " + pathToJMeterTest;
	    	Logger.logConsoleMessage(CommandExecutor.execCommand(command, null));
		} else {
			// The test location is a local zip in a project dir, copy it to the runtime reporting directory
			try {
				FileUtils.copyFileToDirectory(new File(filePath), new File(reportDirLocation));
			} catch (Exception e) {
				Logger.logConsoleMessage("Failed to find and copy the JMeter .zip file from the local source to the runtime directory.");
				e.printStackTrace();
			}
		}
		
		Logger.logConsoleMessage("Unzipping JMeter zip package.");
		new FileZipper().unzipZipFile(filePath, reportDirLocation);
		
		File[] reportDirs = new File(reportDirLocation).listFiles();
		File locationDir = null;
		for (File testDir : reportDirs) {
			if (testDir.isDirectory()) {
				File[] subFiles = testDir.listFiles();
				for (File subFile : subFiles) {
					if (subFile.getName().contains(Constants.JMX_EXT)) {
						locationDir = new File(testDir.getAbsolutePath());
						break;
					}
				}
			}
			if (locationDir != null) {
				break;
			}
		}
		
		File[] allTestFiles = locationDir.listFiles();
		// set the jmx test location
		for (File file : allTestFiles) {
			if (file.getAbsolutePath().endsWith(Constants.JMX_EXT)) {
	    		testLocation = file.getAbsolutePath();
	    	}
	    }
		
		// update and copy all associated files
		if (GridManager.isQALabHub()) {
			for (File file : allTestFiles) {
				if (!file.getAbsolutePath().endsWith(Constants.JMX_EXT) && !file.getName().startsWith(".")) {
					updateAssociatedFilePath(file);
					try {
						// TODO - constant or dynamic ability to set where your jmeter and associated files instance
						// lives on a machine
						FileUtils.copyFileToDirectory(file, new File("/Applications/jmeter/associatedfiles"));
					} catch (IOException e) {
						Logger.logConsoleMessage("Failed to copy associated file to hub associated files dir.");
						e.printStackTrace();
					}
		    		copyAssociatedFileToLabMachines(file.getAbsolutePath());
		    	}
		    }
		}
		
		Logger.logConsoleMessage("Setting test location to '" + pathToJMeterTest + "' with report directory '" + pathToReportDir + "'.");
	}
	
	public static void setDuration(Integer duration) {
		JMeterManager.duration = duration;
	}
	
	private static void updateDuration() {
    	Logger.logConsoleMessage("Setting test duration to '" + duration + "' seconds.");
    	updateJMeterItem("//ThreadGroup//*[@name='ThreadGroup.duration']", duration.toString());
    }
	
	public static void setLoopCount(Integer loopCount) {
		JMeterManager.loopCount = loopCount;
	}
	
	private static void updateLoopCount() {
    	Logger.logConsoleMessage("Setting loop count to '" + loopCount + "'.");
    	updateJMeterItem("//ThreadGroup//*[@name='LoopController.loops']", loopCount.toString());
    }
	
	public static void setThreadCount(Integer threadCount) {
		JMeterManager.threadCount = threadCount;
	}
	
	public static void setNewRelicPost(String appID, String apiKey) {
		if (appID != null || appID != "") {
			Logger.logConsoleMessage("Setting New Relic App ID to '" + appID + "'.");
		    newRelicAppId = appID;
		}
		if (apiKey != null || apiKey != "") {
			Logger.logConsoleMessage("Setting New Relic API Key to '*******************'.");
		    newRelicAPIKey = apiKey;
		}
	}
	
	private static void updateThreadCount() {
    	Logger.logConsoleMessage("Setting thread count to '" + threadCount + "'.");
    	updateJMeterItem("//ThreadGroup//*[@name='ThreadGroup.num_threads']", threadCount.toString());
    }
	
	private static Boolean jMeterTestExists() {
		Boolean exists = getJMeterXMLFile().exists();
		Logger.logConsoleMessage("Does JMeter test exist at specified location: " + exists.toString());
		return exists;
	}
	
    private static Boolean continueForever() {
    	return Boolean.parseBoolean(getJMeterItem("//ThreadGroup//boolProp[@name='LoopController.continue_forever']"));
    }
    
    private static void updateContinueForever(Boolean continueForever) {
    	updateJMeterItem("//ThreadGroup//*[@name='LoopController.continue_forever']", continueForever.toString());
    }
    
    private static Boolean isScheduled() {
    	return Boolean.parseBoolean(getJMeterItem("//ThreadGroup//*[@name='ThreadGroup.scheduler']"));
    }
    
    private static void updateScheduled(Boolean scheduled) {
    	updateJMeterItem("//ThreadGroup//*[@name='ThreadGroup.scheduler']", scheduled.toString());
    }
    
    private static Boolean exceedsDurationLimit(Integer durationLimit) {
    	Boolean durationLimitExceeded = true;
    	if (Integer.parseInt(getJMeterItem("//ThreadGroup//*[@name='ThreadGroup.duration']")) <= durationLimit) {
    		durationLimitExceeded = true;
    	}
    	return durationLimitExceeded;
    }
    
    private static void updateStartupDelay(Integer startupDelay) {
    	updateJMeterItem("//ThreadGroup//*[@name='ThreadGroup.delay']", startupDelay.toString());
    }
    
    private static Boolean exceedsLoopLimit(Integer loopLimit) {
    	Boolean loopLimitExceeded = true;
    	if (Integer.parseInt(getJMeterItem("//ThreadGroup//*[@name='LoopController.loops']")) <= loopLimit) {
    		loopLimitExceeded = false;
    	}
    	return loopLimitExceeded;
    }
    
    private static Boolean exceedsThreadLimit(Integer threadLimit) {
    	Boolean threadLimitExceeded = true;
    	if (Integer.parseInt(getJMeterItem("//ThreadGroup//*[@name='ThreadGroup.num_threads']")) <= threadLimit) {
    		threadLimitExceeded = false;
    	}
    	return threadLimitExceeded;
    }
    
    private static void updateAssociatedFilePath(File associatedFile) {
    	updateJMeterItem("//*[@name='filename'][contains(text(), '" + associatedFile.getName() + "')]", "/Applications/jmeter/associatedfiles/" + associatedFile.getName());
    }
    
    private static void copyAssociatedFileToLabMachines(String associatedFilePath) {
    	List<Thread> jMeterThreads = new ArrayList<Thread>();
    	for (String activeAgent : LabDeviceManager.getAllMachineIPAddresses()) {
    		if (LabDeviceManager.getMachineOSType(activeAgent).equals(DesktopOSType.MAC)) {
    			jMeterThreads.add(new Thread() {
        		    public void run() {
        		    	Logger.logConsoleMessage("Copying associated test file '" + associatedFilePath + "' to remote machine '" + activeAgent + "'.");
                		CommandExecutor.setTimeout(10);
            			CommandExecutor.copyFileFromTo(associatedFilePath, "/Applications/jmeter/associatedfiles", activeAgent);
        		    }
                });
    		}
    		
    	}
    	for (Thread thread : jMeterThreads) {
		     thread.start();
		}
		for (Thread thread : jMeterThreads) {
		     try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
    }
    
    private static void runJMetertest() {
    	// check if jmeter agents are in use and wait as needed. NOTE - this blocking/all strategy will change in the future
    	Integer idleCounter = 0;
    	Integer maxWait = 3600; // TODO - constant
    	
    	// get the remote agent machine list if running on the lab
    	List<String> allActiveAgents = new ArrayList<String>();
    	if (GridManager.isQALabHub()) {
    		for (String machine : LabDeviceManager.getAllMachineIPAddresses()) {
    			if (LabDeviceManager.getMachineOSType(machine).equals(DesktopOSType.MAC)) {
    				// TODO - setup jmeter on windows alpha boxes and remove this check
    				allActiveAgents.add(machine);
    			}
    		}
    	} else {
    		allActiveAgents.add("localhost");
    	}
    	
    	while (GridManager.isQALabHub() && LabDeviceManager.isJMeterInUse() && idleCounter <= maxWait) {
    		if (idleCounter != 0) {
    			Logger.logConsoleMessage("Requested a JMeter agent, but all available agents are in use. Waiting for '" + idleCounter + "' second(s).");
    		}
    		try { Thread.sleep(1000); } catch (InterruptedException e) { }
    		idleCounter++;
    	}
    		
    	if (GridManager.isQALabHub() && LabDeviceManager.isJMeterInUse()) {
    		throw new RuntimeException("There are no available JMeter agents after '" + maxWait + "' seconds. Aborting JMeter run.");
    	}
    	
    	// set the jmeter agents in use
    	if (GridManager.isQALabHub()) {
    	    LabDeviceManager.setJMeterInUse(true);
    	}
    	
    	// clean up any legacy jmeter instances and agent runners
    	if (GridManager.isQALabHub()) {
    		CommandExecutor.execCommand("/Applications/jmeter/bin/shutdown.sh", null);
    		for (String machine : allActiveAgents) {
    			CommandExecutor.execCommand("open " + Constants.JMETER_STOP_NODE_PATH, machine);
    		}
    	}
    	
    	// calculate the desired thread count and determine if the run should be local or across all agents
    	Integer threadCount = Integer.parseInt(getJMeterItem("//ThreadGroup//*[@name='ThreadGroup.num_threads']"));
    	Integer updatedThreadCount = null;
    	finalThreadCount = null;
    	runLocal = false;
    	if (threadCount <= allActiveAgents.size()) {
    		Logger.logConsoleMessage("Setting JMeter to run locally.");
    		runLocal = true;
    		finalThreadCount = threadCount;
    	} else {
    		runLocal = false;
    		updatedThreadCount = Math.round(threadCount / allActiveAgents.size());
    		if (updatedThreadCount.equals(0)) {
    			updatedThreadCount = 1;
    		}
    		finalThreadCount = (updatedThreadCount * allActiveAgents.size());
    		updateJMeterItem("//ThreadGroup//*[@name='ThreadGroup.num_threads']", updatedThreadCount.toString());
    		Logger.logConsoleMessage("Setting JMeter to run across all active agent machines.");
    		Logger.logConsoleMessage("Thread Count set to '" + finalThreadCount + "' to match scaled JMeter agent availability.");
    	}
    	
    	// start the jmeter servers
    	String remoteMachines = "";
    	String remoteStart = "";
    	String remoteExit = "";
    	if (GridManager.isQALabHub() && !runLocal) {
    		List<Thread> startJMeterThreads = new ArrayList<Thread>();
	    	for (String activeAgent : allActiveAgents) {
	    		startJMeterThreads.add(new Thread() {
	    		    public void run() {
	    		    	Logger.logConsoleMessage("Starting JMeter agent machine '" + activeAgent + "'.");
	        			CommandExecutor.execCommand("open " + Constants.JMETER_START_NODE_PATH, activeAgent);
	    		    }
	            });
	    	}
	    	for (Thread thread : startJMeterThreads) {
			     thread.start();
			}
			for (Thread thread : startJMeterThreads) {
			     try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			// generate the remote machine list
    		for (String activeAgent : allActiveAgents) {
    			remoteMachines =  remoteMachines + "," + activeAgent;
    		}
    		remoteStart = " --remotestart " + remoteMachines + " ";
    		remoteExit = " --remoteexit";
    		remoteMachines = remoteMachines.replaceFirst(",", "");
        	try { Thread.sleep(10000); } catch (InterruptedException e) { }
    	}
    	
    	// post the start data to new relic
    	if (GridManager.isQALabHub() && newRelicAppId != null && newRelicAPIKey != null) {
    		String constructedCurl = "curl -X POST 'https://api.newrelic.com/v2/applications/" + newRelicAppId 
    	    		+ "/deployments.json' \\ -H 'X-Api-Key:" + newRelicAPIKey + "' -i \\ -H 'Content-Type: application/json' \\ -d \\ "
    	    		+ "'{\"deployment\": { \"revision\": \"MQE LOAD TEST START\", \"changelog\": \"Starting MQE load test with " + finalThreadCount + "\""
    	    		+ ", \"description\": \"Starting MQE load test\", \"user\": \"brandon.clark@viacom.com\" } }'";
    	    CommandExecutor.execCommand(constructedCurl, null);
    	}
    	
    	// start up a proxy to route the traffic through
    	Integer proxyPort = null;
    	try {
        	ServerSocket serverSocket = new ServerSocket(0);
            proxyPort = serverSocket.getLocalPort();
            serverSocket.close();
        } catch (Exception e) {
            Logger.logConsoleMessage("Failed to generate proxy ports/tunnel identifiers.");
            e.printStackTrace();
        }
    	ProxyManager.initAllProxyServers(Arrays.asList(proxyPort));
    	ProxyManager.setProxyServer(proxyPort);
    	ProxyManager.startProxyServer();
    	proxyServer = ProxyManager.getProxyServer();
    	updateMQEProxySettings(proxyPort);
    	
    	// run the test
    	String reportLocation = reportDirLocation + "results.jtl";
    	logLocation = reportDirLocation + "jmeter.log";
    	String command = Constants.JMETER_PATH + " -j " + logLocation + " -n -J jmeter.save.saveservice.output_format=csv,jmeter.save.saveservice.response_data=true,"
    		+ "jmeter.save.saveservice.samplerData=true,jmeter.save.saveservice.requestHeaders=true,jmeter.save.saveservice.url=true,jmeter.save.saveservice.responseHeaders=true,"
        	+ "summariser.name=summary,summariser.interval=12,summariser.out=true,summariser.log=true -t " 
    	    + testLocation + " -l " + reportLocation + remoteStart + remoteExit;
    	List<Thread> jmeterThreads = new ArrayList<Thread>();
    	jmeterThreads.add(new Thread() {
		    public void run() {
		    	Logger.logConsoleMessage("Running JMeter test with constructed command '" + command + "'");
		    	if (GridManager.isQALabHub()) {
		        	LabDeviceManager.setJMeterInUse(false);
		        }
		    	
		    	if (loopCount.equals(-1)) {
		    		CommandExecutor.setTimeout((duration + CALC_WAIT_SEC));
		    	} else {
		    		CommandExecutor.setTimeout((Constants.JMETER_DURATION_LIMIT + CALC_WAIT_SEC));
		    	}
		    	
		    	try {
		    		Logger.logConsoleMessage(CommandExecutor.execMultiCommand(command));
		    		runCompleted = true;
		    	} catch (IllegalThreadStateException e) {
		    		Logger.logConsoleMessage("An exception occurred during jmeter execution. Terminating test.");
		    		runCompleted = true;
		    	}
		    }
        });
    	
    	jmeterThreads.add(new Thread() {
		    @SuppressWarnings("unchecked")
			public void run() {
		    	Boolean runDurLimitExceeded = false;
		    	if ((trueDuration / CALC_WAIT_SEC) >= (duration + CALC_WAIT_SEC)) {
		    		runDurLimitExceeded = true;
		    		Logger.logConsoleMessage("The true runtime duration of the test has exceeded the maximum duration.");
		    	}
		    	
		    	while (!runCompleted && !runDurLimitExceeded) {
		    		Logger.logConsoleMessage("======== NEW LOG ENTRY ========");
		    		try {
		    			currentHarLog = new File(reportDirLocation + "JMeterPerformance-" + (harLogFiles.size() + 1) + ".har");
						proxyServer.setHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.REQUEST_COOKIES, 
			        			CaptureType.REQUEST_HEADERS, CaptureType.RESPONSE_COOKIES, 
			        			CaptureType.RESPONSE_HEADERS);
						proxyServer.getHar().writeTo(currentHarLog);
						
						if (GridManager.isQALabHub()) {
							// copy the har file to the userContent dir for viewing
							File jenkinsHarLog = new File("/Users/mqeadmin/.jenkins/userContent/JMeterPerformance.har");
							FileUtils.copyFile(currentHarLog, jenkinsHarLog);
							Logger.logConsoleMessage("Har Entry with all request/response details exists at: http://mqe.viacom.com:8080/userContent/" + jenkinsHarLog.getName());
						} else {
							Logger.logConsoleMessage("Har Entry with all request/response details exists at: " + currentHarLog.getAbsolutePath());
						}
						
						Logger.logConsoleMessage("Har file size: " + currentHarLog.length());
						if (currentHarLog.length() >= 10485760) {
							Logger.logConsoleMessage("Har Log size is greater than 10 Megs, archiving the har data and cleaning the proxy logs.");
							// archive the har file and clear the proxy log
							harLogFiles.add(currentHarLog);
							proxyServer.newHar();
						}
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    			
	    			// get the local entries/summary data
		    		Boolean cumulativeEntryFound = false;
		    		BufferedReader logBufferedReader = null;
		    		try {
			    		File logFile = new File(logLocation);
			    		if (logFile.exists()) {
			    			logBufferedReader = new BufferedReader(new FileReader(logFile));
					    	
					    	String line = null;
					    	while ((line = logBufferedReader.readLine()) != null)   {
					    		if (line.contains("jmeter.reporters.Summariser: summary +")) {
					    			if (!iterativeSummaryEntries.contains(line)) {
					    				Logger.logConsoleMessage("ITERATIVE SUMMARY ENTRY: " + line);
					    				iterativeSummaryEntries.add(line);
					    			}
					    		}
					    	  
					    		if (line.contains("jmeter.reporters.Summariser: summary =")) {
					    			if (!summaryEntries.contains(line)) {
					    				cumulativeEntryFound = true;
					    				// new entry
					    				summaryEntries.add(line);
					    				Logger.logConsoleMessage("CUMULATIVE SUMMARY ENTRY: " + line);
					    				if (GridManager.isQALabHub()) {
					    					//post the summary data to splunk
					    					JSONObject jsonToPost = new JSONObject();
					    					jsonToPost.put("dateTime", line.split(" INFO")[0]);
					    					line = line.replaceAll("\\s+","");
					    					jsonToPost.put("currentUsers", finalThreadCount);
					    					jsonToPost.put("totalRequests", line.split("summary=")[1].split("in")[0]);
					    					jsonToPost.put("runDuration", line.split("in")[1].split("=")[0]);
					    					jsonToPost.put("requestsPerSecond", line.split("in")[1].split("=")[1].split("/sAvg:")[0]);
					    					jsonToPost.put("avgResponseTime", line.split("/sAvg:")[1].split("Min:")[0]);
					    					jsonToPost.put("errorCount", line.split("Err:")[1].split("\\(")[0]);
					    					postToSplunk(jsonToPost);
					    				}
					    			}
					    		}
					    	}
			    		}
			    	} catch (Exception e) {
			    		Logger.logConsoleMessage("Failed to retrieve summary data during JMeter execution.");
			    		e.printStackTrace();
			    	} finally {
			    		// clean the log
			    		//CommandExecutor.execCommand("echo -n \"\" > " + logLocation, null);
			    		if (logBufferedReader != null) {
			    			try { logBufferedReader.close(); } catch (IOException e) { }
			    		}
			    	}
		    		
		    		// calculate the local entries ourselves
		    		BufferedReader logCalcBufferedReader = null;
		    		List<String> entryLines = new ArrayList<String>();
		    		try {
		    			File jtlFile = new File(reportLocation);
			    		if (jtlFile.exists()) {
			    			Integer totalRequests = 0;
			    			Integer currentUsers = finalThreadCount;
			    			long runDuration = 0;
			    			long requestsPerSecond = 0;
			    			long avgResponseTime = 0;
			    			Integer errorCount = 0;
			    			
			    			logCalcBufferedReader = new BufferedReader(new FileReader(jtlFile));
					    	String line = null;
					    	while ((line = logCalcBufferedReader.readLine()) != null)   {
					    		if (line.contains(",Thread Group")) {
					    			entryLines.add(line);
					    		}
					    	}
					    	totalRequests = entryLines.size();
					    	
			    			List<String> errorEntries = new ArrayList<String>();
			    			for (String entryLine : entryLines) {
			    				if (!entryLine.contains("200,OK")) {
			    					errorEntries.add(entryLine.split(",")[3]);
			    				}
			    			}
			    			errorCount = errorEntries.size();
			    			
			    			List<String> timeEntries = new ArrayList<String>();
			    			for (String entryLine : entryLines) {
			    				timeEntries.add(entryLine.split(",")[0]);
			    			}
			    			String startTime = Collections.min(timeEntries);
			    			Date startDate = new Date(Long.parseLong(startTime));
			    			String endTime = Collections.max(timeEntries);
			    			Date endDate = new Date(Long.parseLong(endTime));
			    			long timeDiffInMS = endDate.getTime() - startDate.getTime();
			    			runDuration = timeDiffInMS / 1000;
			    			requestsPerSecond = totalRequests / runDuration;
			    			
			    			Integer totalRequestTime = 0;
			    			for (String entryLine : entryLines) {
			    				totalRequestTime = totalRequestTime + Integer.parseInt(entryLine.split(",")[1]);
			    			}
			    			avgResponseTime = totalRequestTime / totalRequests;
			    			
			    			if (totalRequests != 0 && requestsPerSecond != 0) {
			    				Logger.logConsoleMessage("CALCULATED SUMMARY ENTRY: " + "current users=" + currentUsers + ", total requests=" + totalRequests 
			    					+ ", true run duration=" + trueDuration + ", calculated run duration=" + runDuration + ", requests per second=" + requestsPerSecond 
			    					+ ", average response time=" + avgResponseTime + ",error count=" + errorCount);
			    				if (GridManager.isQALabHub() && !cumulativeEntryFound) {
			    					//post the summary data to splunk
			    					JSONObject jsonToPost = new JSONObject();
			    					jsonToPost.put("currentUsers", currentUsers);
			    					jsonToPost.put("totalRequests", totalRequests);
			    					jsonToPost.put("runDuration", trueDuration);
			    					jsonToPost.put("requestsPerSecond", requestsPerSecond);
			    					jsonToPost.put("avgResponseTime", avgResponseTime);
			    					jsonToPost.put("errorCount", errorCount);
			    					postToSplunk(jsonToPost);
			    				}
			    			}
			    		}
			    	} catch (Exception e) {
			    		// ignore for now as a bad single parse is acceptable
			    	} finally {
			    		// clean the log
			    		//CommandExecutor.execCommand("echo -n \"\" > " + logLocation, null);
			    		if (logCalcBufferedReader != null) {
			    			try { logCalcBufferedReader.close(); } catch (IOException e) { }
			    		}
			    	}
		    		
		    		trueDuration = (trueDuration + CALC_WAIT_SEC);
			    	try { Thread.sleep(CALC_WAIT_MS); } catch (InterruptedException e) { }
		    	}
		    }
        });
    	
    	for (Thread thread : jmeterThreads) {
		     thread.start();
		}
		for (Thread thread : jmeterThreads) {
		     try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
        
		// post the stop data to new relic
    	if (GridManager.isQALabHub() && newRelicAppId != null && newRelicAPIKey != null) {
    		String constructedCurl = "curl -X POST 'https://api.newrelic.com/v2/applications/" + newRelicAppId 
    	    		+ "/deployments.json' \\ -H 'X-Api-Key:" + newRelicAPIKey + "' -i \\ -H 'Content-Type: application/json' \\ -d \\ "
    	    		+ "'{\"deployment\": { \"revision\": \"MQE LOAD TEST STOP\", \"changelog\": \"Stopping MQE load test with " + finalThreadCount + "\""
    	    		+ ", \"description\": \"Stopping MQE load test\", \"user\": \"brandon.clark@viacom.com\" } }'";
    	    CommandExecutor.execCommand(constructedCurl, null);
    	}
		
        // terminate the jmeter servers
        if (GridManager.isQALabHub() && !runLocal) {
        	List<Thread> terminateJMeterThreads = new ArrayList<Thread>();
	    	for (String activeAgent : allActiveAgents) {
	    		terminateJMeterThreads.add(new Thread() {
	    		    public void run() {
	    		    	Logger.logConsoleMessage("Stopping JMeter agent machine '" + activeAgent + "'.");
	    		    	CommandExecutor.setTimeout(5);
	            		CommandExecutor.execCommand("open " + Constants.JMETER_STOP_NODE_PATH, activeAgent);
	    		    }
	            });
	    	}
	    	for (Thread thread : terminateJMeterThreads) {
			     thread.start();
			}
			for (Thread thread : terminateJMeterThreads) {
			     try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
        }
        
        // generate the dashboard report
        Logger.logConsoleMessage("Generating dashboard report from result file at '" + reportLocation + "' to reporting dashboard directory at '" 
            + reportDashboardDirLocation + ".");
        
    	// wait for the index file to be generated
    	File indexFile = new File(reportDashboardDirLocation + "/index.html");
    	Integer waitIter = 0;
    	while (!indexFile.exists()) {
    		if (waitIter == 30) {
    			throw new RuntimeException("Report dashboard index not present at '" + indexFile.getAbsolutePath() 
    			    + "' after 30 seconds.");
    		}
    		
    		// remove the last line of the file to avoid dashboard compilation issues
    		try {
    			RandomAccessFile randomAccessFile = new RandomAccessFile(reportLocation, "rw");
        		byte b;
        		long length = randomAccessFile.length() ;
        		if (length != 0) {
        		    do {
        		        length -= 1;
        		        randomAccessFile.seek(length);
        		        b = randomAccessFile.readByte();
        		    } while (b != 10 && length > 0);
        		    randomAccessFile.setLength(length);
        		    randomAccessFile.close();
        		}
    		} catch (Exception e) {
    			
    		}
    		
    		CommandExecutor.setTimeout(30);
            CommandExecutor.execMultiCommand(Constants.JMETER_PATH 
            		+ " -g " + reportLocation + " -o " + reportDashboardDirLocation + " -j " + logLocation);
            
    		waitIter++;
    		try { Thread.sleep(1000); } catch (InterruptedException e) { }
    	}
    	
        // modify the report output for viacom
        modifyReportForViacom();
    }
    
    // TODO - some redundant code here between this and the allure manager when uploading files to S3. Conslidate and clean up.
    public static HashMap<String, String> uploadReportsToS3(String projectBucketName) {
    	HashMap<String, String> reportUrls = new HashMap<String, String>();
    	if (GridManager.isQALabHub()) {
    		AmazonS3 amazon = new AmazonS3Client(new ProfileCredentialsProvider());
            
    		s3ProjectBucketName = projectBucketName;
    		s3ReportDir = RandomData.getCharacterString(20);
    		try {
            	SimpleDateFormat dirFormat = new SimpleDateFormat("MMddyyhhmmssSSSa");
            	s3ReportDir = s3ReportDir + dirFormat.format(new Date());
            	
            	TransferManager transferManager = new TransferManager(amazon);
            	MultipleFileUpload upload = transferManager.uploadDirectory("mqetestreports/" + s3ProjectBucketName, 
            			s3ReportDir, new File(reportDashboardDirLocation), true);
            	upload.waitForCompletion();
            	if (upload.getState().equals(TransferState.Completed)) {
            		s3ReportUrl = "https://s3.amazonaws.com/mqetestreports/" + s3ProjectBucketName + "/" + s3ReportDir + "/index.html";
            	    Logger.logConsoleMessage("Successfully uploaded test report to Amazon S3 at '" + s3ReportUrl + "'.");
            	}
            } catch (AmazonServiceException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            	Logger.logConsoleMessage("Status Code: " + e.getStatusCode());
            } catch (AmazonClientException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            } catch (InterruptedException e) {
    			e.printStackTrace();
    		}
            
            if (s3ReportUrl.isEmpty()) {
            	Logger.logConsoleMessage("Failed to upload jmeter dashboard to Amazon S3.");
            } else {
            	reportUrls.put("dashboardUrl", s3ReportUrl);
            }
            
            String s3HarFileUrl = null;
    		try {
    			amazon.putObject(new PutObjectRequest("mqetestreports/" + s3ProjectBucketName + "/" + s3ReportDir , "harlog.har", currentHarLog));
            	s3HarFileUrl = s3ReportUrl.replace("index.html", "") + "harlog.har";
            	Logger.logConsoleMessage("Successfully uploaded jmeter har log to report directory on Amazon S3 at '" + s3HarFileUrl + "'.");
            } catch (AmazonServiceException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            	Logger.logConsoleMessage("Status Code: " + e.getStatusCode());
            } catch (AmazonClientException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            }
            
            if (s3HarFileUrl == null) {
            	Logger.logConsoleMessage("Failed to upload test file to Amazon S3.");
            }
            reportUrls.put("harLogUrl", s3HarFileUrl);
            
            String s3LogFileUrl = null;
            File logFile = new File(logLocation);
    		try {
    			amazon.putObject(new PutObjectRequest("mqetestreports/" + s3ProjectBucketName + "/" + s3ReportDir , logFile.getName(), logFile));
            	s3LogFileUrl = s3ReportUrl.replace("index.html", "") + logFile.getName();
            	Logger.logConsoleMessage("Successfully uploaded jmeter log to report directory on Amazon S3 at '" + s3LogFileUrl + "'.");
            } catch (AmazonServiceException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            	Logger.logConsoleMessage("Status Code: " + e.getStatusCode());
            } catch (AmazonClientException e) {
            	Logger.logConsoleMessage("Error: " + e.getMessage());
            }
            
            if (s3LogFileUrl == null) {
            	Logger.logConsoleMessage("Failed to upload log file to Amazon S3.");
            }
            reportUrls.put("logUrl", s3LogFileUrl);
    	}
		
        return reportUrls;
    }
    
    private static File getJMeterXMLFile() {
    	return new File(testLocation);
    }
    
    private static Document getJMeterDocument() throws Exception {
    	File reportFile = getJMeterXMLFile();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setIgnoringElementContentWhitespace(true);
        return dbf.newDocumentBuilder().parse(reportFile);
    }
    
    private static XPathExpression getXPathExpression(String xpathQuery) throws Exception {
    	XPathFactory xpf = XPathFactory.newInstance();
        XPath xpath = xpf.newXPath();
        return xpath.compile(xpathQuery);
    }
    
    private static void cleanReportDir(String pathToReportDir) {
    	// check if report dir exists, clean if it does, else create it.
    	File reportDir = new File(pathToReportDir);
    	if (reportDir.exists()) {
    		try {
    			Logger.logConsoleMessage("Reporting directory exists at '" + pathToReportDir + "'. Cleaning...");
				FileUtils.cleanDirectory(reportDir);
			} catch (Exception e) {
				e.printStackTrace();
			}
    	} else {
    		Logger.logConsoleMessage("Reporting directory does not exist at '" + pathToReportDir + "'. Creating...");
    		reportDir.mkdirs();
    	}
    }
    
    private static void rebuildJMeterXML(Document inDocument) throws Exception {
    	TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.transform(new DOMSource(inDocument), new StreamResult(getJMeterXMLFile()));
    }
    
    private static void modifyReportForViacom() {
    	// TODO - most of this is data that should come from a resource file. Refactor as time allows.
    	
    	// get the generated report location
    	String reportLoc = reportDashboardDirLocation;
    	String data = null;
    	
    	// wait for the index file to be generated
    	File indexFile = new File(reportLoc + "/index.html");
    	Integer waitIter = 0;
    	while (!indexFile.exists()) {
    		if (waitIter == 30) {
    			throw new RuntimeException("Report dashboard index not present at '" + indexFile.getAbsolutePath() 
    			    + "' after 30 seconds.");
    		}
    		waitIter++;
    		try { Thread.sleep(1000); } catch (InterruptedException e) { }
    	}
    	
    	// update the dashboard header
    	data = getReportFileData(indexFile.getAbsolutePath());
    	updateReportFileData(indexFile.getAbsolutePath(), data.replace("Apache JMeter Dashboard", "MQE JMeter Dashboard"));
    	
    	// update the images
    	try {
			FileUtils.copyURLToFile(JMeterManager.class.getResource("/favicon.ico"), new File(reportLoc + "/content/pages/icon-apache.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    private static String getReportFileData(String filePath) {
    	InputStream inputStream = null;
    	String input = null;
    	try {
    		inputStream = new FileInputStream(filePath);
    		input = IOUtils.toString(new InputStreamReader(inputStream));
    	} catch (FileNotFoundException e) {
    		Logger.logConsoleMessage("Failed to find report file path at '" + filePath + "'.");
    		e.printStackTrace();
    	} catch (IOException e) {
    		Logger.logConsoleMessage("Failed to get report file data at '" + filePath + "'.");
    		e.printStackTrace();
    	}
    	
    	return input;
    }
    
    private static void updateReportFileData(String filePath, String input) {
    	// rewrite the json object in the allure report file
    	try {
    		FileWriter file = new FileWriter(filePath);
    		file.write(input);
    		file.close();
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to update the test report.");
    		e.printStackTrace();
    	}
    }
    
    private static String getJMeterItem(String query) {
    	String txtResult = null;
    	try {
    		Document document = getJMeterDocument();
    		XPathExpression expression = getXPathExpression(query);
            NodeList results = (NodeList) expression.evaluate(document, XPathConstants.NODESET);
            txtResult = results.item(0).getTextContent();
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to get jmeter test item with query '" + query + "'.");
    		e.printStackTrace();
    	}
    	return txtResult;
    }
    
    private static void updateJMeterItem(String query, String updatedValue) {
    	try {
    		Document document = getJMeterDocument();
            XPathExpression expression = getXPathExpression(query);
			NodeList results = (NodeList) expression.evaluate(document, XPathConstants.NODESET);
			results.item(0).setTextContent(updatedValue);
            rebuildJMeterXML(document);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to update the JMeter test item with query '" + query + "' to new value '" +  updatedValue + "'");
    		e.printStackTrace();
    	}
    }
    
    private static void updateAllJMeterItems(String query, String updatedValue) {
    	try {
    		Document document = getJMeterDocument();
            XPathExpression expression = getXPathExpression(query);
			NodeList results = (NodeList) expression.evaluate(document, XPathConstants.NODESET);
			for (int i = 0; i < results.getLength(); i++) {
            	Node node = results.item(i);
            	node.setTextContent(updatedValue);
            }
			rebuildJMeterXML(document);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to update the JMeter test items with query '" + query + "' to new value '" +  updatedValue + "'");
    		e.printStackTrace();
    	}
    }
    
    private static void insertJMeterBeanShell() {
    	Logger.logConsoleMessage("Adding beanshell assertion logic.");
    	// get the .jmx content
    	String startingContent = null;
    	try {
			startingContent = new String(Files.readAllBytes(Paths.get(testLocation)))
					.replace("\n", "").replace("\r", "").replace("\t", "").replaceAll(">\\s+<", "><");
		} catch (IOException e) {
			Logger.logConsoleMessage("Failed to get jmx content.");
			e.printStackTrace();
		}
    	
    	/* TODO - allow a user to enter custom beanshell
    	// construct the assertion to write desired data to the log file for splunking later
    	String assertion = "<BeanShellAssertion guiclass=\"BeanShellAssertionGui\" testclass=\"BeanShellAssertion\" "
    			+ "testname=\"BeanShell Assertion\" enabled=\"true\"><stringProp name=\"BeanShellAssertion.query\">"
    			+ "log.info(&quot;ENTRYSTART&lt;entry&gt;&lt;url&gt;&quot;+SampleResult.getUrlAsString()+&quot;&lt;/url&gt;&lt;responsecode&gt;&quot;"
    			+ "+SampleResult.getResponseCode()+&quot;&lt;/responsecode&gt;&lt;requestheaders&gt;&quot;+RequestHeaders.toString().replace(&quot; &quot;, &quot;&quot;)"
    			+ "+&quot;&lt;/requestheaders&gt;&lt;responsetime&gt;&quot;+SampleResult.getTime()+&quot;&lt;/responsetime&gt;&lt;/entry&gt;&quot;);"
    			+ "</stringProp><stringProp name=\"BeanShellAssertion.filename\">"
    			+ "</stringProp><stringProp name=\""
    			+ "BeanShellAssertion.parameters\"></stringProp><boolProp name=\"BeanShellAssertion.resetInterpreter\">"
    			+ "false</boolProp></BeanShellAssertion>";
    	
    	String endContent = startingContent.replace("</ResultCollector><hashTree/></hashTree></hashTree></hashTree></jmeterTestPlan>", 
    			"</ResultCollector><hashTree/>" + assertion + "<hashTree/></hashTree></hashTree></hashTree></jmeterTestPlan>");
    	*/
    	String endContent = startingContent;
    	
    	// reconstruct the jmx file
    	FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(new File(testLocation), false);
			fileWriter.write(endContent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (fileWriter != null) {
				    fileWriter.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
    }
    
    private static void updateMQEProxySettings(Integer proxyPort) {
    	Logger.logConsoleMessage("Updating requests to route through BMP proxy.");
    	String proxyHost = Constants.LAB_WEBDRIVER_HUB_IP;
    	if (!GridManager.isQALabHub()) {
    		proxyHost = "localhost";
    	}
    	updateAllJMeterItems("//*[contains(@name, 'proxyHost')]", proxyHost);
    	updateAllJMeterItems("//*[contains(@name, 'proxyPort')]", proxyPort.toString());
    	
    	// get the .jmx content
    	String startingContent = null;
    	try {
			startingContent = new String(Files.readAllBytes(Paths.get(testLocation)));
		} catch (IOException e) {
			Logger.logConsoleMessage("Failed to get jmx content.");
			e.printStackTrace();
		}
    	
    	// check if the doc already contains the proxy port entry
    	if (startingContent.contains("proxyHost")) {
    		updateAllJMeterItems("//*[contains(@name, 'proxyHost')]", proxyHost);
        	updateAllJMeterItems("//*[contains(@name, 'proxyPort')]", proxyPort.toString());
    	} else {
    		try {
				Document document = getJMeterDocument();
                XPathExpression expression = getXPathExpression("//stringProp[@name='HTTPSampler.domain']");
    			NodeList results = (NodeList) expression.evaluate(document, XPathConstants.NODESET);
    			for (int i = 0; i < results.getLength(); i++) {
                	Node node = results.item(i);
                	
                	Text hostText = document.createTextNode(proxyHost);
                	Element hostElement = document.createElement("stringProp");
                	hostElement.setAttribute("name", "HTTPSampler.proxyHost");
                	hostElement.appendChild(hostText);
                	node.getParentNode().insertBefore(hostElement, node);
                	
                	Text portText = document.createTextNode(proxyPort.toString());
                	Element portElement = document.createElement("stringProp");
                	portElement.setAttribute("name", "HTTPSampler.proxyPort");
                	portElement.appendChild(portText);
                	node.getParentNode().insertBefore(portElement, node);
                }
    			rebuildJMeterXML(document);
        	} catch (Exception e) {
        		Logger.logConsoleMessage("Failed to update the JMeter proxy/host entries");
        		e.printStackTrace();
        	}
    	}
    }
    
    private static void postToSplunk(JSONObject jsonToPost) {
    	String splunkUsername = Constants.SPLUNK_LAB_USERNAME;
		  String splunkPassword = Constants.SPLUNK_LAB_PASSWORD;
		  String splunkIndex = Constants.SPLUNK_LAB_JMETER_INDEX;
		  new SplunkManager().connectToSplunk(splunkUsername, splunkPassword)
		      .setIndex(splunkIndex)
	          .postEvent(jsonToPost.toJSONString());
    }
}
