package com.viacom.test.core.browserstack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import com.viacom.test.core.lab.CommandExecutor;
import com.viacom.test.core.util.Logger;

public class BrowserstackTunnelsManager {
	
	private static final String BROWSERSTACK_LOCAL = "BrowserStackLocal";
	private static final String START_BROWSERSTACK_SH = "LaunchBSTunnel.sh";
	private static final Integer TUNNEL_RETRY_COUNT = 2;
	private static String localTestBinaryPath = null;
	private static String localTestShPath = null;
	
	private static ThreadLocal<Integer> tunnelProxyPort = new ThreadLocal<Integer>();
	private static ThreadLocal<String> tunnelIdentifier = new ThreadLocal<String>();
	private static ThreadLocal<String> tunnelPID = new ThreadLocal<String>();
	
	public static void initTunneling() {
		Logger.logConsoleMessage("Copying browser stack local to working directory and enabling tunneling.");
		localTestBinaryPath = System.getProperty("user.dir") + "/" + BROWSERSTACK_LOCAL;
		localTestShPath = System.getProperty("user.dir") + "/" + START_BROWSERSTACK_SH;
		
		if (new File(localTestBinaryPath).exists()) {
		    CommandExecutor.execCommand("chmod 777 " + localTestBinaryPath, null);
		}
		
		if (new File(localTestShPath).exists()) {
		    CommandExecutor.execCommand("chmod 777 " + localTestShPath, null);
		}
		
		// extract browserstack local test binary to the working directory from the jar
		List<String> BSFiles = Arrays.asList(BROWSERSTACK_LOCAL, START_BROWSERSTACK_SH);
		for (String bsFile : BSFiles) {
			InputStream inputStream = BrowserstackTunnelsManager.class.getClassLoader().getResourceAsStream(bsFile);
			FileOutputStream fileOutputStream = null;
					
			try {
				fileOutputStream = new FileOutputStream(bsFile);
				byte[] buf = new byte[2048];
				int r = inputStream.read(buf);
				while(r != -1) {
					fileOutputStream.write(buf, 0, r);
					r = inputStream.read(buf);
				}
			} catch (Exception e) {
				Logger.logConsoleMessage("Failed to copy browserstack local test files to the local user's system.");
				e.printStackTrace();
			} finally {
				if (fileOutputStream != null) {
					try {
						fileOutputStream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
	}
	
	public static void startTunnel(Integer proxyPort, String tunnelID) {
		// remove write privelage from the BS binary so it doesn't auto update
		CommandExecutor.execCommand("chmod u=rx " + localTestBinaryPath, null);
		CommandExecutor.execCommand("chmod u=rx " + localTestShPath, null);
		
		// set the tunnel info
		tunnelProxyPort.set(proxyPort);
		tunnelIdentifier.set(tunnelID);
		
		// attempt to start the tunnel
		for (int i = 0; i < TUNNEL_RETRY_COUNT; i++) {
		    try {
		    	Logger.logConsoleMessage("Starting a BrowserStackLocal tunnel with identifier '" + tunnelIdentifier.get() 
		    		+ "' on proxy port '" + tunnelProxyPort.get().toString() + "'.");
		    	String command = "/bin/bash " + localTestShPath + " " + localTestBinaryPath + " " 
		    	    + BrowserstackCredentialManager.getBrowserstackKey() + " " + tunnelProxyPort.get().toString() + " " + tunnelIdentifier.get() + "";
		    	String tunnelResult = CommandExecutor.execCommand(command, null);
		    	if (tunnelResult.contains("Connected")) {
		    		tunnelPID.set(tunnelResult.split("\"pid\":")[1].split(",")[0]);
		    		break;
		    	} else {
		    		Logger.logConsoleMessage("Browserstack tunnel did not succesfully connect. Retrying...");
		    	}
		    } catch (Exception e) {
		    	Logger.logConsoleMessage("Failed to spin up a BrowserStackLocal tunnel on with proxy port '" + tunnelProxyPort.get().toString() 
		    		+ ". Retrying...");
		        	e.printStackTrace();
		    }
		}
	}
	
	public static void stopTunnel() {
		if (tunnelPID.get() != null) {
			Logger.logConsoleMessage("Stopping BrowserstackLocal tunnel on thread '" + Thread.currentThread().getId() + "'.");
			CommandExecutor.execCommand("kill -9 " + tunnelPID.get(), null);
		}
	}
	
	public static void closeAllBrowserStackTunnels() {
		Logger.logConsoleMessage("Stopping all BrowserStackLocal tunnels.");
		CommandExecutor.execCommand("killall " + BROWSERSTACK_LOCAL, null);
	}
	
	public static String getTunnelIdentifier() {
		return tunnelIdentifier.get();
	}
   
}
