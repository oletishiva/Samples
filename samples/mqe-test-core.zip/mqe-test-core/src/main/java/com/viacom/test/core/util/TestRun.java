package com.viacom.test.core.util;

import com.viacom.test.core.props.DeviceCategory;
import com.viacom.test.core.props.EmergingOS;
import com.viacom.test.core.props.MobileOS;

public class TestRun {

	private static ThreadLocal<MobileOS> mobileOS = new ThreadLocal<MobileOS>();
	private static ThreadLocal<EmergingOS> emergingOS = new ThreadLocal<EmergingOS>();
    private static ThreadLocal<DeviceCategory> deviceCategory = new ThreadLocal<DeviceCategory>();
    private static ThreadLocal<Boolean> mobile = new ThreadLocal<Boolean>();
    private static ThreadLocal<Boolean> sauceRun = new ThreadLocal<Boolean>();
    private static ThreadLocal<Boolean> browserstackRun = new ThreadLocal<Boolean>();
    private static ThreadLocal<Boolean> labRun = new ThreadLocal<Boolean>();
    private static ThreadLocal<Boolean> ios10Run = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    private static ThreadLocal<Boolean> selendroidRun = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    private static ThreadLocal<Boolean> simulatorRun = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    private static ThreadLocal<Boolean> mobileWebRun = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
    
    public static synchronized void setMobile(Boolean isMobile) {
        TestRun.mobile.set(isMobile);
    }
    
    public static synchronized void setSauceRun(Boolean isSauceRun) {
        TestRun.sauceRun.set(isSauceRun);
    }
    
    public static synchronized void setBrowserstackRun(Boolean isBrowserstackRun) {
        TestRun.browserstackRun.set(isBrowserstackRun);
    }
    
    public static synchronized void setLabRun(Boolean isLabRun) {
        TestRun.labRun.set(isLabRun);
    }
    
    public static synchronized void setMobileOS(MobileOS mobileOS) {
        TestRun.mobileOS.set(mobileOS);
    }
    
    public static synchronized MobileOS getMobileOS() {
        return TestRun.mobileOS.get();
    }
    
    public static synchronized void setDeviceCategory(DeviceCategory deviceCategory) {
        TestRun.deviceCategory.set(deviceCategory);
    }
    
    public static synchronized DeviceCategory getDeviceCategory() {
        return deviceCategory.get();
    }
    
    public static synchronized void setSelendroidRun(Boolean isSelendroid) {
    	selendroidRun.set(isSelendroid);
    }
    
    public static synchronized Boolean isIos() {
    	return getMobileOS().equals(MobileOS.IOS);
    }
    
    public static synchronized Boolean isIosSim() {
    	return getMobileOS().equals(MobileOS.IOS_SIM);
    }
    
    public static synchronized void setIOS10(Boolean isiOS10) {
    	ios10Run.set(isiOS10);
    }
    
    public static synchronized Boolean isIos10() {
    	return ios10Run.get();
    }
    
    public static synchronized void setSimulatorRun(Boolean isSimulatorRun) {
    	simulatorRun.set(isSimulatorRun);
    }
    
    public static synchronized Boolean isSimulator() {
    	return simulatorRun.get();
    }
    
    public static synchronized void setMobileWebRun(Boolean isMobileWebRun) {
    	mobileWebRun.set(isMobileWebRun);
    }
    
    public static synchronized Boolean isMobileWeb() {
    	return mobileWebRun.get();
    }
    
    public static synchronized Boolean isAndroid() {
    	return getMobileOS().equals(MobileOS.ANDROID);
    }
    
    public static synchronized Boolean isAndroidSim() {
    	return getMobileOS().equals(MobileOS.ANDROID_SIM);
    }
    
    public static synchronized Boolean isPhone() {
    	return getDeviceCategory().equals(DeviceCategory.PHONE);
    }
    
    public static synchronized Boolean isTablet() {
    	return getDeviceCategory().equals(DeviceCategory.TABLET);
    }
    
    public static synchronized Boolean isMobile() {
    	return mobile.get();
    }
    
    public static synchronized Boolean isSauceRun() {
    	return sauceRun.get();
    }
    
    public static synchronized Boolean isBrowserstackRun() {
    	return browserstackRun.get();
    }
    
    public static synchronized Boolean isLabRun() {
    	return labRun.get();
    }
    
    public static synchronized Boolean isSelendroid() {
    	return selendroidRun.get();
    }
    
    public static synchronized void setEmergingOS(EmergingOS emergingOS) {
        TestRun.emergingOS.set(emergingOS);
    }
    
    public static synchronized EmergingOS getEmergingOS() {
        return TestRun.emergingOS.get();
    }
    
    public static synchronized Boolean isAppleTV() {
        return emergingOS.get().equals(EmergingOS.APPLE_TV);
    }
    
    public static synchronized Boolean isRoku() {
        return emergingOS.get().equals(EmergingOS.ROKU);
    }
    
}
