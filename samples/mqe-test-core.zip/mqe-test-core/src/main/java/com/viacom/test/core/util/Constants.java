package com.viacom.test.core.util;

public class Constants {

	// TODO - a lot of these values should go into the config in resources. Core task as time allows...
	public static final String LAB_WEBDRIVER_HUB_ADDRESS = "localhost";
	public static final String LAB_WEBDRIVER_HUB_IP = "10.15.15.10";
	public static final String LAB_IOS_HUB_PORT = "4445";
	public static final String LAB_IOS_SIM_HUB_PORT = "4448";
	public static final String LAB_ANDROID_HUB_PORT = "4446";
	public static final String LAB_ANDROID_SIM_HUB_PORT = "4447";
	public static final String LAB_WEB_HUB_PORT = "4443";
	public static final String LAB_CONFIG_PATH = "/Users/mqeadmin/.jenkins/userContent/LabConfig.json";
	public static final String EC2_LAB_CONFIG_PATH = "/Users/mqeadmin/.jenkins/userContent/EC2LabConfig.json";
	public static final String GRID_HUB_MACHINE_NAME = "MQEMACPRO-01.local";
	public static final String HUB_APP_PACKAGE_DIR = "/Users/mqeadmin/AppPackages/";
	public static final String NODE_APP_PACKAGE_DIR = "/Users/admin/AppPackages/";
	public static final String HUB_APPIUM_LOG_DIR = "/Users/mqeadmin/AppiumLogs";
	public static final String NODE_APPIUM_LOG_IOS = "/Users/admin/appiumlog_ios.log";
	public static final String NODE_APPIUM_LOG_ANDROID = "/Users/admin/appiumlog_android.log";
	public static final String DEVICE_ID = "deviceID";
	public static final String STATUS = "status";
	public static final String MACHINE_NAME = "machineName";
	public static final String DEVICE_CODE = "deviceCode";
	public static final String DEVICE_OS_VERSION = "deviceOSVersion";
	public static final String DEVICE_CATEGORY = "deviceCategory";
	public static final String DEVICE_NAME = "deviceName";
	public static final String DEVICE_PROXY_PORT = "deviceProxyPort";
	public static final String ACTIVE = "active";
	public static final String INACTIVE = "inactive";
	public static final String DISABLED = "disabled";
	public static final String PACKAGE_DATE_FORMAT = "MMddyyhhmmss";
	public static final String CODE_RESIGN_CERTIFICATE = "DE41EC9E6C117F86497473CBE7855ABCF0AD3ABE";

	public static final Integer PROXY_LOG_TIMEOUT_S = 10;
	public static final Integer PROXY_LOG_POLLING_MS = 500;
	public static final Integer DRIVER_RECYLE_TIMEOUT_MS = 5000;
	public static final Integer DRIVER_NODE_RECYLE_PAUSE_MS = 15000;
	public static final Integer DEVICE_REBOOT_PAUSE_MS = 60000;
	public static final Integer DEVICE_HOME_ELEMENT_TIMEOUT_S = 30;
	public static final Integer DEVICE_WAIT_QUEUE_MAX_ITER = 500; // 1 iter = 10 second wait
	public static final Integer DEVICE_WAIT_QUEUE_SLEEP_MS = 10000;
	public static final Integer INACTIVE_DEVICE_MAX = 5;
	public static final Integer MAX_DEVICE_INSTALL_FAILS = 2;
	
	public static final String HUDSON_HOST = "hudson.mtvi.com";
	public static final String HUDSON_SYSTEM_PROP_USERNAME = "system.test.hudsonusername";
	public static final String HUDSON_SYSTEM_PROP_PASSWORD = "system.test.hudsonpassword";
	
	public static final String I_DEVICE_PATH = "/usr/local/Cellar/ideviceinstaller/HEAD/bin/ideviceinstaller";
	public static final String I_DEVICE_DIAGNOSTICS_PATH = "/usr/local/Cellar/libimobiledevice/1.2.0/bin/idevicediagnostics";
	public static final String ADB_PATH = "/usr/local/Cellar/android-platform-tools/23.0.1/bin/adb";
	
	public static final String ADB_SDCARD_TEST_PATH = "/sdcard/test";
	public static final String SCREEN_RECORD = "screenrecord";
	public static final String IOS_SCREEN_RECORD = "iosscreenrecord";
	public static final String ANDROID_SCREEN_RECORD_COMMAND_PATH = "/Users/admin/Desktop/startAndroidScreenRecording.command";
	public static final String IOS_SCREEN_RECORD_COMMAND_PATH = "/Users/admin/Desktop/startiOSScreenRecording.scpt";
	public static final String IOS_STOP_SCREEN_RECORD_COMMAND_PATH = "/Users/admin/Desktop/stopiOSScreenRecording.scpt";
	public static final String IOS_KILL_REMOTE_NODE_PATH = "/Users/admin/Desktop/KillRemoteiOSNode.command";
	public static final String IOS_SIM_KILL_REMOTE_NODE_PATH = "/Users/admin/Desktop/KillRemoteiOSSimNode.sh";
	public static final String ANDROID_KILL_REMOTE_NODE_PATH = "/Users/admin/Desktop/KillRemoteAndroidNode.command";
	public static final String ANDROID_SIM_KILL_REMOTE_NODE_PATH = "/Users/admin/Desktop/KillRemoteAndroidSimNode.sh";
	public static final String WEB_KILL_REMOTE_NODE_PATH = "/Users/admin/Desktop/KillRemoteWebNode.command";
	public static final String WEB_KILL_REMOTE_NODE_PATH_WIN = "/cygdrive/c/Selenium/KillRemoteWebNode.bat";
	public static final String IOS_START_REMOTE_NODE_PATH = "/Users/admin/Desktop/StartNode_iOS.command";
	public static final String IOS_START_WEB_DEBUGGER_PATH = "/Users/admin/CommandScripts/StartiOSWebDebugProxy.command";
	public static final String IOS_STOP_WEB_DEBUGGER_PATH = "/Users/admin/CommandScripts/StopiOSWebDebugProxy.command";
	public static final String IOS_SIM_START_REMOTE_NODE_PATH = "/Users/admin/Desktop/StartNode_iOS_Sim.command";
	public static final String ANDROID_START_REMOTE_NODE_PATH = "/Users/admin/Desktop/StartNode_Android.command";
	public static final String ANDROID_SIM_START_REMOTE_NODE_PATH = "/Users/admin/Desktop/StartNode_Android_Sim.command";
	public static final String WEB_START_REMOTE_NODE_PATH = "/Users/admin/Desktop/StartNode_Web.command";
	public static final String WEB_START_REMOTE_NODE_PATH_WIN = "/cygdrive/c/Selenium/StartNode_Web.bat";
	
	public static final String FFMPEG_DIR = "/usr/local/Cellar/ffmpeg";
	public static final String MP4_EXT = ".mp4";
	public static final String FLV_EXT = ".flv";
	public static final String MOV_EXT = ".mov";
	public static final long INVALID_FILE_SIZE = 50;
	public static final long INVALID_APP_FILE_SIZE= 262144;
	public static final String APK_EXT = ".apk";
	public static final String IPA_EXT = ".ipa";
	public static final String ZIP_EXT = ".zip";
	public static final String JMX_EXT = ".jmx";
	public static final String HTTP = "http";
	
	public static final Integer DRIVER_MAX_SESSION_ATTEMPTS = 2;
	public static final String DRIVER_FAILURE_EMAIL_ADDRESS = "brandon.clark@viacom.com";
	public static final String DRIVER_FAILURE_EMAIL_SENDER_ADDRESS = "NOREPLY@MQE-DRIVER-MONITORING.com";
	
	public static final String SPLUNK_PATH = "/Applications/Splunk/bin/splunk";
	public static final String SPLUNK_GLOBAL_TEST_DATA_DIR = "/Users/mqeadmin/splunkdata/globaltestdata/";
	public static final Integer SPLUNK_MAX_POST_SIZE = 512000;
	public static final String SPLUNK_LAB_USERNAME = System.getProperty("system.test.splunkusername");
	public static final String SPLUNK_LAB_PASSWORD = System.getProperty("system.test.splunkpassword");
	public static final String SPLUNK_LAB_GLOBAL_INDEX = "globaltestdata";
	public static final String SPLUNK_LAB_JMETER_INDEX = "jmetersummarytestdata";
	
	public static final String SELENDROID = "Selendroid";
	
	public static final String BMP_CER = "MQE_BMP_Certificate.cer";
	public static final String BMP_PEM = "MQE_BMP_Private-key.pem";
	public static final String BMP_PASS = "mqe1515";
	
	public static final String JMETER_PATH = "/Applications/jmeter/bin/jmeter";
	public static final String JMETER_START_NODE_PATH = "/Users/admin/Desktop/StartJMeterServer.command";
	public static final String JMETER_STOP_NODE_PATH = "/Users/admin/Desktop/StopJMeterServer.command";
	public static final Integer JMETER_AGENT_THREAD_LIMIT = 100;
	public static final Integer JMETER_DURATION_LIMIT = 900;
	public static final Integer JMETER_LOOP_COUNT_LIMIT = 1000;
	
	public static final String MQE_LAB_DB_NAME = "MQELab";
	public static final String MQE_LAB_DB_HOST = "localhost";
	public static final Integer MQE_LAB_DB_PORT = 5432;
	public static final String MQE_LAB_DB_USER = "mqeadmin";
	public static final String MQE_LAB_DB_AGENT_MACHINES = "agentmachines";
	public static final String MQE_LAB_DB_IOS_DEVICES = "iosdevices";
	public static final String MQE_LAB_DB_APPLE_TV_DEVICES = "appletvdevices";
	public static final String MQE_LAB_DB_ROKU_DEVICES = "rokudevices";
	public static final String MQE_LAB_DB_IOS_SIMULATORS = "iossimulators";
	public static final String MQE_LAB_DB_ANDROID_DEVICES = "androiddevices";
	public static final String MQE_LAB_DB_ANDROID_SIMULATORS = "androidsimulators";
	public static final String MQE_LAB_DB_BROWSER_NODES = "browsernodes";
	
	public static final String HUB_HUE_BRIDGE_IP = "10.15.17.9";
	public static final String HUB_HUE_USER_ID = "dKTiE-bj-Z9ZJDTRUQI4fwg61hhaiqKePD9iTDYE7";
	
}
