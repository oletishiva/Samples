package com.viacom.test.core.lab;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateName;
import com.amazonaws.services.ec2.model.Placement;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;

import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;

public class EC2Manager {

	private static final String EC2 = "EC2";
	private static final String LAST_RUN_TIME_FORMAT = "MM:dd:yyyy HH:mm:ss";
	private static final String LAST_RUN_START_TIME = "lastRunStartTime";
	private static final String CURRENTLY_RUNNING = "currentlyRunning";
	private static final String MAX_NUM_ALLOWED_NODES = "maxNumAllowedNodes";
	private static final String MQE_GRID_NODE = "MQE-Grid-Node-";
	
	private static final String IMAGE_ID = "ami-bbd50edb";
	private static final String SECURITY_GROUP_NAME = "Viacom MQE Selenium Grid";
	private static final String INSTANCE_TYPE = "t2.medium";
	private static final String KEY_NAME = "JMeter-webdriver";
	
	private static List<String> instanceIds = new ArrayList<String>();
	
	public static synchronized String getLastRunStartTime() {
		String lastRunTime = null;
		try {
    		JSONParser parser = new JSONParser();
    		JSONObject jsonObj = (JSONObject) parser.parse(getEC2LabConfigFileData());
    		JSONObject ec2Obj = (JSONObject) jsonObj.get(EC2);
    		lastRunTime = (String) ec2Obj.get(LAST_RUN_START_TIME);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to retrieve last run start time.");
    		e.printStackTrace();
    	}
    	return lastRunTime;
	}
	
	@SuppressWarnings("unchecked")
	public static synchronized void setLastRunStartTime() {
		try {
    		JSONParser parser = new JSONParser();
    		JSONObject jsonObj = (JSONObject) parser.parse(getEC2LabConfigFileData());
    		
    		JSONObject ec2Obj = (JSONObject) jsonObj.get(EC2);
    		DateFormat dateFormat = new SimpleDateFormat(LAST_RUN_TIME_FORMAT);
    		ec2Obj.put(LAST_RUN_START_TIME, dateFormat.format(new Date()));
    		
    		FileWriter file = new FileWriter(Constants.EC2_LAB_CONFIG_PATH);
    		file.write(jsonObj.toJSONString());
    		file.close();
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to set the last run start time.");
    		e.printStackTrace();
    	}
	}
    
	public static synchronized Boolean getCurrentlyRunning() {
		Boolean lastRunTime = null;
		try {
    		JSONParser parser = new JSONParser();
    		JSONObject jsonObj = (JSONObject) parser.parse(getEC2LabConfigFileData());
    		JSONObject ec2Obj = (JSONObject) jsonObj.get(EC2);
    		lastRunTime = (Boolean) ec2Obj.get(CURRENTLY_RUNNING);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to retrieve currently running status.");
    		e.printStackTrace();
    	}
    	return lastRunTime;
	}
	
	@SuppressWarnings("unchecked")
	public static synchronized void setCurrentlyRunning(Boolean isRunning) {
		try {
    		JSONParser parser = new JSONParser();
    		JSONObject jsonObj = (JSONObject) parser.parse(getEC2LabConfigFileData());
    		
    		JSONObject ec2Obj = (JSONObject) jsonObj.get(EC2);
    		ec2Obj.put(CURRENTLY_RUNNING, isRunning);
    		
    		FileWriter file = new FileWriter(Constants.EC2_LAB_CONFIG_PATH);
    		file.write(jsonObj.toJSONString());
    		file.close();
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to set the currently running status.");
    		e.printStackTrace();
    	}
	}
	
	public static synchronized Integer getMaxNumAllowedNodes() {
		Long maxNumAllowedNodes = 1L;
		try {
    		JSONParser parser = new JSONParser();
    		JSONObject jsonObj = (JSONObject) parser.parse(getEC2LabConfigFileData());
    		JSONObject ec2Obj = (JSONObject) jsonObj.get(EC2);
    		maxNumAllowedNodes = (Long) ec2Obj.get(MAX_NUM_ALLOWED_NODES);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to retrieve currently running status.");
    		e.printStackTrace();
    	}
    	return Integer.valueOf(maxNumAllowedNodes.intValue());
	}
	
	public static synchronized void startEC2Instances() {
		try {
			AmazonEC2 ec2 = new AmazonEC2Client(new ProfileCredentialsProvider());
			
			// log the instance start time to the config
			setLastRunStartTime();
			setCurrentlyRunning(true);
			
			// check if the instances are already running
			if (getAllRunningEC2Instances().isEmpty()) {
				// set the max number of available threads (TODO this could get complicated so re-evaluate as needed)
				Integer instanceCount = 1;
				Integer maxAllowedInstances = getMaxNumAllowedNodes();
				if (maxAllowedInstances != null) {
					instanceCount = maxAllowedInstances;
				}
				
				// instance request details
				RunInstancesRequest runInstancesRequest = new RunInstancesRequest();
				Placement placement = new Placement();
				placement.setAvailabilityZone("us-west-2a");
				ArrayList<String> securityGroups = new ArrayList<String>();
			 	securityGroups.add(SECURITY_GROUP_NAME);
	            runInstancesRequest.withImageId(IMAGE_ID)
			        .withInstanceType(INSTANCE_TYPE)
					.withMinCount(1)
					.withMaxCount(instanceCount)
					.withKeyName(KEY_NAME)
					.withSecurityGroups(securityGroups);
					
	            // start the instances
	            RunInstancesResult runResults = ec2.runInstances(runInstancesRequest);
	            
	            // get the instance ids
	            List<Instance> instances = runResults.getReservation().getInstances();
	            for (Instance instance : instances) {
	            	instanceIds.add(instance.getInstanceId());
	            }
	            
	            // tag the instances
	            int i = 1;
	            for (Instance instance : instances) {
	                CreateTagsRequest createTagsRequest = new CreateTagsRequest();
	                createTagsRequest.withResources(instance.getInstanceId())
	                    .withTags(new Tag("Name", MQE_GRID_NODE + i));
	                ec2.createTags(createTagsRequest);
	                i++;
	            }
			}
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to start the EC2 instances.");
    		e.printStackTrace();
    	}
	}
	
	public static synchronized Boolean shouldTerminateInstances() {
		Boolean terminateInstances = false;
		
		// are any instances running?
		if (!getAllRunningEC2Instances().isEmpty()) {
			// get the last run start time
			String dateTime = getLastRunStartTime();
			DateFormat format = new SimpleDateFormat(LAST_RUN_TIME_FORMAT);
			Date dateStarted = null;
			try {
				dateStarted = format.parse(dateTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			// add 55 minutes to the last run start time
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dateStarted);
			calendar.add(Calendar.MINUTE, 55);
			Date dateStartedPlusCutoff = calendar.getTime();
			
			// check if it's been more than 55 minutes since the instances were spun up
			Date dateNow = new Date();
			if (dateNow.compareTo(dateStartedPlusCutoff) > 0) {
				// check if any jobs are actively running
				HttpClient httpclient = HttpClientBuilder.create().build();
		        HttpGet request = new HttpGet("http://mqe.viacom.com:8080/api/xml?tree=jobs[name,url,color]"
		        		+ "&xpath=/hudson/job[ends-with(color/text(),%22_anime%22)]&wrapper=jobs");

		        String failureMsg = "Failed to get running list of MQE QA Jenkins jobs.";
		        HttpResponse response = null;
		        try {
		        	response = httpclient.execute(request);
		        } catch (Exception e) {
		        	Logger.logConsoleMessage(failureMsg);
		        	e.printStackTrace();
		        }
		        
		        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
		            Logger.logConsoleMessage(failureMsg);
		            Logger.logConsoleMessage(response.getStatusLine().getReasonPhrase());
		        } else {
		        	try {
		            	InputStream input = response.getEntity().getContent();
		                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
		                StringBuilder sb = new StringBuilder();
		                String line = null;
		                while ((line = reader.readLine()) != null) {
		                    sb.append(line).append("\n");
		                }
		                input.close();
		                
		                String responseBody = sb.toString();
		                JSONParser parser = new JSONParser();
		                if (!parser.parse(responseBody).toString().contains("-Web")) {
		                    terminateInstances = true;
		                }
		            } catch (Exception e) {
		            	Logger.logConsoleMessage(failureMsg);
		            	e.printStackTrace();
		            }
		        }
			}
		}
		
		return terminateInstances;
	}
	
	public static synchronized void terminateAllEC2Instances() {
		try {
			AmazonEC2 ec2 = new AmazonEC2Client(new ProfileCredentialsProvider());
			
			if (!getAllRunningEC2Instances().isEmpty()) {
				TerminateInstancesRequest terminateRequest = new TerminateInstancesRequest();
				terminateRequest.setInstanceIds(getAllRunningEC2Instances());
				ec2.terminateInstances(terminateRequest);
			}
		
			setCurrentlyRunning(false);
    	} catch (Exception e) {
    		Logger.logConsoleMessage("Failed to terminate the EC2 instances.");
    		e.printStackTrace();
    	}
	}
	
	private static synchronized List<String> getAllRunningEC2Instances() {
		AmazonEC2 ec2 = new AmazonEC2Client(new ProfileCredentialsProvider());
		
		List<String> instances = new ArrayList<String>();
	    for (Reservation reservation : ec2.describeInstances().getReservations()) {
	        for (Instance instance : reservation.getInstances()) {
	            if (instance.getState().getName().contains(InstanceStateName.Running.toString())) {
	            	for (Tag tag : instance.getTags()) {
	            		if (tag.getKey().contains("Name") && tag.getValue().contains(MQE_GRID_NODE)) {
		                	instances.add(instance.getInstanceId());
		                }
		            }
	            }
	        }
	    }
	    
	    return instances;
	}
	
	private static synchronized String getEC2LabConfigFileData() {
    	InputStream inputStream = null;
    	String input = null;
    	String configFilePath = Constants.EC2_LAB_CONFIG_PATH;
    	try {
    		inputStream = new FileInputStream(configFilePath);
    		input = IOUtils.toString(new InputStreamReader(inputStream));
    	} catch (FileNotFoundException e) {
    		Logger.logConsoleMessage("Failed to find lab config file path at '" + configFilePath + "'.");
    		e.printStackTrace();
    	} catch (IOException e) {
    		Logger.logConsoleMessage("Failed to get json data from lab config file path at '" + configFilePath + "'.");
    		e.printStackTrace();
    	} finally {
    		try {
				inputStream.close();
			} catch (IOException e) {
				Logger.logConsoleMessage("Failed to close the lab config input stream.");
				e.printStackTrace();
			}
    	}
    	
    	return input;
    }
    
}
