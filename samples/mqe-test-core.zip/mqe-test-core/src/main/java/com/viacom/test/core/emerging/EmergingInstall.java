package com.viacom.test.core.emerging;

import java.io.File;
import java.text.SimpleDateFormat;

import java.util.Date;

import com.viacom.test.core.lab.LabDeviceManager;
import com.viacom.test.core.props.EmergingOS;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.RandomData;

public class EmergingInstall {

	private static ThreadLocal<String> appFileName = new ThreadLocal<String>();
	
	public static void downloadAppPackage(EmergingOS emergingOS, String appPackageUrl) {
		SimpleDateFormat dateTimeFormat = new SimpleDateFormat(Constants.PACKAGE_DATE_FORMAT);
		
	    String appExt = null;
		if (emergingOS.equals(EmergingOS.APPLE_TV)) {
			appExt = ".app";
		} else if (emergingOS.equals(EmergingOS.ROKU)) {
			appExt = ".zip";
		}
		
		// download the app on the core machine
		appFileName.set(RandomData.getCharacterString(10) + dateTimeFormat.format(new Date()) + appExt);
		
		Integer maxDownloadAtt = 2;
		Boolean downloadSuccess = false;
		Integer downloadIter = 0;
		while (!downloadSuccess && downloadIter < maxDownloadAtt) {
			try {
		        LabDeviceManager.downloadAppPackage(null, appPackageUrl, appFileName.get());
			} catch (Exception e) {
				Logger.logConsoleMessage("App package timed out during download.");
			}
			
			// check the file size of the downloaded package to ensure it's valid
		    File file = new File(Constants.HUB_APP_PACKAGE_DIR + appFileName.get());
		    if (file.exists() && file.length() > Constants.INVALID_APP_FILE_SIZE) {
		    	downloadSuccess = true;
		    } else {
		    	Logger.logConsoleMessage("App package failed to download successfully on attempt '" 
		            + downloadIter + "'. Retrying...");
		    }
		    
		    downloadIter++;
		}
		
		if (!downloadSuccess) {
			throw new RuntimeException("The app package did not download successfully after '" 
		        + maxDownloadAtt + "' attempts.");
		}
	}
	
	public static String getHubAppFilePath() {
		return Constants.HUB_APP_PACKAGE_DIR + appFileName.get();
	}

}
