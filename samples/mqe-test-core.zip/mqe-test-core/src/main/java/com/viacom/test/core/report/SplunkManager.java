package com.viacom.test.core.report;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.splunk.Args;
import com.splunk.HttpService;
import com.splunk.SSLSecurityProtocol;
import com.splunk.Service;
import com.splunk.ServiceArgs;
import com.viacom.test.core.lab.CommandExecutor;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;

public class SplunkManager {
	
	private final String HOST = "10.15.15.10"; // TODO - config
	private final Integer PORT = 8089; // TODO - config
	private Service service = null;
	private com.splunk.Index index = null;
	
	private static ThreadLocal<Boolean> splunkConnectSuccess = new ThreadLocal<Boolean>() {
    	protected Boolean initialValue() {
    		return false;
    	}
    };
	
	/**********************************************************************************************
     * Sets the username, password, and host/port for the splunk instance.
     * 
     * @param username - {@link String} - The splunk username.
     * @param password - {@link String} - The splunk password.
     * @author Brandon Clark created March 23, 2016
     * @version 1.0.0 March 23, 2016
     ***********************************************************************************************/
	public SplunkManager connectToSplunk(String username, String password) {
		try {
			// set the username, password, and host/port values
			ServiceArgs loginArgs = new ServiceArgs();
			loginArgs.setUsername(username);
			loginArgs.setPassword(password);
			loginArgs.setHost(HOST);
			loginArgs.setPort(PORT);
			
			// login to the splunk instance and set the splunk service
			HttpService.setSslSecurityProtocol(SSLSecurityProtocol.TLSv1_2);
			service = Service.connect(loginArgs);
			splunkConnectSuccess.set(true);
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to connect to splunk. Checking if splunk is online and restarting...");
			Logger.logConsoleMessage(e.getMessage());
			try {
				Logger.logConsoleMessage(CommandExecutor.execCommand(Constants.SPLUNK_PATH + " start", null));
			} catch(Exception e1) {
				Logger.logConsoleMessage("Failed to restart splunk.");
			}
		}
		
		return this;
	}
	
	/**********************************************************************************************
     * Sets the index of the splunk instance you wish to post data to.
     * 
     * @param indexName - {@link String} - The name of the index to post to i.e. "videoplayer".
     * @author Brandon Clark created March 23, 2016
     * @version 1.0.0 March 23, 2016
     ***********************************************************************************************/
	public SplunkManager setIndex(String indexName) {
		try {
			// set the index you wish to post data to
			if (splunkConnectSuccess.get()) {
			    index = service.getIndexes().get(indexName);
			}
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to get splunk index '" + indexName + "'.");
			Logger.logConsoleMessage(e.getMessage());
		}
		
		return this;
	}
	
	/**********************************************************************************************
     * Posts a fully constructed json block to splunk as a splunk event. NOTE - all link breaks are trimmed
     * from the event body automatically to prevent problematic event references in splunk.
     * 
     * @param eventJson - {@link String} - A fully constructed and valid json object.
     * @author Brandon Clark created March 23, 2016
     * @version 1.0.0 March 23, 2016
     ***********************************************************************************************/
	public SplunkManager postEvent(String eventJson) {
		// check that the json is valid
		if (isJSONValid(eventJson) && splunkConnectSuccess.get()) {
			// strip out extraneous space
			String eventJsonClean = eventJson.replace("\n", "").replace("\r", "");
			
			// get the size of the post
			Integer sizeOfPost = eventJsonClean.getBytes().length;
			Logger.logConsoleMessage("Requesting splunk post with event size: " + sizeOfPost);
			
			if (sizeOfPost <= Constants.SPLUNK_MAX_POST_SIZE) {
				try {
					// post the json formatted event
					Args eventArgs = new Args();
					eventArgs.put("sourcetype", "json");
					index.submit(eventArgs, eventJsonClean);
				} catch (Exception e) {
					Logger.logConsoleMessage("Failed to post event to splunk.");
					Logger.logConsoleMessage(e.getMessage());
				}
			} else {
			    Logger.logConsoleMessage("Splunk post was not completed as splunk event request exceeded "
			    	+ "max size of: " + Constants.SPLUNK_MAX_POST_SIZE);
			}
		} else {
			Logger.logConsoleMessage("The splunk json request is not valid json.");
		}
		
		return this;
	}
	
	private boolean isJSONValid(String json) {
	    try {
	        new JSONObject(json);
	        return true;
	    } catch (JSONException objectException) {
	        try {
	            new JSONArray(json);
	            return true;
	        } catch (JSONException arrayException) {
	            return false;
	        }
	    }
	}
	
}
