package com.viacom.test.core.report;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

import com.viacom.test.core.lab.GridManager;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;

public class HueLighting {

	private static String hueLightID = null;
	private static String color;
	private static Boolean singleFailPolicy = false;
	
	public static void enableSingleFailPolicy() {
		singleFailPolicy = true;
	}
	
	public static void setTestSuiteStart(String hueLightID) {
		HueLighting.hueLightID = hueLightID;
        color = "46920"; // blue (test run starting)
		String payload = "{\"on\":true, \"sat\":250, \"bri\":45, \"hue\":" + color + "}";
        setLightState(payload);
	}
	
	public static void setTestSuiteResult(Integer passTestCount, Integer failTestCount) {
		Integer totalCount = passTestCount + failTestCount;
		Double failurePerc = (double) failTestCount / totalCount;
		if (singleFailPolicy) {
			if (failTestCount > 0) {
				color = "0"; // red (failed)
			} else {
				color = "25717"; // green (success)
			}
		} else {
			if (failTestCount == 0 || failurePerc < 0.05) {
				color = "25717"; // green (success)
			} else if (failurePerc < 0.10) {
				color = "33920"; // yellow
			} else {
				color = "0"; // red (failed)
			}
		}
		String payload = "{\"on\":true, \"sat\":250, \"bri\":45, \"hue\":" + color + "}";
		setLightState(payload);
	}
	
	private static void setLightState(String payload) {
		if (GridManager.isQALabHub()) {
			HttpClient httpclient = HttpClientBuilder.create().build();
	        HttpPut request = new HttpPut(getLightStateURL());

	        String failureMsg = "Failed to update hue light.";
	        HttpResponse response = null;
	        try {
	        	StringEntity entity = new StringEntity(payload);
	        	request.addHeader("content-type", "application/json");
	            request.setEntity(entity);
	            response = httpclient.execute(request);
	        } catch (Exception e) {
	        	Logger.logConsoleMessage(failureMsg);
	        	e.printStackTrace();
	        }
	        
	        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
	            Logger.logConsoleMessage(failureMsg);
	            Logger.logConsoleMessage(response.getStatusLine().getReasonPhrase());
	        } else {
	            Logger.logConsoleMessage("Successfully updated hue light to color: " + color + ".");
	        }
		}
	}
	
	private static String getLightStateURL() {
        return "http://" + Constants.HUB_HUE_BRIDGE_IP + "/api/" + Constants.HUB_HUE_USER_ID + "/lights/" 
        	+ hueLightID + "/state";
	}

}