package com.viacom.test.core.emerging;

import com.viacom.test.core.lab.ActiveDeviceManager;
import com.viacom.test.core.lab.GridManager;
import com.viacom.test.core.lab.LabDeviceManager;
import com.viacom.test.core.props.EmergingOS;
import com.viacom.test.core.proxy.ProxyManager;

public class EmergingDriverManager {

	private static ThreadLocal<EmergingOS> emergingOS = new ThreadLocal<EmergingOS>();
	private static ThreadLocal<String> emergingDeviceID = new ThreadLocal<String>();
	private static ThreadLocal<String> emergingMachineIP = new ThreadLocal<String>();
	private static ThreadLocal<String> emergingDeviceIP = new ThreadLocal<String>();
	private static ThreadLocal<String> emergingDeviceUsername = new ThreadLocal<String>();
	private static ThreadLocal<String> emergingDevicePassword = new ThreadLocal<String>();
	private static ThreadLocal<String> emergingHarmonyDeviceID = new ThreadLocal<String>();
	private static ThreadLocal<String> harmonyHubIP = new ThreadLocal<String>();
    
	public static synchronized void setEmergingOS(EmergingOS emergingOS) {
        EmergingDriverManager.emergingOS.set(emergingOS);
    }
    
	public static synchronized EmergingOS getEmergingOS() {
        return emergingOS.get();
    }
	
    public static synchronized void setDeviceId(String deviceId) {
        EmergingDriverManager.emergingDeviceID.set(deviceId);
    }
    
    public static synchronized String getDeviceId() {
        return emergingDeviceID.get();
    }
    
    public static synchronized void setMachineIP(String machineIP) {
        EmergingDriverManager.emergingMachineIP.set(machineIP);
    }
    
    public static synchronized String getMachineIP() {
        return emergingMachineIP.get();
    }
    
    public static synchronized void setDeviceUsername(String username) {
        EmergingDriverManager.emergingDeviceUsername.set(username);
    }
    
    public static synchronized String getDeviceUsername() {
        return emergingDeviceUsername.get();
    }
    
    public static synchronized void setDevicePassword(String password) {
        EmergingDriverManager.emergingDevicePassword.set(password);
    }
    
    public static synchronized String getDevicePassword() {
        return emergingDevicePassword.get();
    }
    
    public static synchronized void setDeviceIP(String deviceIP) {
        EmergingDriverManager.emergingDeviceIP.set(deviceIP);
    }
    
    public static synchronized String getDeviceIP() {
        return emergingDeviceIP.get();
    }
    
    public static synchronized void setHarmonyDeviceId(String harmonyDeviceId) {
        EmergingDriverManager.emergingHarmonyDeviceID.set(harmonyDeviceId);
    }
    
    public static synchronized String getHarmonyDeviceId() {
        return emergingHarmonyDeviceID.get();
    }
    
    public static synchronized void setHarmonyHubHubIP(String ipAddress) {
        harmonyHubIP.set(ipAddress);
    }
    
    public static synchronized String getHubHarmonyIP() {
        return harmonyHubIP.get();
    }
    
    public static void stopDriver() {
    	if (GridManager.isQALabHub()) {
    		// remove the active driver from the list
    		ActiveDeviceManager.removeActiveDeviceID(ActiveDeviceManager.getActiveDevice());
    		
    		// set the device no longer in use
    		LabDeviceManager.setDeviceInUse(getEmergingOS(), ActiveDeviceManager.getActiveDevice(), false);
    	}
    	
    	// stop the device proxy
		if (ProxyManager.getProxyServer() != null) {
			ProxyManager.stopProxyServer();
		}
    }
	
}
