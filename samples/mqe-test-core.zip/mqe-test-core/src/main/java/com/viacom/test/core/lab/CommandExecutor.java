package com.viacom.test.core.lab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.viacom.test.core.util.Logger;

public class CommandExecutor {

	private static final String REMOTE_ADMIN_USER = "admin@";
	
	private static ThreadLocal<String> command = new ThreadLocal<String>();
	private static ThreadLocal<String> output = new ThreadLocal<String>();
	private static ThreadLocal<Integer> exitCode = new ThreadLocal<Integer>();
	private static ThreadLocal<Integer> timeout = new ThreadLocal<Integer>() {
	    protected Integer initialValue() {
	    	return 60;
	    }
	};
	private static ThreadLocal<Process> process = new ThreadLocal<Process>();
	
	/**********************************************************************************************
     * Sets/overrides the command timeout max of the executing process.
     * 
     * @param timeout - {@link Integer} - The max time in seconds for the process or command to wait for a response before timing out.
     * @author Brandon Clark created March 22, 2016
     * @version 1.0 March 22, 2016
     ***********************************************************************************************/
	public static void setTimeout(Integer timeoutInSeconds) {
		CommandExecutor.timeout.set(timeoutInSeconds);
	}
	
	/**********************************************************************************************
     * Gets the last executed command.
     * 
     * @author Brandon Clark created February 1, 2016
     * @version 1.0 February 1, 2016
     * @return The previously executed command.
     ***********************************************************************************************/
	public static String getCommand() {
		return command.get();
	}
	
	/**********************************************************************************************
     * Gets the last executed exit code.
     * 
     * @author Brandon Clark created March 22, 2016
     * @version 1.0 March 22, 2016
     * @return The previously executed exit code.
     ***********************************************************************************************/
	public static Integer getExitCode() {
		return exitCode.get();
	}
	
	/**********************************************************************************************
     * Gets the output (or error) of the last executed command.
     * 
     * @author Brandon Clark created February 1, 2016
     * @version 1.0 February 1, 2016
     * @return The output or error of the previously executed command.
     ***********************************************************************************************/
	public static String getOutput() {
		return output.get();
	}
	
	public static Process getProcess() {
		return CommandExecutor.process.get();
	}
	
	/**********************************************************************************************
     * Executes a user command in the bash environment.
     * 
     * @param command - {@link String} - The bash command to execute.
     * @param machineIPAddress - {@link String} - The machine IP address of the machine to run a remote command, ie 10.15.15.15.
     * @author Brandon Clark created February 1, 2016
     * @version 1.3 April 27, 2016
     * @return The output of the executed command.
     ***********************************************************************************************/
	public static String execCommand(String command, String machineIPAddress) {
		String user = getAdminUserSSHString(machineIPAddress);
		CommandExecutor.command.set(user + command);
		CommandExecutor.output.set(null);
		Process process = null;
		
		String errorMsg = "The command '" + CommandExecutor.command.get() + "' failed to execute.";
		try {
			process = Runtime.getRuntime().exec(CommandExecutor.command.get());
			process.waitFor(timeout.get(), TimeUnit.SECONDS);
			exitCode.set(process.exitValue());
			CommandExecutor.output.set(Stream.of(process.getErrorStream(), process.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		        	Logger.logConsoleMessage(errorMsg);
		            e.printStackTrace();
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (InterruptedException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		} catch (IOException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		} catch (IllegalThreadStateException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		}
		finally {
			process.destroyForcibly();
		}
		
	    return CommandExecutor.output.get();
	}
	
	/**********************************************************************************************
     * Executes a user command in the bash environment via process builder. The command input should be in
     * Array style option format. Note that this method will execute the subprocesses independently from the main process
     * and output is redirected to the current Java process.
     * 
     * @param command[] - {@link Array} - The bash command array list of options to execute.
     * @param machineIPAddress - {@link String} - The machine IP address of the machine to run a remote command, ie 10.15.15.15.
     * @author Brandon Clark created June 14, 2016
     * @version 1.0 June 14, 2016
     * @return The output of the executed command.
     ***********************************************************************************************/
	public static String execIndependentCommand(String[] command, String machineIPAddress) {
		String user = getAdminUserSSHString(machineIPAddress);
		CommandExecutor.command.set(user + command.toString());
		CommandExecutor.output.set(null);
		Process process = null;
		
		String errorMsg = "The command '" + CommandExecutor.command.get() + "' failed to execute.";
		
		try {
		    ProcessBuilder processBuilder = new ProcessBuilder(command);
		    processBuilder.redirectErrorStream(true);
		    processBuilder.inheritIO();
		    process = processBuilder.start();
		    CommandExecutor.process.set(process);
		    process.waitFor(timeout.get(), TimeUnit.SECONDS);
		    CommandExecutor.output.set(Stream.of(process.getErrorStream(), process.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		        	Logger.logConsoleMessage(errorMsg);
		            e.printStackTrace();
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (Exception e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		}
			
		return CommandExecutor.output.get();
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String execEnvironmentCommand(String[] command, Map<String, String> environmentProps, String machineIPAddress) {
		String user = getAdminUserSSHString(machineIPAddress);
		CommandExecutor.command.set(user + command.toString());
		CommandExecutor.output.set(null);
		Process process = null;
		
		String errorMsg = "The command '" + CommandExecutor.command.get() + "' failed to execute.";
		
		try {
		    ProcessBuilder processBuilder = new ProcessBuilder(command);
		    Map<String, String> environment = processBuilder.environment();
		    environment.clear();
		    Iterator iterator = environmentProps.entrySet().iterator();
		    while (iterator.hasNext()) {
		    	Map.Entry<String, String> pair = (Map.Entry<String, String>) iterator.next();
		    	environment.put(pair.getKey(), pair.getValue());
		    	iterator.remove();
		    }
		    process = processBuilder.start();
		    process.waitFor(timeout.get(), TimeUnit.SECONDS);
		    CommandExecutor.output.set(Stream.of(process.getErrorStream(), process.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		        	Logger.logConsoleMessage(errorMsg);
		            e.printStackTrace();
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (Exception e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		}
			
		return CommandExecutor.output.get();
	}
	
	/**********************************************************************************************
     * Executes a multi style local command in the bash environment.
     * 
     * @param command - {@link String} - The bash command to execute.
     * @author Brandon Clark created April 1, 2016
     * @version 1.0 April 1, 2016
     * @return The output of the executed command.
     ***********************************************************************************************/
	public static String execMultiCommand(String command) {
		CommandExecutor.command.set(command);
		CommandExecutor.output.set(null);
		Process process = null;
		
		String errorMsg = "The command '" + CommandExecutor.command.get() + "' failed to execute.";
		try {
			process = Runtime.getRuntime().exec(new String[] { "/bin/sh", "-c", command});
			process.waitFor(timeout.get(), TimeUnit.SECONDS);
			exitCode.set(process.exitValue());
			CommandExecutor.output.set(Stream.of(process.getErrorStream(), process.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		        	Logger.logConsoleMessage(errorMsg);
		            e.printStackTrace();
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (InterruptedException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		} catch (IOException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		} catch (IllegalThreadStateException e) {
			Logger.logConsoleMessage(errorMsg);
			e.printStackTrace();
		}
		finally {
			process.destroyForcibly();
		}
		
	    return CommandExecutor.output.get();
	}
	
	/**********************************************************************************************
     * Executes a scp user command in the bash environment.
     * 
     * @param srcFilePath - {@link String} - The local file path of the file to copy.
     * @param dstDirPath - {@link String} - The target directory path to copy the file to on the remote machine.
     * @param machineIPAddress - {@link String} - The ssh user string in the format of 'user@ipaddress' to run a remote command.
     * @author Brandon Clark created February 12, 2016
     * @version 1.0 February 12, 2016
     * @return The output of the executed command.
     ***********************************************************************************************/
	public static String copyFileFromTo(String srcFilePath, String dstDirPath, String machineIPAddress) {
		String user = "scp " + srcFilePath + " " + getAdminUserSCPString(machineIPAddress) + ":" + dstDirPath;
		CommandExecutor.command.set(user);
		CommandExecutor.output.set(null);
		try {
			Process proc = Runtime.getRuntime().exec(CommandExecutor.command.get());
			proc.waitFor(timeout.get(), TimeUnit.SECONDS);
		    CommandExecutor.output.set(Stream.of(proc.getErrorStream(), proc.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		            throw new RuntimeException(e);
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to execute scp command '" + command + "'.");
    		e.printStackTrace();
		}
	    return CommandExecutor.output.get();
	}
	
	/**********************************************************************************************
     * Executes a scp user command in the bash environment.
     * 
     * @param srcFilePath - {@link String} - The remote file path of the file to copy.
     * @param dstDirPath - {@link String} - The target directory path to save the file to on the local machine.
     * @param machineIPAddress - {@link String} - The target machine IP address to grap the file from.
     * @author Brandon Clark created May 10, 2016
     * @version 1.0 May 10, 2016
     * @return The output of the executed command.
     ***********************************************************************************************/
	public static String copyFileToFrom(String srcFilePath, String dstDirPath, String machineIPAddress) {
		String user = "scp " + getAdminUserSCPString(machineIPAddress) + ":" + srcFilePath + " " + dstDirPath;
		CommandExecutor.command.set(user);
		CommandExecutor.output.set(null);
		try {
			Process proc = Runtime.getRuntime().exec(CommandExecutor.command.get());
			proc.waitFor(timeout.get(), TimeUnit.SECONDS);
			CommandExecutor.output.set(Stream.of(proc.getErrorStream(), proc.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (IOException e) {
		            throw new RuntimeException(e);
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to execute scp command '" + command.get() + "'.");
    		e.printStackTrace();
		}
	    return CommandExecutor.output.get();
	}
	
	public static String execEmergingCommand(String command, String machineIP) {
		String user = getAdminUserSSHString(machineIP);
		CommandExecutor.command.set(user + command);
		CommandExecutor.output.set(null);
		Process process = null;
		
		String errorMsg = "The command '" + CommandExecutor.command.get() + "' failed to execute.";
		try {
			process = Runtime.getRuntime().exec(new String[] { "/bin/sh", "-c", command });
			process.waitFor(timeout.get(), TimeUnit.SECONDS);
			exitCode.set(process.exitValue());
			CommandExecutor.output.set(Stream.of(process.getErrorStream(), process.getInputStream()).parallel().map((InputStream isForOutput) -> {
		        StringBuilder output = new StringBuilder();
		        try (BufferedReader br = new BufferedReader(new InputStreamReader(isForOutput))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                output.append(line);
		                output.append("\n");
		            }
		            br.close();
		        } catch (Exception e) {
		        	CommandExecutor.output.set(errorMsg);
		        }
		        return output;
		    }).collect(Collectors.joining()));
		} catch (Exception e) {
			CommandExecutor.output.set(errorMsg);
		} finally {
			process.destroyForcibly();
		}
		
	    return CommandExecutor.output.get();
	}
	
	private static String getAdminUserSSHString(String sessionUserString) {
		if (sessionUserString == null) {
			return "";
		} else if (sessionUserString.contains("@")) {
			return "ssh " + sessionUserString + " ";
		} else {
			return "ssh " + REMOTE_ADMIN_USER + sessionUserString + " ";
		}
	}
	
	private static String getAdminUserSCPString(String sessionUserString) {
		if (sessionUserString.contains("@")) {
			return sessionUserString;
		} else {
			return REMOTE_ADMIN_USER + sessionUserString;
		}
	}
	
}
