package com.viacom.test.core.emerging;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.viacom.test.core.lab.CommandExecutor;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.TestRun;

public class EmergingUtil {

	public EmergingUtil() {
    	
    }

    public static String getHarmonyCLIPath() {
    	String harmonyPath = System.getProperty("user.dir") + "/src/test/resources/harmonyHubCLI/harmonyHubCli.js";
    	File harmonyFile = new File(harmonyPath);
    	
    	if (!harmonyFile.exists()) {
    		String errorMsg = "The harmony CLI package was not found in the project's resources directory!";
    		Logger.logConsoleMessage(errorMsg);
    		throw new RuntimeException(errorMsg);
    	}
    	return harmonyPath;
    }
    
    public static String getNodePath() {
    	String nodeDir = "/usr/local/Cellar/node";
    	String nodeVersion = CommandExecutor.execCommand("ls " + nodeDir, null).trim();
        String nodePath = null;
    	if (StringUtils.isEmpty(nodeVersion)) {
            Logger.logConsoleMessage("Could not find node in directory: " + nodeDir);
        } else {
            nodePath = nodeDir + "/" + nodeVersion + "/bin/node";
        	
        }
    	return nodePath;
    }
    
    public static String getIDeviceScreenshotPath(String machineIP) {
    	String libiDir = "/usr/local/Cellar/libimobiledevice";
    	String libiVersion = CommandExecutor.execCommand("ls " + libiDir, machineIP).trim();
        String libiPath = null;
    	if (StringUtils.isEmpty(libiVersion)) {
            Logger.logConsoleMessage("Could not find libimobile in directory: " + libiDir);
        } else {
            libiPath = libiDir + "/" + libiVersion + "/bin/idevicescreenshot";
        	
        }
    	return libiPath;
    }
    
    public static String getTesseractPath() {
    	String tesseractDir = "/usr/local/Cellar/Tesseract";
    	String tesseractVersion = CommandExecutor.execCommand("ls " + tesseractDir, null).trim();
    	
    	String tesseractPath = null;
    	if (StringUtils.isEmpty(tesseractVersion)) {
            Logger.logConsoleMessage("Could not find tesseract in directory '" + tesseractDir + "'. Did you first run "
            	+ "'brew install tesseract'?");
        } else {
            tesseractPath = tesseractDir + "/" + tesseractVersion + "/bin/tesseract";
        	
        }
    	return tesseractPath;
    }
    
    public static void cleanScreenImageDir() {
    	File screenshotDir = new File(System.getProperty("user.dir") + "/test-output/screenshots");
    	if (screenshotDir.exists()) {
    		try {
    			Logger.logConsoleMessage("Emptying all images from the screenshot directory.");
				FileUtils.cleanDirectory(screenshotDir);
			} catch (Exception e) {
				Logger.logConsoleMessage("Failed to clean screenshot directory.");
				e.printStackTrace();
			}
    	}
    }
    
    public static void commandSender(String command) {
    	String success = "executed successfully";
    	Integer maxIter = 5;
    	if (TestRun.isRoku()) {
    		maxIter = 2;
    	}
    	Integer iter = 0;
    	
    	for (int i = 0; i <= maxIter; i++) {
    		if (iter.equals(maxIter)) {
    			throw new RuntimeException("Emerging interaction with command '" + command + "' failed to execute after multiple attempts.");
    		}
    		
    		String result = null;
    		try {
    			CommandExecutor.setTimeout(30); // TODO - config
    			result = CommandExecutor.execEmergingCommand(command, null);
    			if (result != null) {
    				if (TestRun.isAppleTV()) {
    					if (result.contains(success)) {
            				break;
                		}
        			} else if (TestRun.isRoku()) {
        				if (!result.toLowerCase().contains("failed to")) {
        					break;
        				}
        			}
    			}
    		} catch (Exception e) {
    			try { Thread.sleep(1000); } catch (InterruptedException e1) { }
    		}
    		iter++;
    	}
    }
    
}
