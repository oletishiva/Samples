package com.viacom.test.core.emerging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.littleshoot.proxy.HttpFiltersSource;

import com.viacom.test.core.lab.ActiveDeviceManager;
import com.viacom.test.core.lab.AvailableDevicePoller;
import com.viacom.test.core.lab.GridManager;
import com.viacom.test.core.lab.LabDeviceManager;

import com.viacom.test.core.props.EmergingOS;

import com.viacom.test.core.proxy.ProxyManager;

import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.TestRun;

import net.lightbody.bmp.BrowserMobProxyServer;

public class EmergingDriverFactory {

	private static List<String> allDevices = new ArrayList<String>();
	private static ThreadLocal<EmergingOS> activeEmergingOS = new ThreadLocal<EmergingOS>();
    private static ThreadLocal<String> activeEmergingOSVersion = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceID = new ThreadLocal<String>();
    private static ThreadLocal<String> activeHarmonyDeviceID = new ThreadLocal<String>();
    private static ThreadLocal<String> activeHarmonyHubIP = new ThreadLocal<String>();
    private static ThreadLocal<String> activeMachineIP = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceIP = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceUsername = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDevicePassword = new ThreadLocal<String>();
    private static ThreadLocal<String> activeDeviceProxyPort = new ThreadLocal<String>();
    private static ThreadLocal<String> activeAppPackageLocation = new ThreadLocal<String>();
    
    private static ThreadLocal<String> specificTargetDeviceID = new ThreadLocal<String>() {
    	protected String initialValue() {
    		return null;
    	}
    };
    
    private static ThreadLocal<List<HttpFiltersSource>> filters = new ThreadLocal<List<HttpFiltersSource>>() {
    	protected List<HttpFiltersSource> initialValue() {
    		return null;
    	}
    };
    
    private static ThreadLocal<Integer> localDebugProxyPort = new ThreadLocal<Integer>() {
    	protected Integer initialValue() {
    		return null;
    	}
    };
    
    // TODO - some redundant code between specific device/lab device/debug. Clean up as time allows
    public static void initiateEmergingDriver(EmergingOS emergingOS, String pathOrUrlToApp) {
		activeEmergingOS.set(emergingOS);
		TestRun.setEmergingOS(emergingOS);
		
		if (GridManager.isQALabHub() && specificTargetDeviceID.get() != null) { // SPECIFIC DEVICE REQUESTED
			activeDeviceID.set(specificTargetDeviceID.get());
			// get the device info
			HashMap<String, String> deviceInfo = TestRun.isRoku() ? LabDeviceManager.getRokuDeviceInfo(activeDeviceID.get()) 
					: LabDeviceManager.getAppleTVDeviceInfo(activeDeviceID.get());
			
			
			activeHarmonyDeviceID.set(deviceInfo.get("harmony_device_id"));
			activeEmergingOSVersion.set(deviceInfo.get("device_os_version"));
			activeHarmonyHubIP.set(LabDeviceManager.getHarmonyHubIPAddress(activeEmergingOS.get()));
    	    
			// apple tv specific
			if (TestRun.isAppleTV()) {
				activeMachineIP.set(deviceInfo.get("machine_ip"));
				activeDeviceProxyPort.set(deviceInfo.get("device_proxy_port"));
			}
			
			// roku specific
			if (TestRun.isRoku()) {
				activeDeviceIP.set(deviceInfo.get("device_ip"));
				activeDeviceUsername.set(deviceInfo.get("device_username"));
				activeDevicePassword.set(deviceInfo.get("device_password"));
			}
			
			activeAppPackageLocation.set(pathOrUrlToApp);
			EmergingDriverManager.setEmergingOS(activeEmergingOS.get());
			EmergingDriverManager.setDeviceId(activeDeviceID.get());
			EmergingDriverManager.setHarmonyDeviceId(activeHarmonyDeviceID.get());
			EmergingDriverManager.setHarmonyHubHubIP(activeHarmonyHubIP.get());
			if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
				EmergingDriverManager.setDeviceIP(activeDeviceIP.get());
				EmergingDriverManager.setDeviceUsername(activeDeviceUsername.get());
				EmergingDriverManager.setDevicePassword(activeDevicePassword.get());
			}
			EmergingDriverManager.setMachineIP(null);
			
			while (LabDeviceManager.isDeviceInUse(activeEmergingOS.get(), activeDeviceID.get())) {
			    AvailableDevicePoller.pollFarmForDevice(activeEmergingOS.get(), activeDeviceID.get(), true);
			}
	    	
			// install/launch
			if (activeEmergingOS.get().equals(EmergingOS.APPLE_TV)) {

			} else if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
				EmergingInstall.downloadAppPackage(activeEmergingOS.get(), pathOrUrlToApp);
				activeAppPackageLocation.set(EmergingInstall.getHubAppFilePath());
				launchRokuApp();
			}
		} else if (GridManager.isQALabHub()) {
    		Boolean sessionSuccess = false;
    		
    		for (int farmIter = 0; farmIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; farmIter++) {
    			Boolean deviceAvailable = false;
    			while (!deviceAvailable) {
    				synchronized (EmergingDriverFactory.class) {
    					List<String> currDeviceFarm = new ArrayList<String>();
						if (allDevices.isEmpty()) {
							currDeviceFarm = LabDeviceManager.getAllDeviceIDs(activeEmergingOS.get());
						} else {
							currDeviceFarm = allDevices;
						}
						
						for (String deviceID : currDeviceFarm) {
							activeDeviceID.set(deviceID);
        					
							// get the device info
							HashMap<String, String> deviceInfo = TestRun.isRoku() ? LabDeviceManager.getRokuDeviceInfo(activeDeviceID.get()) 
									: LabDeviceManager.getAppleTVDeviceInfo(activeDeviceID.get());
							
							// set the active device info
        					activeHarmonyDeviceID.set(deviceInfo.get("harmony_device_id"));
        					activeEmergingOSVersion.set(deviceInfo.get("device_os_version"));
            				activeHarmonyHubIP.set(LabDeviceManager.getHarmonyHubIPAddress(activeEmergingOS.get()));
        	        	    
        					// apple tv specific
        					if (TestRun.isAppleTV()) {
        						activeMachineIP.set(deviceInfo.get("machine_ip"));
                				activeDeviceProxyPort.set(deviceInfo.get("device_proxy_port"));
            				}
        					
        					// roku specific
        					if (TestRun.isRoku()) {
        						activeDeviceIP.set(deviceInfo.get("device_ip"));
        						activeDeviceUsername.set(deviceInfo.get("device_username"));
        						activeDevicePassword.set(deviceInfo.get("device_password"));
        					}
        					
        	        	    // is the device active/enabled on the farm
        					Boolean deviceActive = deviceInfo.get("device_status").equals("active");
        					
        					// is the device currently not in use
        					Boolean inUse = Boolean.parseBoolean(deviceInfo.get("device_in_use"));
        					
        					if (deviceActive && !inUse) {
        						// DEVICE AVAILABLE FOR TEST
                				ActiveDeviceManager.setActiveDevice(activeDeviceID.get());
                        	    ActiveDeviceManager.addActiveDevice(activeDeviceID.get());
                        	    LabDeviceManager.setDeviceInUse(activeEmergingOS.get(), activeDeviceID.get(), true);
                        	    deviceAvailable = true;
                        	    break;
        					}
						}
    				}
    				
    				if (!deviceAvailable) {
    					AvailableDevicePoller.pollFarmForDevice(emergingOS, activeDeviceID.get(), false);
    				}
    			}
    			
        		for (int deviceIter = 0; deviceIter <= Constants.DRIVER_MAX_SESSION_ATTEMPTS; deviceIter++) {
        			// attempt to start a session
        			try {
        				// set and start the proxy for the device prior to the app startup
        				if (activeDeviceProxyPort.get() != null) {
        					//LabDeviceManager.killDeviceProxyPort(activeMachineIP.get(), activeEmergingOS.get());
            				//Thread.sleep(1000);
            				ProxyManager.initAllProxyServers(Arrays.asList(Integer.parseInt(activeDeviceProxyPort.get())));
            				ProxyManager.enableMITM();
            				ProxyManager.setProxyServer(Integer.parseInt(activeDeviceProxyPort.get()));
            				ProxyManager.startProxyServer();
                			
                			// set any proxy rewrites prior to session startup
                			if (filters.get() != null) {
                				for (HttpFiltersSource filter : filters.get()) {
                					ProxyManager.getProxyServer().addHttpFilterFactory(filter);
                    			}
                			}
        				}
        				
            			// set the driver instance details
        				EmergingDriverManager.setEmergingOS(activeEmergingOS.get());
        				EmergingDriverManager.setHarmonyDeviceId(activeHarmonyDeviceID.get());
        				EmergingDriverManager.setHarmonyHubHubIP(activeHarmonyHubIP.get());
        				if (activeEmergingOS.get().equals(EmergingOS.APPLE_TV)) {
        					EmergingDriverManager.setDeviceId(activeDeviceID.get());
        					EmergingDriverManager.setMachineIP(activeMachineIP.get());
        				} else if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
        					EmergingDriverManager.setDeviceIP(activeDeviceIP.get());
        					EmergingDriverManager.setDeviceUsername(activeDeviceUsername.get());
        					EmergingDriverManager.setDevicePassword(activeDevicePassword.get());
        				}
        				
        				// install/launch app
        				if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
        					EmergingInstall.downloadAppPackage(activeEmergingOS.get(), pathOrUrlToApp);
        					activeAppPackageLocation.set(EmergingInstall.getHubAppFilePath());
        					launchRokuApp();
        				} else if (activeEmergingOS.get().equals(EmergingOS.APPLE_TV)) {
        					// TODO - APPLE TV INSTALL
        				}
        				
        				Logger.logMessage("Session successfully created for an " + activeEmergingOS.get().toString() 
                        		+ " device with device id '" + activeHarmonyDeviceID.get() + "'.");
                        
                        sessionSuccess = true;
                        break;
                    } catch (Exception e) {
                    	try {
							Thread.sleep(Constants.DRIVER_RECYLE_TIMEOUT_MS);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
                    	
                    	if (deviceIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
                    		// unhealthy device, remove from the active lab device list
                    		Logger.logMessage("A session failed to be spun up for emerging device type '" + activeEmergingOS.get().value() + "' on device with id '" 
                    				+ activeHarmonyDeviceID.get() + "'. This device has been removed from the active device farm.");
                    		ActiveDeviceManager.removeActiveDeviceID(activeDeviceID.get());
                    		LabDeviceManager.setDeviceInUse(activeEmergingOS.get(), activeHarmonyDeviceID.get(), false);
                            try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    	} else {
                    		Logger.logMessage("Failed to start Emerging session on attempt '" + deviceIter 
                    			+ "' for device '" + activeHarmonyDeviceID.get() + "'. Retrying...");
                    		Logger.logMessage(e.getMessage());
                    		e.printStackTrace();
                    		
                    		// kill the proxy server
                    		try { ProxyManager.stopProxyServer(); } catch (Exception e2) { /* ignore */ }
                    	}
                    }
        		}
    			
        		if (sessionSuccess) {
    				break;
    			}
        		
        		if (farmIter == Constants.DRIVER_MAX_SESSION_ATTEMPTS) {
        			Logger.logConsoleMessage("FAILED TO START SESSION AFTER MULTIPLE ATTEMPTS ON MULTIPLE DEVICES!");
        		} else {
        			Logger.logConsoleMessage("Failed to start session on lab device with id '" + activeHarmonyDeviceID.get() + "' after multiple "
        				+ "attempts. Retrying on a different device...");
        		} 
    		}
    	} else { // LOCAL TEST RUN (DEBUG)
    		try {
    			if (localDebugProxyPort.get() != null) {
    				// set and start the proxy for the device prior to the app startup
    				ProxyManager.initAllProxyServers(Arrays.asList(localDebugProxyPort.get()));
    				ProxyManager.enableMITM();
    				ProxyManager.setProxyServer(localDebugProxyPort.get());
    				ProxyManager.startProxyServer();
    			}
    		} catch (Exception e) {
    			
    		}
    		try {
				if (filters.get() != null) {
					HashMap<Integer, BrowserMobProxyServer> integerBrowserMobProxyServerHashMap = ProxyManager.getAllProxyServers();

					for (Integer integer : integerBrowserMobProxyServerHashMap.keySet()) {
						for (HttpFiltersSource filter : filters.get()) {
							integerBrowserMobProxyServerHashMap.get(integer).addHttpFilterFactory(filter);
						}
					}
				}

				// set the app instance
				activeAppPackageLocation.set(pathOrUrlToApp);
				EmergingDriverManager.setEmergingOS(activeEmergingOS.get());
				EmergingDriverManager.setDeviceId(activeDeviceID.get());
				EmergingDriverManager.setHarmonyDeviceId(activeHarmonyDeviceID.get());
				EmergingDriverManager.setHarmonyHubHubIP(activeHarmonyHubIP.get());
				if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
					EmergingDriverManager.setDeviceIP(activeDeviceIP.get());
					EmergingDriverManager.setDeviceUsername(activeDeviceUsername.get());
					EmergingDriverManager.setDevicePassword(activeDevicePassword.get());
				}
				EmergingDriverManager.setMachineIP(null);
				
				// install/launch
				if (activeEmergingOS.get().equals(EmergingOS.APPLE_TV)) {

				} else if (activeEmergingOS.get().equals(EmergingOS.ROKU)) {
					launchRokuApp();
				}
            } catch (Exception e) {
            	Logger.logConsoleMessage("Failed to spin up a local Emerging session.");
            	e.printStackTrace();
            } 
    	}
    }
	
	public static void setRewritesAtStartup(List<HttpFiltersSource> rewriteFilters) {
    	filters.set(rewriteFilters);
    }
    
    public static void setLocalDebugProxyPort(Integer debugProxyPort) {
    	localDebugProxyPort.set(debugProxyPort);
    }
    
    public static void setLocalAppleTVDeviceDetails(String deviceID, String harmonyDeviceID, String harmonyHubIP) {
    	activeDeviceID.set(deviceID);
    	activeHarmonyDeviceID.set(harmonyDeviceID);
    	activeHarmonyHubIP.set(harmonyHubIP);
    }
    
    public static void setLocalRokuDeviceDetails(String deviceIP, String username, String password, String harmonyDeviceID, String harmonyHubIP) {
    	activeDeviceIP.set(deviceIP);
    	activeDeviceUsername.set(username);
    	activeDevicePassword.set(password);
    	activeHarmonyDeviceID.set(harmonyDeviceID);
    	activeHarmonyHubIP.set(harmonyHubIP);
    }
    
    public static void setTargetDevice(String deviceID) {
    	specificTargetDeviceID.set(deviceID);
    }
    
    private static void launchRokuApp() {
    	// delete the sideloaded app
    	Logger.logMessage("Removing any previously sideloaded test apps.");
    	EmergingUtil.commandSender("curl -u " + activeDeviceUsername.get() + ":" + activeDevicePassword.get() 
		+ " -v -F mysubmit=Delete -F 'archive= ' "
		+ "http://" + activeDeviceIP.get() + "/plugin_install --digest");
		
		// install and launch the app
    	Logger.logMessage("Installing and launching app package.");
    	EmergingUtil.commandSender("curl -u " + activeDeviceUsername.get() + ":" + activeDevicePassword.get() 
		    + " -v -F mysubmit=Install -F archive=@" + activeAppPackageLocation.get() + " http://" + activeDeviceIP.get() + "/plugin_install --digest");
    }
    
}
