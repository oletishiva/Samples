package com.viacom.test.core.sauce;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import com.saucelabs.ci.sauceconnect.SauceConnectFourManager;
import com.saucelabs.ci.sauceconnect.SauceTunnelManager;
import com.viacom.test.core.lab.CommandExecutor;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.RandomData;

public class SauceTunnelsManager {
	
	private static final String SC = "sc";
	private static final Integer TUNNEL_RETRY_COUNT = 3;
	private static final Integer SC_TUNNEL_TIMEOUT_S = 30;
	private static HashMap<String, SauceTunnelManager> sauceTunnels = new HashMap<String, SauceTunnelManager>();
	private static HashMap<String, SauceTunnelManager> sauceTunnelsOptionMap = new HashMap<String, SauceTunnelManager>();
	private static List<String> sauceTunnelIdentifiers = Collections.synchronizedList(new ArrayList<String>());
	private static ThreadLocal<SauceTunnelManager> sauceTunnel = new ThreadLocal<SauceTunnelManager>();
	private static ThreadLocal<String> tunnelIdentifier = new ThreadLocal<String>();
	
	private static Integer connectedTunnels = 0;
	private static String scPath;
	
	public static void initAllSauceTunnels(List<String> tunnelIdentifiers) {
		// extract sauce connect to the working directory from the jar
		InputStream inputStream = SauceTunnelsManager.class.getClassLoader().getResourceAsStream(SC);
		FileOutputStream fileOutputStream = null;
		try {
			scPath = System.getProperty("user.dir") + "/sc";
			File scFile = new File(scPath);
			if (scFile.exists()) {
				scFile.delete();
			}
					
		    fileOutputStream = new FileOutputStream(SC);
		    byte[] buf = new byte[2048];
			int r = inputStream.read(buf);
			while(r != -1) {
			    fileOutputStream.write(buf, 0, r);
				r = inputStream.read(buf);
			}
					
			CommandExecutor.execCommand("chmod 777 " + scPath, null);
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to copy sauce connect to the local user's system.");
			e.printStackTrace();
		} finally {
		    if(fileOutputStream != null) {
			    try {
				    fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
				
		for (String tunnelIdentifier : tunnelIdentifiers) {
			SauceTunnelManager sauceTunnel = new SauceConnectFourManager(false);
			sauceTunnelIdentifiers.add(tunnelIdentifier);
			sauceTunnels.put(tunnelIdentifier, sauceTunnel);
		}
	}
	
	public static HashMap<String, SauceTunnelManager> getAllSauceTunnels() {
		return sauceTunnels;
	}
	
	public static void setSauceTunnel(String tunnelIdentifier) {
		sauceTunnel.set(sauceTunnels.get(tunnelIdentifier));
		SauceTunnelsManager.tunnelIdentifier.set(tunnelIdentifier);
	}
	
	public static SauceTunnelManager getSauceTunnel() {
		return sauceTunnel.get();
	}
	
	public static String getSauceTunnelIdentifier() {
		return tunnelIdentifier.get();
	}
	
	public static List<String> getAllTunnelIdentifiers() {
		return sauceTunnelIdentifiers;
	}
	
	public static void startSauceConnect(SauceTunnelManager sauceTunnel, String tunnelIdentifier, Integer proxyPort) {
		// attempt to start the tunnel
		for (int i = 0; i < TUNNEL_RETRY_COUNT; i++) {
    		try {
            	ServerSocket serverSocket = null;
            	Integer tunnelPort = null;
                serverSocket = new ServerSocket(0);
        		tunnelPort = serverSocket.getLocalPort();
        		serverSocket.close();
                
                Integer scProxyPort = null;
                ServerSocket serverSocket2 = null;
                serverSocket2 = new ServerSocket(0);
        		scProxyPort = serverSocket2.getLocalPort();
        		serverSocket2.close();
        		
        		// set the ready file location
        		File readyFile = new File(System.getProperty("user.dir") + "/tunnelReady" + RandomData.getCharacterString(40));
        		
        		// start the tunnel and add it to the options map for closing later
        		String options = "--no-proxy-caching -B all -i " + tunnelIdentifier + " -p localhost:" + proxyPort.toString() + " --pidfile /tmp/" 
            		    + RandomData.getCharacterString(40) + ".pid --logfile /tmp/" + RandomData.getCharacterString(40) 
            		    + ".log --scproxy-port " + scProxyPort.toString() + " -f " + readyFile.getAbsolutePath();
            		
            	sauceTunnel.openConnection(SauceCredentialManager.getSauceUsername(), SauceCredentialManager.getSauceKey(), tunnelPort, null, options, 
                    	null, false, scPath);
            	sauceTunnelsOptionMap.put(options, sauceTunnel);
            	
        		for (int readyIter = 0; readyIter <= SC_TUNNEL_TIMEOUT_S; readyIter++) {
        			if (readyIter == SC_TUNNEL_TIMEOUT_S) {
        				readyFile.delete();
        				closeTunnel(sauceTunnel, options);
        				throw new RuntimeException("SC Spin up failure.");
        			}
        			
        			if (readyFile.exists()) {
        				Logger.logConsoleMessage("Tunnel with id '" + tunnelIdentifier  + "' is ready for testing.");
        				readyFile.delete();
        				break;
        			}
        			Thread.sleep(1000);
        		}
        		
        		connectedTunnels++;
        		break;
        	}
        	catch (Exception e) {
        		Logger.logConsoleMessage("Failed to spin up a sauce tunnel on with proxy port '" + proxyPort.toString() + "'. Retrying...");
        		e.printStackTrace();
        	}
    	}
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void closeAllSauceConnectTunnels() {
		if (!sauceTunnelsOptionMap.isEmpty()) {
			List<Thread> closeThreads = new ArrayList<Thread>();
			
			Iterator iterator = sauceTunnelsOptionMap.entrySet().iterator();
		    while (iterator.hasNext()) {
		        Map.Entry<String, SauceTunnelManager> entry = (Map.Entry<String, SauceTunnelManager>) iterator.next();
		        closeThreads.add(new Thread() {
	    			public void run() {
	    				closeTunnel(entry.getValue(), entry.getKey());
	    			}
	    		});
		    }
		    
		    for (Thread thread : closeThreads) {
	    		thread.start();
	    	}
	    	for (Thread thread : closeThreads) {
	    		try {
					thread.join();
				} catch (InterruptedException e) {
					Logger.logConsoleMessage("Failed to close sauce tunnels.");
					e.printStackTrace();
				}
	    	}
		} else {
			// get all the active tunnel ids
			List<String> allTunnelIds = getAllTunnelIds();
					
			Boolean existingTunnels = false;
			if (allTunnelIds.size() > 0) {
				existingTunnels = true;
				
			}
			
			List<Thread> closeThreads = new ArrayList<Thread>();
			for (String tunnelId : allTunnelIds) {
				closeThreads.add(new Thread() {
	    			public void run() {
	    				Logger.logConsoleMessage("Deleting sauce labs tunnel with id '" + tunnelId + "'.");
	    				CommandExecutor.execCommand("curl https://saucelabs.com/rest/v1/" + SauceCredentialManager.getSauceUsername() 
	    					+ "/tunnels/" + tunnelId + " -u " + SauceCredentialManager.getSauceUsername() + ":" 
	    					+ SauceCredentialManager.getSauceKey() + " -X DELETE", null);
	    			}
	    		});
			}
			
			for (Thread thread : closeThreads) {
	    		thread.start();
	    	}
	    	for (Thread thread : closeThreads) {
	    		try {
					thread.join();
				} catch (InterruptedException e) {
					Logger.logConsoleMessage("Failed to close sauce tunnels.");
					e.printStackTrace();
				}
	    	}
			
	    	if (existingTunnels) {
	    		try {
					Thread.sleep(10000);
				} catch (InterruptedException e) { }
	    	}
	        
	    	// kill all tunnel processes
	    	CommandExecutor.execCommand("killall sc", null);
		}
	}
	
	public static Integer getSauceConnectTunnelCount() {
        return connectedTunnels;
	}
	
	private static void closeTunnel(SauceTunnelManager sauceTunnel, String options) {
		File logFile = null;
		try {
			logFile = new File(System.getProperty("user.dir") + "/tunnelCloseFile.txt");
			if (!logFile.exists()) {
				logFile.createNewFile();
			}
			PrintStream logStream = new PrintStream(logFile);
			sauceTunnel.closeTunnelsForPlan(SauceCredentialManager.getSauceUsername(), options, logStream);
			logStream.close();
			logFile.delete();
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to delete sauce tunnel.");
			e.printStackTrace();
			if (logFile != null) {
				if (logFile.exists()) {
					logFile.delete();
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private static List<String> getAllTunnelIds() {
		// get all the active tunnel ids
		List<String> allTunnelIds = new ArrayList<String>();
		String tunnelsUrl = "https://" + SauceCredentialManager.getSauceUsername() + ":" + SauceCredentialManager.getSauceKey() 
				+ "@saucelabs.com/rest/v1/" + SauceCredentialManager.getSauceUsername() + "/tunnels";
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpGet getTunnelsRequest = new HttpGet(tunnelsUrl);

		HttpResponse getTunnelsResponse = null;
		try {
		    getTunnelsResponse = httpclient.execute(getTunnelsRequest);
		} catch (Exception e) {
		    Logger.logConsoleMessage("Failed to get list of active tunnels from sauce.");
		    e.printStackTrace();
		}
		        
		if (getTunnelsResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
		    Logger.logConsoleMessage("Failed to get list of active tunnels from sauce.");
		    Logger.logConsoleMessage(getTunnelsResponse.getStatusLine().getReasonPhrase());
		} else {
		    try {
		        InputStream input = getTunnelsResponse.getEntity().getContent();
		        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
		        StringBuilder sb = new StringBuilder();
		        String line = null;
		        while ((line = reader.readLine()) != null) {
		            sb.append(line).append("\n");
		        }
		        reader.close();
		        input.close();
		                
		        String responseBody = sb.toString();
		        JSONParser parser = new JSONParser();
		        JSONArray tunnelIDArr = (JSONArray) parser.parse(responseBody);
		        Iterator<String> iterator = tunnelIDArr.iterator();
		        while (iterator.hasNext()) {
		            allTunnelIds.add(iterator.next());
		        }
		    } catch (Exception e) {
		        Logger.logConsoleMessage("Failed to get list of active tunnels from sauce.");
		        e.printStackTrace();
		    }
		}
				
		return allTunnelIds;
	}

   
}