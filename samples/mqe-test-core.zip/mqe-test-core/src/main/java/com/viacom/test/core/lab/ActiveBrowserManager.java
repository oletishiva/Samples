package com.viacom.test.core.lab;

import java.util.HashSet;
import java.util.Set;

import com.viacom.test.core.props.BrowserType;

public class ActiveBrowserManager {
	
	private static ThreadLocal<String> activeBrowserNode = new ThreadLocal<String>();
	private static ThreadLocal<BrowserType> activeBrowserType = new ThreadLocal<BrowserType>();
	private static Set<String> inactiveBrowserNodes = new HashSet<String>();
	
	public synchronized static void setActiveBrowserNode(String machineIP, BrowserType browserType) {
		activeBrowserNode.set(machineIP);
		activeBrowserType.set(browserType);
	}
	
	public synchronized static String getActiveBrowserAddress() {
		return activeBrowserNode.get();
	}
	
	public synchronized static BrowserType getActiveBrowserType() {
		return activeBrowserType.get();
	}
	
	public synchronized static void addInactiveBrowserNode(String machineIP) {
		inactiveBrowserNodes.add(machineIP);
	}
	
	public synchronized static Set<String> getInactiveBrowserNodes() {
		return inactiveBrowserNodes;
	}
}
