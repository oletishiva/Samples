package com.viacom.test.core.lab;

import java.io.File;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashSet;

import java.util.Set;

import com.viacom.test.core.driver.DriverManager;
import com.viacom.test.core.props.MobileOS;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.TestRun;

public class GlobalInstall {

	private static String appFileName = null;
	private static Set<String> installedSet = new HashSet<String>();
	private static String appPackageID = null;
	private static MobileOS mobileOS = null;
	
	public static void downloadAppPackage(String appPackageUrl) {
		SimpleDateFormat dateTimeFormat = new SimpleDateFormat(Constants.PACKAGE_DATE_FORMAT);
		MobileOS mobileOS = appPackageUrl.contains(Constants.IPA_EXT) ? MobileOS.IOS : MobileOS.ANDROID;
		String appExt = mobileOS == MobileOS.ANDROID ? Constants.APK_EXT : Constants.IPA_EXT;
		
		// download the app on the core machine
		appFileName = dateTimeFormat.format(new Date()) + appExt;
		
		Integer maxDownloadAtt = 2;
		Boolean downloadSuccess = false;
		Integer downloadIter = 0;
		while (!downloadSuccess && downloadIter < maxDownloadAtt) {
			try {
		        LabDeviceManager.downloadAppPackage(null, appPackageUrl, appFileName);
			} catch (Exception e) {
				Logger.logConsoleMessage("App package timed out during download.");
			}
			
			// check the file size of the downloaded package to ensure it's valid
		    File file = new File(Constants.HUB_APP_PACKAGE_DIR + appFileName);
		    if (file.exists() && file.length() > Constants.INVALID_APP_FILE_SIZE) {
		    	downloadSuccess = true;
		    } else {
		    	Logger.logConsoleMessage("App package failed to download successfully on attempt '" 
		            + downloadIter + "'. Retrying...");
		    }
		    
		    downloadIter++;
		}
		
		if (!downloadSuccess) {
			throw new RuntimeException("The app package did not download successfully after '" 
		        + maxDownloadAtt + "' attempts.");
		}
	}
	
	/**********************************************************************************************
     * Installs an app on a target device.
     * 
     * @param installOnTest - {@link Boolean} - Set to true if you want the app to be installed at the beginning of EVERY test execution. 
     * Otherwise, the script will install the app the first time the test runs on the device in the suite.
     * @param appPackageID - {@link String} - The app package id of the app to install.
     * @param appPackageUrl - {@link String} - The url of the application to download.
     * @author Brandon Clark created August 1, 2016
     * @version 1.0 August 1, 2016
     * @return Boolean - the success or failure of the install attempt.
     ***********************************************************************************************/
	public static Boolean installApp(Boolean installOnTest, String deviceID, String appPackageID) {
		if (appFileName == null) {
			throw new RuntimeException("The app file path is null. Did you call GlobalInstall.downloadAppPackage "
				+ "in your SuiteListener.onStart method?");
		}
		
		Boolean installSuccess = false;
		Integer installIter = 0;
		
    	GlobalInstall.mobileOS = TestDeviceInfo.getMobileOS();
        GlobalInstall.appPackageID = appPackageID;
		
		// check if the device is reachable on the lab
		if (LabDeviceManager.isDeviceConnected(deviceID)) {
			while (!installSuccess && installIter != 2) {
				// check if the app is installed
				String machineIP = TestDeviceInfo.getTetheredMachineIP();
				Boolean appInstalled = LabDeviceManager.isAppInstalled(machineIP, mobileOS, deviceID, appPackageID);
				if (TestRun.isSelendroid()) { // SELENDROID
					if (!installedSet.contains(deviceID)) {
						// push the app to the target machine
						LabDeviceManager.copyAppPackage(machineIP, Constants.HUB_APP_PACKAGE_DIR + appFileName, 
							Constants.NODE_APP_PACKAGE_DIR + appFileName);
						if (appInstalled) {
							LabDeviceManager.uninstallApp(machineIP, mobileOS, deviceID, appPackageID);
						}
						
						installedSet.add(deviceID);
						installSuccess = true;
						break;
					} else {
						installSuccess = true;
						break;
					}
				} else { // APPIUM
					// uninstall the app if the user indicates they want a fresh install on EVERY test
					if (appInstalled && installOnTest) {
						LabDeviceManager.uninstallApp(machineIP, mobileOS, deviceID, appPackageID);
					}
					
					// uninstall the app if it is the first execution on the device in the suite
					if (appInstalled && !installOnTest && !installedSet.contains(deviceID)) {
						LabDeviceManager.uninstallApp(machineIP, mobileOS, deviceID, appPackageID);
					}
					
					// indicate a success install if the device was previously installed successfully
					// and the user HAS NOT uninstalled the app during the test execution
					if (installedSet.contains(deviceID) && !installOnTest && appInstalled) {
						installSuccess = true;
						break;
					}
					
					// install the app as needed
					if (!LabDeviceManager.isAppInstalled(machineIP, mobileOS, deviceID, appPackageID)) {
						// push the app to the target machine
						LabDeviceManager.copyAppPackage(machineIP, Constants.HUB_APP_PACKAGE_DIR + appFileName, 
							Constants.NODE_APP_PACKAGE_DIR + appFileName);
						// install the app package on the device
					    LabDeviceManager.installApp(machineIP, mobileOS, deviceID, Constants.NODE_APP_PACKAGE_DIR + appFileName);
					    // check that the app was installed successfully
					    installSuccess = LabDeviceManager.isAppInstalled(machineIP, mobileOS, deviceID, appPackageID);
					    if (!installSuccess) {
					    	Logger.logConsoleMessage("App was not installed successfully on attempt '" + installIter + "'.");
					    } else {
					    	installedSet.add(deviceID);
					    }
					}
				}
				
				installIter++;
			}
		} else {
			Logger.logConsoleMessage("Device '" + deviceID + "' cannot be reached on the lab.");
		}
		
		return installSuccess;
    }
	
	public static String getNodeAppFile() {
		return Constants.NODE_APP_PACKAGE_DIR + appFileName;
	}
	
	public static Boolean uninstallApp() {
		// get the current running info
		String sessionIP = GridManager.getRunningSessionIP();
		String deviceID = LabDeviceManager.getDeviceID(sessionIP, mobileOS);
		
		// stop the current session
		DriverManager.stopAppiumDriver();
		
		// uninstall the app package from the current device
		LabDeviceManager.uninstallApp(sessionIP, mobileOS, deviceID, appPackageID);
		
		return LabDeviceManager.isAppInstalled(sessionIP, mobileOS, deviceID, appPackageID);
	}

}
