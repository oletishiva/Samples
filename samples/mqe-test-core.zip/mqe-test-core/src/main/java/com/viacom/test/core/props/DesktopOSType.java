package com.viacom.test.core.props;

public enum DesktopOSType {
	
  MAC ("MAC"),
  WINDOWS ("WINDOWS");

  private final String value;

  private DesktopOSType(String value) {
    this.value = value;
  }

  public String value() {
    return value;
  }
  
}
