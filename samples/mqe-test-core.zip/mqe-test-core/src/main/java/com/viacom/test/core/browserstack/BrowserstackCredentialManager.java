package com.viacom.test.core.browserstack;

import com.viacom.test.core.util.TestRun;

public class BrowserstackCredentialManager {

	private static String browserstackUsername = null;
    private static String browserstackKey = null;
    
    /**********************************************************************************************
     * Sets the browserstack username and key.
     * 
     * @param String - {@link String} - The browserstack username.
     * @param String - {@link String} - The browserstack key.
     * @author Brandon Clark created June 6, 2016
     * @version 1.0 June 6, 2016
     ***********************************************************************************************/
    public static synchronized void setBrowserstackCreds(String username, String key) {
    	TestRun.setBrowserstackRun(true);
    	browserstackUsername = username;
    	browserstackKey = key;
    }
    
    /**********************************************************************************************
     * Gets the browserstack username.
     * 
     * @author Brandon Clark created June 6, 2016
     * @version 1.0 June 6, 2016
     * @return String - The browserstack username.
     ***********************************************************************************************/
    public static synchronized String getBrowserstackUsername() {
    	return browserstackUsername;
    }
    
    /**********************************************************************************************
     * Gets the browserstack key.
     * 
     * @author Brandon Clark created June 6, 2016
     * @version 1.0 June 6, 2016
     * @return String - The sauce key.
     ***********************************************************************************************/
    public static synchronized String getBrowserstackKey() {
    	return browserstackKey;
    }

}
