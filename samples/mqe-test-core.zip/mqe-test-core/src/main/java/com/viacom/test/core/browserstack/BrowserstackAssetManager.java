package com.viacom.test.core.browserstack;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.viacom.test.core.util.Logger;

public class BrowserstackAssetManager {
	
	private static String assetDownloadUrl;
	
	/**********************************************************************************************
     * Gets the video screen recording of the browserstack session and returns an .mp4 file.
     * 
     * @param sessionID - {@link String} - The webdriver sessionId of the test execution.
     * @param fileName - {@link String} - The absolute file path/name of the file to save the .mp4 to. NOTE - this
     * will most likely be your project screenshots directory in test-output.
     * @author Brandon Clark created June 15, 2016
     * @version 1.0.0 June 15, 2016
     ***********************************************************************************************/
	public static void getScreenRecording(String sessionID, String fileName) {
		Logger.logConsoleMessage("Getting screen recording video from Browserstack for session id '" + sessionID + "'.");
		String videoRequestUrl = "https://www.browserstack.com/automate/sessions/" + sessionID + ".json";
		
		// get the asset download url
		assetDownloadUrl = getSessionAssetUrl(videoRequestUrl, "video_url");
		
		// get the video itself
        CloseableHttpClient httpclient = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(assetDownloadUrl);

        String failureMsg = "Failed to download screen recording video with session id '" + sessionID + "'.";
        HttpResponse response = null;
        try {
        	response = httpclient.execute(request);
        } catch (Exception e) {
        	Logger.logConsoleMessage(failureMsg);
        	e.printStackTrace();
        }
        
        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            Logger.logConsoleMessage(failureMsg);
            Logger.logConsoleMessage(response.getStatusLine().getReasonPhrase());
        } else {
        	try {
        		InputStream is = response.getEntity().getContent();
        		FileOutputStream fos = new FileOutputStream(new File(fileName));
        		int inByte;
        		while((inByte = is.read()) != -1)
        		     fos.write(inByte);
        		is.close();
        		fos.close();
                
            } catch (Exception e) {
            	Logger.logConsoleMessage(failureMsg);
            	e.printStackTrace();
            }
        }
	}
	
	// TODO - get the selenium log from browserstack
	
	private static String getSessionAssetUrl(String url, String field) {
		assetDownloadUrl = null;
        
		CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(AuthScope.ANY, 
		    new UsernamePasswordCredentials(BrowserstackCredentialManager.getBrowserstackUsername(), BrowserstackCredentialManager.getBrowserstackKey()));
		
		CloseableHttpClient httpclient = HttpClientBuilder.create()
				.setDefaultCredentialsProvider(credentialsProvider).build();
        
		HttpGet request = new HttpGet(url);

        String failureMsg = "Failed to get '" + field + "' asset url from browserstack session url '" 
        	        + url + "'.";
        HttpResponse response = null;
        try {
        	response = httpclient.execute(request);
        } catch (Exception e) {
        	Logger.logConsoleMessage(failureMsg);
        	e.printStackTrace();
        }
        
        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            Logger.logConsoleMessage(failureMsg);
            Logger.logConsoleMessage(response.getStatusLine().getReasonPhrase());
        } else {
        	try {
            	InputStream input = response.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                input.close();
                
                String responseBody = sb.toString();
                JSONParser parser = new JSONParser();
                JSONObject jsonObj = (JSONObject) parser.parse(responseBody);
                JSONObject automationObj = (JSONObject) jsonObj.get("automation_session");
                assetDownloadUrl = automationObj.get(field).toString();
            } catch (Exception e) {
            	Logger.logConsoleMessage(failureMsg);
            	e.printStackTrace();
            }
        }
        
        return assetDownloadUrl;
	}
	
}
