package com.viacom.test.core.props;

/**
 * The possible emerging OS targets for execution.
 */
public enum EmergingOS {
	
  APPLE_TV ("appletv"),
  ROKU ("roku"),
  CHROMECAST ("chromecast");

  private final String value;

  private EmergingOS(String value) {
    this.value = value;
  }

  public String value() {
    return value;
  }
  
}
