package com.viacom.test.core.lab;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.remote.SessionId;

import com.viacom.test.core.driver.DriverManager;
import com.viacom.test.core.props.MobileOS;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;
import com.viacom.test.core.util.TestRun;

public class GridManager {

	private static Integer localAndroidHubPort = null;
	private static Integer localiOSHubPort = null;
	private static Integer localWebHubPort = null;
	
	/**********************************************************************************************
     * Gets the grid lab hub ip.
     * 
     * @author Brandon Clark created February 1, 2016
     * @version 1.0 February 1, 2016
     * @return String - The lab hub ip address.
     ***********************************************************************************************/
	public static synchronized String getGridHubIP() {
		return Constants.LAB_WEBDRIVER_HUB_ADDRESS;
	}
    
	/**********************************************************************************************
     * Gets the appropriate running hub port of the test execution, i.e. port 4445 if the execution is
     * iOS vs 4446 if the execution is for iOS. Optionally the user can set their own desired local port
     * of execution.
     * 
     * @author Brandon Clark created February 1, 2016
     * @version 1.1 December 1, 2016
     * @return String - The hub port.
     ***********************************************************************************************/
	public static String getGridHubPort(MobileOS mobileOS) {
		String hubPort = null;
		if (isQALabHub()) { // lab run
			if (mobileOS != null) {
				if (mobileOS.equals(MobileOS.ANDROID_SIM) || mobileOS.equals(MobileOS.IOS_SIM)) {
					if (mobileOS.equals(MobileOS.ANDROID_SIM)) {
						hubPort = Constants.LAB_ANDROID_SIM_HUB_PORT;
					} else if (mobileOS.equals(MobileOS.IOS_SIM)) {
						hubPort = Constants.LAB_IOS_SIM_HUB_PORT;
					}
				} else {
					if (mobileOS.equals(MobileOS.ANDROID)) {
						hubPort = Constants.LAB_ANDROID_HUB_PORT;
					} else if (mobileOS.equals(MobileOS.IOS)) {
						hubPort = Constants.LAB_IOS_HUB_PORT;
					}
				}
			} else {
				hubPort = Constants.LAB_WEB_HUB_PORT;
			}
		} else { // local run
		    if (mobileOS != null) {
		    	if (mobileOS.equals(MobileOS.ANDROID)) {
		    		if (localAndroidHubPort != null) {
		    			hubPort = localAndroidHubPort.toString();
		    		} else {
		    			hubPort = Constants.LAB_ANDROID_HUB_PORT;
		    		}
		    	} else if (mobileOS.equals(MobileOS.IOS)) {
		    		if (localiOSHubPort != null) {
		    			hubPort = localiOSHubPort.toString();
		    		} else {
		    			hubPort = Constants.LAB_IOS_HUB_PORT;
		    		}
		    	}
		    } else {
		    	if (localWebHubPort != null) {
		    		hubPort = localWebHubPort.toString();
		    	} else {
		    		hubPort = Constants.LAB_WEB_HUB_PORT;
		    	}
		    }
		}
		
		return hubPort;
	}
	
	public static String getLabNodePort() {
		return TestRun.isIos() ? "4731" : "4730";
	}
	
	/**********************************************************************************************
     * Gets the running session address of the webdriver/appium execution from the grid in the format of
     * "http://address:port".
     * 
     * @author Brandon Clark created February 1, 2016
     * @version 1.1 March 17, 2016
     * @return String - The session address of the running session.
     ***********************************************************************************************/
    public static synchronized String getRunningSessionIP() {
    	String sessionIP = null;
    	String responseBody = null;
    	try {
    		SessionId sessionID = TestRun.isMobile() ? DriverManager.getAppiumDriver().getSessionId() 
        			: DriverManager.getWebDriver().getSessionId();
        	MobileOS mobileOS = null;
        	if (TestRun.isMobile()) {
        		mobileOS = TestRun.getMobileOS();
        	}
    		String testSessionApi = "http://" + getGridHubIP() + ":" + getGridHubPort(mobileOS) 
					+ "/grid/api/testsession?session=" + sessionID.toString();
    		responseBody = queryWebdriverHub(testSessionApi);
			JSONParser parser = new JSONParser();
		    JSONObject object = (JSONObject) parser.parse(responseBody);
		    sessionIP = object.get("proxyId").toString();
		    sessionIP = sessionIP.split("http://")[1];
		    sessionIP = sessionIP.split(":")[0];
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to get the node IP address.");
			e.printStackTrace();
		}
		
		return sessionIP;
    }
    
    public static synchronized Integer getRunningSessionCount(MobileOS mobileOS) {
    	Integer sessionCount = null;
    	String responseBody = CommandExecutor.execCommand("curl -i -H \"Accept: application/json\" -H \"Content-Type"
    			+ ": application/json\" -X GET http://" + getGridHubIP() + ":" + getGridHubPort(mobileOS) + "/wd/hub/sessions", null);
        try {
    		sessionCount = StringUtils.countMatches(responseBody, "ext. key");
    		Logger.logConsoleMessage("Count of currently running sessions: " + sessionCount);
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to get the count of active sessions.");
			e.printStackTrace();
		}
		
		return sessionCount;
    }
    
    public static synchronized Boolean isLabNodeRegistered(String nodeIP, MobileOS mobileOS) {
    	String responseBody = CommandExecutor.execCommand("curl -i -H \"Accept: application/json\" -H \"Content-Type"
    		+ ": application/json\" -X GET http://" + getGridHubIP() + ":" + getGridHubPort(mobileOS) + "/grid/api/proxy?id=http://" + nodeIP + ":" 
    		+ getLabNodePort(), null);
        
		return responseBody.toLowerCase().contains("proxy found");
    }
    
    public static Boolean isQALabHub() {
    	try {
    		return InetAddress.getLocalHost().getHostName().equals(Constants.GRID_HUB_MACHINE_NAME);
		} catch (UnknownHostException e) {
			return false;
		}
    }
    
    public static void setLocalAndroidHubPort(Integer port) {
    	localAndroidHubPort = port;
    }
    
    public static void setLocaliOSHubPort(Integer port) {
    	localiOSHubPort = port;
    }
    
    public static void setLocalWebHubPort(Integer port) {
    	localWebHubPort = port;
    }
    
    /**********************************************************************************************
     * NOTE - ADMIN USE ONLY! NOT TO BE USED AT THE PROJECT LEVEL!!!
     * Resets a remote mobile node on the lab
     * 
     * @author Brandon Clark created February 17, 2017
     * @version 1.0 February 17, 2017
     ***********************************************************************************************/
	public static void resetRemoteMobileNode(MobileOS mobileOS, String machineIP) {
		String killNodeScriptPath = null;
		String startNodeScriptPath = null;
		if (mobileOS.equals(MobileOS.ANDROID)) {
			killNodeScriptPath = Constants.ANDROID_KILL_REMOTE_NODE_PATH;
			startNodeScriptPath = Constants.ANDROID_START_REMOTE_NODE_PATH;
		} else if (mobileOS.equals(MobileOS.ANDROID_SIM)) {
			killNodeScriptPath = Constants.ANDROID_SIM_KILL_REMOTE_NODE_PATH;
			startNodeScriptPath = Constants.ANDROID_SIM_START_REMOTE_NODE_PATH;
		} else if (mobileOS.equals(MobileOS.IOS)) {
			killNodeScriptPath = Constants.IOS_KILL_REMOTE_NODE_PATH;
			startNodeScriptPath = Constants.IOS_START_REMOTE_NODE_PATH;
		} else if (mobileOS.equals(MobileOS.IOS_SIM)) {
			killNodeScriptPath = Constants.IOS_SIM_KILL_REMOTE_NODE_PATH;
			startNodeScriptPath = Constants.IOS_SIM_START_REMOTE_NODE_PATH;
		}
			
		CommandExecutor.execCommand("open " + killNodeScriptPath, machineIP);
		try { Thread.sleep(Constants.DRIVER_RECYLE_TIMEOUT_MS); } catch (InterruptedException e) {}
		CommandExecutor.execCommand("open " + startNodeScriptPath, machineIP);
		if (mobileOS.equals(MobileOS.IOS)) {
			CommandExecutor.execCommand("open " + Constants.IOS_STOP_WEB_DEBUGGER_PATH, machineIP);
			try { Thread.sleep(250); } catch (InterruptedException e) {}
			CommandExecutor.execCommand("open " + Constants.IOS_START_WEB_DEBUGGER_PATH, machineIP);
		}
		
		// wait for the node to register
		Integer nodeRegisterPoll = 0;
		while (!isLabNodeRegistered(machineIP, mobileOS) && nodeRegisterPoll <= 10) {
			if (nodeRegisterPoll == 10) {
				Logger.logConsoleMessage("Node did not register with the grid on '" + machineIP + "'.");
			}
			try { Thread.sleep(1000); } catch (InterruptedException e) { }
			nodeRegisterPoll++;
		}
		try { Thread.sleep(1000); } catch (InterruptedException e) { }
	}
	
    private static String queryWebdriverHub(String url) {
    	String responseBody = null;
    	try {
    		URL jsonURL= new URL(url);
		    HttpURLConnection request = (HttpURLConnection) jsonURL.openConnection();
			request.setRequestMethod("GET");
			request.connect();
				
		    InputStream input = request.getInputStream();
		    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
		    StringBuilder sb = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
					sb.append(line).append("\n");
		    }
		    reader.close();
			input.close();
				
		    responseBody = sb.toString();
		} catch (Exception e) {
			Logger.logConsoleMessage("Failed to query webdriver hub.");
			e.printStackTrace();
		}
		
		return responseBody;
    }
    
}
