package com.viacom.test.core.lab;

import com.viacom.test.core.driver.DriverManager;
import com.viacom.test.core.props.EmergingOS;
import com.viacom.test.core.props.MobileOS;
import com.viacom.test.core.util.Constants;
import com.viacom.test.core.util.Logger;

public class AvailableDevicePoller {
	
	private static ThreadLocal<Integer> activeIdleCounter = new ThreadLocal<Integer>() {
    	protected Integer initialValue() {
    		return 1;
    	}
    };
    private static ThreadLocal<Integer> activeIdleIterativeCounter = new ThreadLocal<Integer>() {
    	protected Integer initialValue() {
    		return 1;
    	}
    };
    private static Integer idleCheckCount = 0;
	private static Integer fullDeviceInUseReset = 0;
	private static final Integer ACTIVE_IDLE_ITER_MAX = 15;
	private static final Integer ACTIVE_IDLE_CHECKS_MAX = 100;
	private static final Integer MAX_TEST_SESSION_LIMIT_MIN = 10;
	
	public static void pollFarmForDevice(MobileOS mobileOS, String deviceID, String machineIP, 
			Boolean specificDeviceRequest) {
    	if (activeIdleIterativeCounter.get() >= ACTIVE_IDLE_ITER_MAX) {
    		activeIdleIterativeCounter.set(0);
    		
    		// check if any tests have been running for longer than 10 minutes
    		if (idleCheckCount >= ACTIVE_IDLE_CHECKS_MAX) {
    			Logger.logConsoleMessage("More than '" + ACTIVE_IDLE_CHECKS_MAX + "' idle iterations have occurred. Checking device duration.");
    			idleCheckCount = 0;
    			for (String device : LabDeviceManager.getAllDeviceIDs(mobileOS)) {
        			Long runTime = LabDeviceManager.getDeviceUseDuration(device);
        			if (runTime != 0L) {
        				Long currTime = System.currentTimeMillis();
            			Long testDuration = ((currTime - runTime) / 1000); // runtime in seconds
            			
            			Integer testDurationInMin = (int) (testDuration / 60);
            			synchronized (AvailableDevicePoller.class) {
            				if (testDurationInMin >= MAX_TEST_SESSION_LIMIT_MIN && LabDeviceManager.getDeviceUseDuration(device) != 0L) {
                				Logger.logConsoleMessage("An active '" + mobileOS.value() + "' test on device '" + device + "' has been running for more than '" + MAX_TEST_SESSION_LIMIT_MIN 
                						+ "' minutes on thread '" 
                        				+ Thread.currentThread().getId() + "'. Killing the test as it exceeds the maximum alloted runtime for a single test.");
                        		try {DriverManager.getAppiumDriver().quit();} catch (Exception e) { /* ignore */}
                				LabDeviceManager.setDeviceInUse(device, false);
                        		LabDeviceManager.setDeviceUseDuration(device, 0L);
                        		GridManager.resetRemoteMobileNode(mobileOS, machineIP);
                			}
            			}
        			}
        		}
    		}
    			
    		// check if there are active sessions
			Logger.logConsoleMessage("Current device request has iteratively been polling for more than '" + ACTIVE_IDLE_ITER_MAX + "' iterations on thread '" + Thread.currentThread().getId() + "'. "
					+ "Checking to ensure other sessions are blocking it.");
			Integer activeSessionCount = GridManager.getRunningSessionCount(mobileOS);
			if (activeSessionCount.equals(0)) {
				Integer deviceResetMax = specificDeviceRequest ? 2 : LabDeviceManager.getAllDeviceIDs(mobileOS).size() + 1;
				if (fullDeviceInUseReset >= deviceResetMax) {
					GlobalAbort.terminateTestSuite("A full device reset has been performed multiple time!");
				} else {
					synchronized (AvailableDevicePoller.class) {
						for (String deviceId : LabDeviceManager.getAllDeviceIDs(mobileOS)) {
							if (LabDeviceManager.isDeviceInUse(deviceID)) {
								Logger.logConsoleMessage("Device request from the virtual device farm has been polling for '" + activeIdleCounter.get() + "' iteration(s) on thread '" 
									+ Thread.currentThread().getId() + "', but there are "
					    			+ "currently no active sessions running. Resetting the list of devices in use.");
					    			
								LabDeviceManager.setDeviceInUse(deviceId, false);
							}
		    				
		    			}
		    			fullDeviceInUseReset = fullDeviceInUseReset + 1;
					}
				}	
			} else {
				Logger.logConsoleMessage("Other sessions are currently in progress. Continuing to poll on thread '" + Thread.currentThread().getId() + "'...");
			}
		}
    	
    	if (activeIdleCounter.get() >= Constants.DEVICE_WAIT_QUEUE_MAX_ITER) {
    		throw new RuntimeException("A device request has exceeded the maximum lab poll allotment of '" + Constants.DEVICE_WAIT_QUEUE_MAX_ITER + "' iterations. Terminating the driver request.");
    	}
    	
    	if (specificDeviceRequest) {
    		Logger.logConsoleMessage("The specific requested device '" + deviceID + "' "
    		    + "is currently in use. Device request has been polling for '" + activeIdleCounter.get() + "' iteration(s).");
    	} else {
    		Logger.logConsoleMessage("Requested a device from the device virtual farm on thread '" + Thread.currentThread().getId() + "' but none are available. "
    				+ "Device request has been polling for '" + activeIdleCounter.get() + "' iteration(s).");
    	}
		
    	idleCheckCount++;
    	activeIdleCounter.set(activeIdleCounter.get() + 1);
		activeIdleIterativeCounter.set(activeIdleIterativeCounter.get() + 1);
		try { Thread.sleep(Constants.DEVICE_WAIT_QUEUE_SLEEP_MS); } catch (InterruptedException e) { } // check every 10 seconds
    }
	
	public static void pollFarmForDevice(EmergingOS emergingOS, String deviceID, Boolean specificDeviceRequest) {
    	if (activeIdleIterativeCounter.get() >= ACTIVE_IDLE_ITER_MAX) {
    		activeIdleIterativeCounter.set(0);
    		
    		// check if any tests have been running for longer than 10 minutes
    		/* TODO
    		for (String device : LabDeviceManager.getAllDeviceIDs(mobileOS)) {
    			Long runtime = LabDeviceManager.getDeviceUseDuration(device);
    			Long currTime = System.currentTimeMillis() / 1000;
    			Integer testDuration = (int) (runtime - currTime) / 60;
    			Logger.logConsoleMessage("An active '" + mobileOS.value() + "' test has been running for more than 10 minutes on thread '" 
    				+ Thread.currentThread().getId() + "'. Killing the test as it exceeds the maximum alloted runtime for a single test.");
    			if (testDuration >= 10) {
    				LabDeviceManager.setDeviceInUse(device, false);
    				LabDeviceManager.setDeviceUseDuration(device, 0L);
    				GridManager.resetRemoteMobileNode(mobileOS, machineIP);
    			}
    		}
    		*/
    		
    		// check if there are active sessions
			Logger.logConsoleMessage("Current device request has iteratively been polling for more than '" + ACTIVE_IDLE_ITER_MAX + "' iterations on thread '" + Thread.currentThread().getId() + "'. "
					+ "WARNING!");
		}
    	
    	if (activeIdleCounter.get() >= Constants.DEVICE_WAIT_QUEUE_MAX_ITER) {
    		throw new RuntimeException("A device request has exceeded the maximum lab poll allotment of '" + Constants.DEVICE_WAIT_QUEUE_MAX_ITER + "' iterations. Terminating the driver request.");
    	}
    	
    	if (specificDeviceRequest) {
    		Logger.logConsoleMessage("The specific requested device '" + deviceID + "' "
    		    + "is currently in use. Device request has been polling for '" + activeIdleCounter.get() + "' iteration(s).");
    	} else {
    		Logger.logConsoleMessage("Requested a device from the device virtual farm on thread '" + Thread.currentThread().getId() + "' but none are available. "
    				+ "Device request has been polling for '" + activeIdleCounter.get() + "' iteration(s).");
    	}
		
    	activeIdleCounter.set(activeIdleCounter.get() + 1);
		activeIdleIterativeCounter.set(activeIdleIterativeCounter.get() + 1);
		try { Thread.sleep(Constants.DEVICE_WAIT_QUEUE_SLEEP_MS); } catch (InterruptedException e) { } // check every 10 seconds
    }
}
