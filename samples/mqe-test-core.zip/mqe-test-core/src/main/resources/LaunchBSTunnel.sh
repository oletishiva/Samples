#!/bin/bash

BS_BINARY_PATH=$1
BS_KEY=$2
BS_PROXY_PORT=$3
BS_TUNNEL_IDENTIFIER=$4

$BS_BINARY_PATH $BS_KEY --local-proxy-host localhost --local-proxy-port $BS_PROXY_PORT --local-identifier $BS_TUNNEL_IDENTIFIER --force-local --force-proxy --daemon start --verbose 3
