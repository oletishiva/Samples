package tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import core.TestBase;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.SignInUserScreen;

public class SignInUserScreenOriginal extends TestBase {



	/*@Test (groups = { "loginErrorValidation"})
	public void loginErrorValidation()
	{
		System.err.println("Appium driver:"+getDriver());
		System.err.println("Appium driver:"+appiumDriver);
		SignInUserScreen sis=new SignInUserScreen(appiumDriver)	;
		sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();
		//click on SignInButton
		sis.clickSignInButton();
		sis.clickSignInButton();

		System.err.println(sis.getUseramePasswordErrorText());
		Assert.assertEquals(sis.getUseramePasswordErrorText(),
				"Please enter your email address", "The error is displayed..");

//enter the user name  error message for password
		sis.getUsername().sendKeys("qualitytesting98@gmail.com");
		//	signinObj.getPassword().click();
		sis.getSignInButton().click();
		Assert.assertEquals(sis.getUseramePasswordErrorText(),
				"Please enter a password", "The error message for password is displayed..");
		sis.getUsername().clear();
		sis.getUsername().sendKeys("qualitytesting98@gmail.com");
		appiumDriver.hideKeyboard();
		sis.getPassword().click();
		sis.getPassword().sendKeys("android1");

		appiumDriver.hideKeyboard();

		System.err.println(sis.getSignInButton().isDisplayed());
		//signinObj.getSignInButton().wait(2000);
		sis.getSignInButton().click();
		//signinObj.getSignInButton().click();

		System.out.println("passedd signin-----------");

		try{
			if(sis.getCloseBtn().isDisplayed())
				sis.getCloseBtn().click();
		}
		catch(Exception e)
		{

		}


	}
*/


	@Test (groups = { "login"})
	public void login()
	{
		SignInUserScreen sis=new SignInUserScreen(appiumDriver)	;
		sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();
		//click on SignInButton
		sis.clickSignInButton();
		sis.clickSignInButton();
		sis.getUsername().clear();
		sis.getUsername().sendKeys("qualitytesting98@gmail.com");
		appiumDriver.hideKeyboard();
		sis.getPassword().click();
		sis.getPassword().sendKeys("android1");
		appiumDriver.hideKeyboard();
		sis.getSignInButton().click();

		try{
			if(sis.getCloseBtn().isDisplayed())
				sis.getCloseBtn().click();
		}
		catch(Exception e)
		{

		}
	}
	
	



	
	
}
