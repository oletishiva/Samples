package tests;

import core.Key;
import core.TestBase;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pages.SearchAddRemove;
import pages.SignInUserScreen;
import pages.GeneralPage;


public class SearchAddRemoveTests extends TestBase {


    @Test(groups = {"searchAdd"})
    public void searchAndAdd() {
        SignInUserScreen sis = new SignInUserScreen(appiumDriver);
        SearchAddRemove searh = new SearchAddRemove(appiumDriver);
        GeneralPage gen= new GeneralPage(appiumDriver);
        searh.getSearchBtn().click();
       // searh.getSearchBox().click();
     //   searh.getSearchBox().clear();
        searh.getSearchBox().sendKeys("beer");
        gen.sendKeyEvent(Key.ENTER_BUTTON);
        if(searh.getAddList().get(0).isDisplayed()) {
            Reporter.log("<font color='green'>" + searh.getAddList().get(0).getText() + "</font>" + "Is Present", true);
            searh.getAddList().get(0).click();
        }
        gen.verifyElementPresent(searh.getPlusSymbol());
        gen.verifyElementPresent(searh.getSubtractSymbol());
        gen.verifyElementPresent(searh.getNoOfItems());
        gen.sendKeyEvent(Key.BACK_BUTTON);
       }

}
