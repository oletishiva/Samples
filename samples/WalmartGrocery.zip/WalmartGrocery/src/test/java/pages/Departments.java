package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import java.util.List;

public class Departments extends GeneralPage {
  //  private AndroidDriver driver;

    @AndroidFindBy(xpath ="//*[@text='DEPARTMENTS' or @text='Departments']")
    MobileElement btnDepartment;

    @FindBys( {
            @FindBy(id ="com.walmart.grocery:id/description")

    } )
    private List<MobileElement> departmentDesc;

    public Departments(AppiumDriver appiumDriver) {
        super(appiumDriver);
    }

    public MobileElement getBtnDepartment() {
        return btnDepartment;
    }

    public List<MobileElement> getDepartmentDesc() {
        return departmentDesc;
    }
}
