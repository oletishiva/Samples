package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SignInUserScreen extends GeneralPage{
	//private AndroidDriver driver;

	@AndroidFindBy(xpath ="//android.widget.Button[@text='SIGN IN' or @text='Sign In']")
	MobileElement SignInButton;
	@AndroidFindBy( id ="com.walmart.grocery:id/sign_in_email_field" )
	MobileElement userName;
	@AndroidFindBy( id ="com.walmart.grocery:id/sign_in_password_field" )
	MobileElement passWord;
	
	@AndroidFindBy(xpath ="//*[@text='NEXT']")
	MobileElement btnNext;

	By btnNextWait=By.xpath("//*[@text='NEXT']");//Button to be visible for wait
	@FindBys( {
			@FindBy(id ="com.walmart.grocery:id/textinput_error")

	} )
	private List<MobileElement> inpurErrorTxt;

	@AndroidFindBy(xpath ="//android.widget.ImageButton[@content-desc='Open navigation drawer']")
	MobileElement navDrawer;

	@AndroidFindBy( id ="com.walmart.grocery:id/close" )
	MobileElement closebtn;


	public SignInUserScreen(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	
	
	public MobileElement getSignInButton() {
		return SignInButton;
		
	}
	public MobileElement getUsername() {
	//	return Username;
		return userName;
	}
	public MobileElement getPassword() {
		//return Password;
		
		return passWord;
	}
	
	public MobileElement getnavDrawer() {
		return navDrawer;
		
	}

	public MobileElement getNextButton() {
		return btnNext;

	}

	public void splashScreenNextButtonClick()
	{
		waitForVisibilityOf(btnNextWait);
		btnNext.click();
	}

	public void clickSignInButton()
	{
		SignInButton.click();
	}

	public String getUseramePasswordErrorText()
	{
		return inpurErrorTxt.get(0).getText();
	}

	public MobileElement getNavDrawer()
	{
		return getNavDrawer();
	}

	public MobileElement getCloseBtn() {
		return closebtn;

	}
	/*public void menuBarItemsDisplayed(){
		{
			waitForVisibilityOf(By.xpath("//android.widget.ImageButton[@content-desc='Open navigation drawer']"));
			getnavDrawer().click();
		}
	}
	
	 protected void waitForVisibilityOf(By loc) {
	       WebDriverWait wait = new WebDriverWait(driver, 60);
	       
	       wait.until(ExpectedConditions.visibilityOfElementLocated(loc));
	    		
	        
	    }*/
}
