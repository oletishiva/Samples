package pageObjects;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import java.util.List;

public class SearchAddRemoveObjects  {
    @AndroidFindBy(id = "com.walmart.grocery:id/action_search")
    public MobileElement searchBtn;

    @AndroidFindBy(id = "com.walmart.grocery:id/search_src_text")
    public MobileElement searchBox;

    @AndroidFindBy(xpath = ".//android.widget.Button[@text='ADD']")
    public MobileElement btnAdd;

    @AndroidFindBy(id = "com.walmart.grocery:id/add_button")
    public MobileElement plusSymbol;

    @AndroidFindBy(id = "com.walmart.grocery:id/subtract_button")
    public MobileElement subtractSymbol;

    @AndroidFindBy(id = "com.walmart.grocery:id/amount")
    public MobileElement noOfItems;



    @FindBys( {
            @FindBy(id ="com.walmart.grocery:id/amount")

    } )
    private List<MobileElement> addList;

   

    public MobileElement getSearchBtn() {    return searchBtn;   }

    public MobileElement getSearchBox() {
        return searchBox;
    }

    public List<MobileElement> getAddList() {
        return addList;
    }

    public MobileElement getNoOfItems() {
        return noOfItems;
    }

    public MobileElement getPlusSymbol() {
        return plusSymbol;
    }

    public MobileElement getSubtractSymbol() {
        return subtractSymbol;
    }
}
