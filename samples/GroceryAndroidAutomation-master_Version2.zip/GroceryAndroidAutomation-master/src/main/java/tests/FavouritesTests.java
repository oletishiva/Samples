package tests;

import java.util.List;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.BasePage;
import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import pageObjects.FavouritesObjects;


import pages.Favourites;
import pages.HomeScreen;
import pages.SearchAddRemove;
import pages.SignInScreen;
import pages.SplashScreen;

public class FavouritesTests extends TestBase{
	
	@Test
	public void verifyFavouritiesIsEmpty()
	{
		Favourites fav=new Favourites(new TestBase().getDriver());
		SplashScreen splash=new SplashScreen(new TestBase().getDriver());
	    SignInScreen s1=new SignInScreen(new TestBase().getDriver());
	    splash.clickBtnNext();
	    s1.clickSignIn();
        s1.login("qualitytesting98@gmail.com","android1");
        fav.navigateToFavouritesPage();
	   if( fav.isFavouritiesEmpty())
	   {
		   fav.getFavouritesEmptyPageMessage();
		   test.log(Status.INFO, "Favourites list is empty");
	   }
	   else
		   test.log(Status.INFO, "Favourites List is not empty");
	    
	}
	
	@Test
	public void searchAddToFavourities()
	{
		SearchAddRemove searh = new SearchAddRemove(new TestBase().getDriver());
		 Favourites fav=new Favourites(new TestBase().getDriver());
		 BasePage base = new BasePage(new TestBase().getDriver());
		 searh.clickSearchButton();
		 searh.searchText("bread");
		 base.sendKeyEvent(Key.ENTER_BUTTON);
		List<MobileElement> favouriteIndicators=fav.getAllFavouritesIndicators();
		
		for(int i=0;i<favouriteIndicators.size();i++)
		{
			String text=favouriteIndicators.get(i).getAttribute("checked");
			if(text.equals("false"))
			{
			favouriteIndicators.get(i).click();
			text=favouriteIndicators.get(i).getAttribute("checked");
			if(text.equals(true))
				test.log(Status.PASS, "Clciked Item added to Favourites-->Check in Favourites tab");
			}
		}
		
		
		base.sendKeyEvent(Key.BACK_BUTTON); 
		fav.navigateToFavouritesPage();
		 
	}

	@Test
	public void removeItemsFromFavourities()
	{
		 SearchAddRemove searh = new SearchAddRemove(new TestBase().getDriver());
		 Favourites fav=new Favourites(new TestBase().getDriver());
		 BasePage base = new BasePage(new TestBase().getDriver());
	//	 HomeScreen home=new HomeScreen(new TestBase().getDriver());
		// home.navigateToHome();
		 fav.navigateToFavouritesPage();
		 if(!(fav.isFavouritiesEmpty()))
		 {
			 do
			 {
				 
					 List<MobileElement> favouriteIndicators=fav.getAllFavouritesIndicators();
					 favouriteIndicators.get(0).click(); ;
				
				 
			 } while(!fav.isFavouritiesEmpty());
			 
		 }
		
		
		 
	}
}
