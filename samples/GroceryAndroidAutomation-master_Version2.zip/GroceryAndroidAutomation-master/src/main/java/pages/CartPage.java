package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;

import core.BasePage;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.CartPageObjects;


public class CartPage extends BasePage {

	CartPageObjects cartpgObj=new CartPageObjects();
	public CartPage(AppiumDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), cartpgObj);
	}
	

    public MobileElement getCartBtn() {
        return cartpgObj.cartBtn;
    }

    public MobileElement getCartItemCount() {
        return cartpgObj.cartItemCount;
    }

    public MobileElement getCartItemSubTotal() {
        return cartpgObj.cartItemSubTotal;
    }

    public List<MobileElement> getCartViewList() {
        return cartpgObj.cartViewList;
    }

    public MobileElement getCartCheckoutBtn() {
        return cartpgObj.cartCheckoutBtn;
    }

    public MobileElement getCartMinTotalErrMsg() {
        return cartpgObj.cartMinTotalErrMsg;
    }

    public MobileElement getCartSubTotalInCheckoutPage() {
        return cartpgObj.cartSubTotalInCheckoutPage;
    }

    public MobileElement getFramesInCart() {
        return cartpgObj.framesInCart;
    }

    public MobileElement getCartCollapsedQuantityView(){return cartpgObj.cartCollapsedQuantityView;    }

    public MobileElement getCartItems(){return cartpgObj.cartItems;}

    public MobileElement getCartItemRemove(){return cartpgObj.cartItemRemove;}

    public MobileElement getCartEmptyMessage(){return cartpgObj.cartEmptyMessage;}

    public MobileElement getCartEmptyId(){return  cartpgObj.cartEmptyId;}

}
