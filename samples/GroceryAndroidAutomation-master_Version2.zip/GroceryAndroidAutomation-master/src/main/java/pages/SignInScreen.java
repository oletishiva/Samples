package pages;

import core.Driver;
import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.SignInUserScreen;
import pageObjects.SplashScreenPageObject;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import java.util.concurrent.TimeUnit;

public class SignInScreen extends Driver {
    SignInUserScreen signInPageObject=new SignInUserScreen();

    public SignInScreen(AppiumDriver<MobileElement> driver){
        super();
        PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), signInPageObject);

    }



    public void clickSignIn()
    {
        signInPageObject.getSignInButton().click();
    }

    public void userNameErrorValidation()
    {
        Assert.assertEquals(signInPageObject.getUseramePasswordErrorText(),
                "Please enter your email address", "The error is displayed..");
        
        if(signInPageObject.getUseramePasswordErrorText().equalsIgnoreCase("Please enter your email address"))
        	test.log(Status.PASS, "Verified Username Error Text");
        else
        	test.log(Status.FAIL, "Verified Username Error Text");
        	
    }

    public void passWordErrorValidation()
    {
        Assert.assertEquals(signInPageObject.getUseramePasswordErrorText(),
                "Please enter a password", "The error message for password is displayed..");
        
        if(signInPageObject.getUseramePasswordErrorText().equalsIgnoreCase("Please enter a password"))
        	test.log(Status.PASS, "Verified Password Error Text");
        else
        	test.log(Status.FAIL, " Password Error Text Mismatch");
    }

    public void login(String userName,String password)
    {
        signInPageObject.getUsername().clear();
        signInPageObject.getUsername().sendKeys(userName);
        appiumDriver.hideKeyboard();
        signInPageObject.getPassword().click();
        signInPageObject.getPassword().sendKeys(password);
        appiumDriver.hideKeyboard();
        signInPageObject.getSignInButton().click();
    }

    public void enterUserName(String userName)
    {
        signInPageObject.getUsername().clear();
        signInPageObject.getUsername().sendKeys(userName);
    }

    public void enterPassword(String password)
    {
        signInPageObject.getPassword().clear();
        signInPageObject.getPassword().sendKeys(password);
    }

}
