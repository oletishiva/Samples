package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import core.BasePage;
import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.FavouritesObjects;


public class Favourites extends BasePage{

	FavouritesObjects favobj=new FavouritesObjects();
	public Favourites(AppiumDriver driver) {
		super(driver);
	PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS),favobj);
	}
	
	public Boolean isFavouritiesEmpty()
	{
		Boolean result=verifyElementPresent(favobj.getfavouritesIcon());
		return result;
	}
	
	public void navigateToFavouritesPage()
	{
		favobj.getfavouritesBtn().click();
	}
	
	public void getFavouritesEmptyPageMessage()
	{

		List<MobileElement> elements=favobj.getfavouritesIcon().findElements(By.xpath("//following-sibling::android.widget.TextView"));
		System.out.println("no of siblings:"+elements.size());	
		for(MobileElement ele:elements)	
		{		System.out.println(ele.getText());
				test.log(Status.INFO, ele.getText());
				
		}
		
		String str=String.valueOf(favobj.getfavouritesIcon());
		System.out.println(str);
		
		List<MobileElement> elements1=appiumDriver.findElements(By.xpath("//android.widget.ImageView[@resource-id='com.walmart.grocery:id/favorite_icon']//following-sibling::android.widget.TextView"));
		System.out.println("no of siblings elements1:"+elements1.size());
		for(MobileElement ele:elements1)	
		{		System.out.println(ele.getText());
				test.log(Status.INFO, ele.getText());
				
		}
		
	}
	
	public List<MobileElement> getAllFavouritesIndicators()
	{
		return favobj.getfavouritesIndicator();
	}
	

}
