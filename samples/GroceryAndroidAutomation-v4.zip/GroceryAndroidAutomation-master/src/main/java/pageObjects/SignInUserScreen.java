package pageObjects;

import java.util.List;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBys;
import org.openqa.selenium.By;


import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;

public class SignInUserScreen  {
    //private AndroidDriver driver;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='SIGN IN' or @text='Sign In']")
    MobileElement SignInButton;
    @AndroidFindBy(id = "com.walmart.grocery:id/sign_in_email_field")
    MobileElement userName;
    @AndroidFindBy(id = "com.walmart.grocery:id/sign_in_password_field")
    MobileElement passWord;


    By btnNextWait = By.xpath("//*[@text='NEXT']");//Button to be visible for wait

    @AndroidFindBys(value = {
            @AndroidBy(id = "com.walmart.grocery:id/textinput_error")
    })
    public List<MobileElement> inpurErrorTxt;

    //@AndroidFindBys({@AndroidFindBy(id ="com.walmart.grocery:id/textinput_error")} )
    //private List<MobileElement> inpurErrorTxt;







    public MobileElement getSignInButton() {
        return SignInButton;

    }

    public MobileElement getUsername() {
        //	return Username;
        return userName;
    }

    public MobileElement getPassword() {
        //return Password;

        return passWord;
    }


    /*public MobileElement getNextButton() {
        return btnNext;

    }

    public void splashScreenNextButtonClick() {
        waitForVisibilityOf(btnNextWait);
        btnNext.click();
    }*/

    public void clickSignInButton() {
        SignInButton.click();
    }

    public String getUseramePasswordErrorText() {
        return inpurErrorTxt.get(0).getText();
    }



	/*public void menuBarItemsDisplayed(){
		{
			waitForVisibilityOf(By.xpath("//android.widget.ImageButton[@content-desc='Open navigation drawer']"));
			getnavDrawer().click();
		}
	}
	
	 protected void waitForVisibilityOf(By loc) {
	       WebDriverWait wait = new WebDriverWait(driver, 60);
	       
	       wait.until(ExpectedConditions.visibilityOfElementLocated(loc));
	    		
	        
	    }*/
}
