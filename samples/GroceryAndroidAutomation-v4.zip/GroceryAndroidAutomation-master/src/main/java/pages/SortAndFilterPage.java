package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;

import core.BasePage;
import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.SortAndFilterPageObjects;

public class SortAndFilterPage extends BasePage{
	
	SortAndFilterPageObjects sortFilterPageObjecs=new SortAndFilterPageObjects();

	public SortAndFilterPage(AppiumDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), sortFilterPageObjecs);
	}
	
	public void clickOnSortBy()
	{
		sortFilterPageObjecs.txtSortBy.click();
	}
	
	public void clickRadioBtnPriceLowToHigh()
	{
		sortFilterPageObjecs.radioBtnTxtLowToHigh.click();
	}
	
	public MobileElement getFindSimilarItemsBtn()
	{
		return sortFilterPageObjecs.btnFindSimilarItems;
	}
	
	
	public Boolean isFindSimilarItemsDisplayed()
	{
		Boolean result=false;
		
		try
		{
			new TestBase().getDriver().findElementByXPath("//android.widget.Button[@resource-id='com.walmart.grocery:id/find_similar_button']");
			result=true;
					//getFindSimilarItemsBtn().isDisplayed()
				
		}
		catch(Exception e)
		{
			 return false;
		}
		
		return result;
	}

}
