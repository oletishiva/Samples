package pages;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;

import core.BasePage;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.DepartmentsObjects;


public class Departments extends BasePage{

	DepartmentsObjects deptObjects = new DepartmentsObjects();
	public Departments(AppiumDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), deptObjects);
	}
	
	 public MobileElement getBtnDepartment() {
	        return deptObjects.btnDepartment;
	    }

	    public List<MobileElement> getDepartmentDesc() {
	        return deptObjects.departmentDesc;
	    }

}
