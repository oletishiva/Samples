package core;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import utils.Utils;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.remote.*;
import org.testng.ITestResult;
import org.testng.annotations.*;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by chv on 07.02.2017.
 *
 * Test base class
 */
public  class TestBase {
	public static ExtentHtmlReporter htmlReporter;
    public static ExtentReports reports;
    public static ExtentTest test;
    public static AndroidDriver<MobileElement> appiumDriver;

    @BeforeSuite(alwaysRun = true)
    protected void setUp() throws MalformedURLException {
        System.err.println("Before Suite:");
       // URL remoteAddress = new URL("http://127.0.0.1:4723/wd/hub");

        appiumDriver = Utils.createAndroidDriver();
      
        
        htmlReporter=new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/AutomationReports.html"));
    	htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/Extent-Config.xml"));
    	reports=new ExtentReports();
    	reports.setSystemInfo("Platform", "Android");
    	reports.attachReporter(htmlReporter);
    }

    /**
     * Create Appium DesiredCapabilities
     */
    private DesiredCapabilities createAppiumCapabilities (){
        DesiredCapabilities capabilities = new DesiredCapabilities();
     //   capabilities.setCapability("app", new File(                "app/walMart.apk").getAbsolutePath());
        //capabilities.setCapability(CapabilityType.VERSION, 4.4);
        capabilities.setCapability("automationName", "Appium");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("deviceName", "android");
        capabilities.setCapability("newCommandTimeout", 200);
        capabilities.setCapability("appPackage",
                "com.walmart.grocery");
        capabilities.setCapability("appActivity",
                "com.walmart.grocery.screen.start.StartupActivity");
        return capabilities;
    }

    public AndroidDriver<MobileElement> getDriver()
    {

        return  appiumDriver;
    }

    @AfterSuite(alwaysRun = true)
    protected void tearDown(){

        //appiumDriver.quit();
    	reports.flush();
    }
    
    @BeforeTest()
    public void extentSetup()
    {
    	
    }
    
    @BeforeMethod
    public void register(Method method)
    {
    	String testname=method.getName();
    	test=reports.createTest(testname);
    //	test.log(Status.INFO, testname);
    }
    
    @AfterMethod
    public void captureStatus(ITestResult result)
    {
    	if(result.getStatus()==ITestResult.SUCCESS)
    	{
    		test.log(Status.PASS,"The Test Method Named as "+result.getName()+ "is Passed");
    	}
    	else if(result.getStatus()==ITestResult.FAILURE)
    		{
    		test.log(Status.FAIL,"The Test Method Named as "+result.getName()+ "is failed");
    		test.log(Status.FAIL, "Test Failure" + result.getThrowable());
    		}
    	else if(result.getStatus()==ITestResult.SKIP)
    	{
    		test.log(Status.SKIP,"The Test Method Named as "+result.getName()+ "is SKIPPED");
    	}
    	
    	reports.attachReporter(htmlReporter);
    	
    }
    
    @AfterTest
    public void cleanUp()
    {
    	//reports.flush();
    }
    
}


