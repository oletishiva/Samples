package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import java.util.List;

public class CartPage extends GeneralPage {
    @AndroidFindBy(id = "com.walmart.grocery:id/action_cart")
    public MobileElement cartBtn;

    @AndroidFindBy(id = "com.walmart.grocery:id/actionbar_cart_count")
    public MobileElement cartItemCount;




    @AndroidFindBy(id = "com.walmart.grocery:id/actionbar_cart_subtotal")
    public MobileElement cartItemSubTotal;



   @AndroidFindBy(xpath ="//*[@class='android.widget.FrameLayout']")
    MobileElement framesInCart; // Here we are taking FrameLayout to check wheather cart is empty or not

    @AndroidFindBy(id = "com.walmart.grocery:id/cart_checkout")
    public MobileElement cartCheckoutBtn;

    @AndroidFindBy(id = "com.walmart.grocery:id/min_total")
    public MobileElement cartMinTotalErrMsg;

    @AndroidFindBy(id = "com.walmart.grocery:id/subtotal_value")
    public MobileElement cartSubTotalInCheckoutPage;

    @AndroidFindBy(xpath ="//*[@resource-id='com.walmart.grocery:id/collapsed_quantity_view']")
    MobileElement cartCollapsedQuantityView;

    @AndroidFindBy(xpath ="//*[@resource-id='com.walmart.grocery:id/amount']")
    MobileElement cartItems;



    @AndroidFindBy(xpath ="//android.widget.TextView[@text='REMOVE']")
    MobileElement cartItemRemove;

    @AndroidFindBy(xpath ="//android.widget.TextView[@text=concat('You don', \"'\", 't have any items in your cart yet.')]")
    MobileElement cartEmptyMessage;

    @AndroidFindBy(xpath ="//*[@resource-id='com.walmart.grocery:id/empty_cart']")
    MobileElement cartEmptyId;





    @FindBys( {
            @FindBy(xpath="//android.support.v7.widget.RecyclerView[@resource-id='com.walmart.grocery:id/list_view']/android.widget.FrameLayout")

    } )

    private List<MobileElement> cartViewList;

    public CartPage(AppiumDriver appiumDriver) {
        super(appiumDriver);
    }

    public MobileElement getCartBtn() {
        return cartBtn;
    }

    public MobileElement getCartItemCount() {
        return cartItemCount;
    }

    public MobileElement getCartItemSubTotal() {
        return cartItemSubTotal;
    }

    public List<MobileElement> getCartViewList() {
        return cartViewList;
    }

    public MobileElement getCartCheckoutBtn() {
        return cartCheckoutBtn;
    }

    public MobileElement getCartMinTotalErrMsg() {
        return cartMinTotalErrMsg;
    }

    public MobileElement getCartSubTotalInCheckoutPage() {
        return cartSubTotalInCheckoutPage;
    }

    public MobileElement getFramesInCart() {
        return framesInCart;
    }

    public MobileElement getCartCollapsedQuantityView(){return cartCollapsedQuantityView;    }

    public MobileElement getCartItems(){return cartItems;}

    public MobileElement getCartItemRemove(){return cartItemRemove;}

    public MobileElement getCartEmptyMessage(){return cartEmptyMessage;}

    public MobileElement getCartEmptyId(){return  cartEmptyId;}
}
