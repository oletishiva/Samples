package tests;

import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pages.GeneralPage;
import pages.HomePageObjects;
import pages.SignInUserScreen;
import screens.HomeScreen;

import java.util.Arrays;
import java.util.List;

public class HomePageTests extends TestBase {



    @Test(groups = { "101navigationItems"})
    public void verifyNavigationDrawerItems()
    {

        HomeScreen h1=new HomeScreen(new TestBase().getDriver());
        h1.getyNavigationDrawerItems();

    }

    @Test(groups = { "102HorizontalTabularItems"})

    public void verifyHorizontalTabularItemsInHomePage()
    {
        HomeScreen h1=new HomeScreen(new TestBase().getDriver());
        h1.clickHomeInHambergerMenu();
        h1.getHorizontalTabularItemsInHomePage();
    }
    /*@Test(groups = { "103logOut"})
    public void signOut()
    {
        h1=new HomePageObjects(appiumDriver);
        g1=new GeneralPage(appiumDriver);
        s1=new SignInUserScreen(appiumDriver);
        h1.getnavDrawer().click();
        MobileElement element=g1.scrollToElementByName("Sign out",navigatorResourceId);
        element.click();
        if(s1.getSignInButton().isDisplayed())
            Reporter.log("<font color='green'>"+ "User Signed out Successfully" +"</font>" ,true);



    }*/







}
