package testngExamples;

import org.testng.annotations.Test;

public class ALogin {
	
	@Test
	public void userNameErrorValidation()
	{
		System.err.println("userNameErrorValidation");
	}
	@Test
	public void passWordErrorValidation()
	{
		System.err.println("passWordErrorValidation");
	}
	@Test
	public void signIn()
	{
		System.err.println("signIn");
	}

}
