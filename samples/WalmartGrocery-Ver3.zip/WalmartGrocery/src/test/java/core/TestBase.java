package core;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.remote.*;
import org.testng.annotations.*;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by chv on 07.02.2017.
 *
 * Test base class
 */
public  class TestBase {

    public static AndroidDriver<MobileElement> appiumDriver;

    @BeforeSuite(alwaysRun = true)
    protected void setUp() throws MalformedURLException {
        System.err.println("Before Suite:");
        URL remoteAddress = new URL("http://127.0.0.1:4723/wd/hub");

        appiumDriver = new AndroidDriver<MobileElement>(remoteAddress, createAppiumCapabilities());
        //mustangprodenv=testing;SENV=prodb;$1
     //   appiumDriver.manage().addCookie(new Cookie("mustangprodenv", "testing"));
      //  appiumDriver.manage().addCookie(new Cookie("SENV", "prodb"));
    }

    /**
     * Create Appium DesiredCapabilities
     */
    private DesiredCapabilities createAppiumCapabilities (){
        DesiredCapabilities capabilities = new DesiredCapabilities();
     //   capabilities.setCapability("app", new File(                "app/walMart.apk").getAbsolutePath());
        //capabilities.setCapability(CapabilityType.VERSION, 4.4);
        capabilities.setCapability("automationName", "Appium");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("deviceName", "android");
        capabilities.setCapability("newCommandTimeout", 200);
        capabilities.setCapability("appPackage",
                "com.walmart.grocery");
        capabilities.setCapability("appActivity",
                "com.walmart.grocery.screen.start.StartupActivity");
        return capabilities;
    }

    public AndroidDriver<MobileElement> getDriver()
    {

        return  appiumDriver;
    }

    @AfterSuite(alwaysRun = true)
    protected void tearDown(){

        //appiumDriver.quit();
    }
}
