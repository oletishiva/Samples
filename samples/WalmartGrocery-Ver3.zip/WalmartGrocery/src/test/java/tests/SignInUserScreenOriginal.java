package tests;

import core.TestBase;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePageObjects;
import pages.SignInUserScreen;
import screens.HomeScreen;

public class SignInUserScreenOriginal extends TestBase {



	@Test (groups = { "100loginErrorValidation"},priority=0)

	public void loginErrorValidationTest()
	{
		System.err.println("Appium driver:"+getDriver());
		System.err.println("Appium driver:"+appiumDriver);
		SignInUserScreen sis=new SignInUserScreen()	;
	/*	sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();
		sis.splashScreenNextButtonClick();*/
		//click on SignInButton
		sis.clickSignInButton();
		sis.clickSignInButton();

		System.err.println(sis.getUseramePasswordErrorText());
		Assert.assertEquals(sis.getUseramePasswordErrorText(),
				"Please enter your email address", "The error is displayed..");

		//enter the user name  error message for password
		sis.getUsername().sendKeys("qualitytesting98@gmail.com");
		//	signinObj.getPassword().click();
		sis.getSignInButton().click();
		Assert.assertEquals(sis.getUseramePasswordErrorText(),
				"Please enter a password", "The error message for password is displayed..");
		sis.getUsername().clear();

	}


	@Test (groups = { "101login"})
	public void signIn() {
		SignInUserScreen sis = new SignInUserScreen();
		HomePageObjects h1=new HomePageObjects();
	//	sis.splashScreenNextButtonClick();
		//sis.splashScreenNextButtonClick();
		//sis.splashScreenNextButtonClick();
		//click on SignInButton
	//	sis.clickSignInButton();
		//sis.clickSignInButton();
		sis.getUsername().clear();
		sis.getUsername().sendKeys("qualitytesting98@gmail.com");
		appiumDriver.hideKeyboard();
		sis.getPassword().click();
		sis.getPassword().sendKeys("android1");
		appiumDriver.hideKeyboard();
		sis.getSignInButton().click();

		try {
			if (h1.getCloseBtn().isDisplayed())
				h1.getCloseBtn().click();
		} catch (Exception e) {

		}
	}

		@Test (groups = { "onlyLogin"})
		public void signInOnly()
		{
			SignInUserScreen sis=new SignInUserScreen()	;
			HomePageObjects h1=new HomePageObjects();
			sis.getUsername().clear();
			sis.getUsername().sendKeys("qualitytesting98@gmail.com");
			appiumDriver.hideKeyboard();
			sis.getPassword().click();
			sis.getPassword().sendKeys("android1");
			appiumDriver.hideKeyboard();
			sis.getSignInButton().click();

			try{
				if(h1.getCloseBtn().isDisplayed())
					h1.getCloseBtn().click();
			}
			catch(Exception e)
			{

			}
	}
	
	



	
	
}
