package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class FavouritesObjects {

	
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='FAVORITES']")
			MobileElement favouritesBtn;
	
	@AndroidFindBy(id="com.walmart.grocery:id/favorite_icon")
	MobileElement favouritesIcon;
	
		 @FindBys( {
         @FindBy(id="com.walmart.grocery:id/favorite_indicator")

 } )
 private List<MobileElement> favouritesIndicator;


		@AndroidFindBy(id="com.walmart.grocery:id/filter_header")
		public MobileElement filterHeader;
		

		
	
	 public MobileElement getfavouritesBtn() {
	        return favouritesBtn;
	    }
	 
	 public MobileElement getfavouritesIcon() {
	        return favouritesIcon;
	    }
	 
	 public List<MobileElement> getfavouritesIndicator() {
	        return favouritesIndicator;
	    }
	 
	 


}
