package pageObjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SortAndFilterPageObjects {
	
	@AndroidFindBy(xpath="//*[@text='Sort by' and ../parent::*[@resource-id='com.walmart.grocery:id/list_view']]")
    public MobileElement txtSortBy;

	
	
	 @AndroidFindBy(xpath="//*[@class='android.widget.RadioButton' and ./following-sibling::*[@text='Price: low to high']]")
	    public MobileElement radioBtnTxtLowToHigh;
	 
	 


}
