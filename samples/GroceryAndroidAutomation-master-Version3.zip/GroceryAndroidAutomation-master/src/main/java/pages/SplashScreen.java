package pages;

import core.Driver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.SignInUserScreen;
import pageObjects.SplashScreenPageObject;

import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

public class SplashScreen  extends Driver{

    SplashScreenPageObject splashScreenPageObject=new SplashScreenPageObject();
    public SplashScreen(AppiumDriver<MobileElement> driver){
        super();
        PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), splashScreenPageObject);

    }

    public void clickBtnNext()
    {
       // SignInUserScreen sis=new SignInUserScreen(appiumDriver)	;
        splashScreenPageObject.getButtonNext().click();
        splashScreenPageObject.getButtonNext().click();
        splashScreenPageObject.getButtonNext().click();
    }


}
