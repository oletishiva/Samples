package pages;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import core.BasePage;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.SearchAddRemoveObjects;

public class SearchAddRemove extends BasePage {
	By btnSortAndFilter=By.xpath("//android.widget.Button[@resource-id='com.walmart.grocery:id/refine']");
	SearchAddRemoveObjects searchObject=new SearchAddRemoveObjects();
	public SearchAddRemove(AppiumDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), searchObject);
	}
	
	public void clickSearchButton()
	{
		searchObject.getSearchBtn().click();
	}
	
	public void searchText(String text)
	{
		searchObject.getSearchBox().click();
		searchObject.getSearchBox().clear();
		searchObject.getSearchBox().sendKeys(text);
	}
	
	
	
	public List<MobileElement> getSearchItems()
	{
		return searchObject.getAddList();
	}
	
	public void clickPlusSymbol()
	{
		searchObject.getPlusSymbol().click();
	}
	
	public void clickMinusSymbol()
	{
		searchObject.getSubtractSymbol().click();
	}
	public int getNoOfItemsAddedToCartFromSingleListItem()
	{
		String itemCount=String.valueOf(searchObject.getNoOfItems().getText());
		System.err.println("Item Count:"+itemCount);
		return Integer.parseInt(itemCount);
	}
	
	public MobileElement getFilterHeader()
	 {
		 return searchObject.filterHeader;
	 }
	
	
	public void clickSortAndFilter()
	{
		getFilterHeader().findElement(btnSortAndFilter).click();
	}
	
	public MobileElement getBtnSortAndFilter() {
        return searchObject.btnSortAndFilter;
    }
	
}
