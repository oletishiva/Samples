package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;

import core.BasePage;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import pageObjects.SortAndFilterPageObjects;

public class SortAndFilterPage extends BasePage{
	
	SortAndFilterPageObjects sortFilterPageObjecs=new SortAndFilterPageObjects();

	public SortAndFilterPage(AppiumDriver driver) {
		super(driver);
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), sortFilterPageObjecs);
	}
	
	public void clickOnSortBy()
	{
		sortFilterPageObjecs.txtSortBy.click();
	}
	
	public void clickRadioBtnPriceLowToHigh()
	{
		sortFilterPageObjecs.radioBtnTxtLowToHigh.click();
	}

}
