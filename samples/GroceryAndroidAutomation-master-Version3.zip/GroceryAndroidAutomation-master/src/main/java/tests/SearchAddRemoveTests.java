package tests;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import core.BasePage;
import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.ios.IOSTouchAction;

import pages.CartPage;
import pages.Favourites;
import pages.SearchAddRemove;
import pages.SignInScreen;
import pages.SortAndFilterPage;


public class SearchAddRemoveTests extends TestBase {

	
    @Test
    public void searchAndAdd() {
    	SignInScreen s1=new SignInScreen(new TestBase().getDriver());
        SearchAddRemove search=new SearchAddRemove(new TestBase().getDriver());
        BasePage base = new BasePage(new TestBase().getDriver());
        new SignInTests().signInFlow();
        search.clickSearchButton();
        // searh.getSearchBox().click();
        //   searh.getSearchBox().clear();
        search.searchText("beer");
        base.sendKeyEvent(Key.ENTER_BUTTON);
      
        
        if (search.getSearchItems().get(0).isDisplayed()) {
            Reporter.log("<font color='green'>" + search.getSearchItems().get(0).isDisplayed() + "</font>" + "Is Present", true);
            search.getSearchItems().get(0).click();
        }
        
      
        
    }
    
    @Test
    public void increaseQuantity()
    {
    	 SearchAddRemove search=new SearchAddRemove(new TestBase().getDriver());
    	 search.clickPlusSymbol();
    	 search.clickPlusSymbol();
    	 new TestBase().getDriver().findElement(By.xpath("//*[@resource-id='com.walmart.grocery:id/add_button']")).click();
    }
    @Test
    public void decreaseQuantity()
    {
    	 SearchAddRemove search=new SearchAddRemove(new TestBase().getDriver());
    	 search.clickMinusSymbol();
    	 new TestBase().getDriver().findElement(By.xpath("//*[@resource-id='com.walmart.grocery:id/subtract_button']")).click();
    }
    @Test
    public void getItemCount()
    {
    	 SearchAddRemove search=new SearchAddRemove(new TestBase().getDriver());
    	 int count=search.getNoOfItemsAddedToCartFromSingleListItem();
    	 test.log(Status.INFO,"<font color='green'>" + count + "</font>" + "Will be going to be added to cart");
    }
    @Test
    public void cartPageView()
    {
    	
    	 BasePage base = new BasePage(new TestBase().getDriver());
    	CartPage cp = new CartPage(new TestBase().getDriver());
        base.sendKeyEvent(Key.BACK_BUTTON);
        cp.getCartBtn().click();
        List<MobileElement> items = cp.getCartViewList();
        System.err.println("Items in Card:" + cp.getCartViewList().size());
        test.log(Status.INFO,"<font color='green'>"+"Items in Cart:"+cp.getCartViewList().size()+"</font>");
        
    }
    
    @Test
    public void removeItemsFromCart()
    {
    	
    	CartPage cp = new CartPage(new TestBase().getDriver());
    	
        for (MobileElement ele : cp.getCartViewList()) {
            System.err.println(ele.findElement(By.id("com.walmart.grocery:id/title")).getText());
            test.log(Status.INFO,"<font color='green'>"+"Items Title:"+ele.findElement(By.id("com.walmart.grocery:id/title")).getText()+"</font>");
           // cp.getCartCollapsedQuantityView().click();
            ele.findElement(By.id("com.walmart.grocery:id/collapsed_quantity_view")).click();
            new WebDriverWait(new TestBase().getDriver(), 30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@resource-id='com.walmart.grocery:id/amount']")));
            cp.getCartItems().click();
            cp.getCartItemRemove().click();

            new BasePage(new TestBase().getDriver()).waitSeconds(60);

//*[@resource-id='com.walmart.grocery:id/amount']

      

        }
        
    }
    
    @Test
    public void verifyCartisEmptyOrNot()
    {
    	
    	CartPage cp = new CartPage(new TestBase().getDriver());
		try
			{
			        if(cp.getCartEmptyId().isDisplayed())
			        {
			            test.log(Status.INFO,ExtentColor.GREEN + cp.getCartEmptyId().findElement(By.xpath("//*[@class='android.widget.TextView']")).getText());
			            test.pass(MarkupHelper.createLabel("Passed: CartPage Is Empty ",ExtentColor.GREEN));
			        }
			
			}
		catch(Exception e)
			{
			 test.fail(MarkupHelper.createLabel("Passed: CartPage Is Not Empty ",ExtentColor.RED));       	
			}
        new BasePage(new TestBase().getDriver()).sendKeyEvent(Key.BACK_BUTTON);
        }
    
  @Test
  public void verifySortAndFilter()
	  {
	  SearchAddRemove search=new SearchAddRemove(new TestBase().getDriver());
	  BasePage base = new BasePage(new TestBase().getDriver());
	  SortAndFilterPage sort=new SortAndFilterPage(new TestBase().getDriver());
	  new SignInTests().signInFlow();
      search.clickSearchButton();
      search.searchText("beer");
      base.sendKeyEvent(Key.ENTER_BUTTON);
      new WebDriverWait(new TestBase().getDriver(), 30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//android.widget.Button[@resource-id='com.walmart.grocery:id/refine']")));
	  search.clickSortAndFilter();
	 sort.clickOnSortBy();
	 sort.clickRadioBtnPriceLowToHigh();
	 
	 String str=new Favourites(new TestBase().getDriver()).getFilterHeader().findElement(By.className("android.widget.TextView")).getText().substring(0, 2);
	 System.err.println(str);
	 int count=(Integer.parseInt(str));
	 System.err.println("count:"+count);
	 for(int i=0;i<count;i++)
		 base.scrollDown();
	// base.scrollToElementByIndex("com.walmart.grocery:id/grid_view", i);
		  
	  }
        
    
    }


/*

Point location = ele.getLocation();
Point center = ele.getCenter();
System.err.println("location:"+location);
System.err.println("center:"+center.getX() +":"+center.getY()+":{"+center +"}");
*/
/*TouchAction swipe = new TouchAction(new TestBase().getDriver())
        .press(element(ele,-10, center.y - location.y))
        .waitAction(waitOptions(ofSeconds(2)))
        .moveTo(element(ele,100,center.y - location.y))
        .release();
swipe.perform();*/
/*Point center1 = ele.getCenter();
TouchAction dragNDrop = new TouchAction(new TestBase().getDriver())
        .longPress(longPressOptions()
                .withPosition(point(center1.x, center1.y))
                .withDuration(ofSeconds(10)))
        .moveTo(point(0, center1.y))
        .release();
dragNDrop.perform();

TouchAction remove = new TouchAction(new TestBase().getDriver())
        .longPress(longPressOptions()
                .withPosition(point(center1.x, center1.y))
                .withDuration(ofSeconds(10)))
        .moveTo(point(-100, 0))
        .release();
remove.perform();*/

