package roughCode;

import org.openqa.selenium.Dimension;
import org.testng.annotations.Test;

import core.BasePage;
import core.TestBase;
import io.appium.java_client.TouchAction;
import tests.SignInTests;

public class SwipteTest  extends TestBase{
	
	@Test
	public void swipeToDeleteCardViews()
	{
		new SignInTests().signInFlow();
		
		/*new BasePage(appiumDriver).waitSeconds(120);
				
		TouchAction touchAction =new TouchAction(appiumDriver);
		Dimension size = appiumDriver.manage().window().getSize();
		int y1 = (int) (size.getHeight() * .20);
		int x1 = (int) (size.getWidth()*.50);
		int y2 = (int) (size.getHeight() * .80);

		        touchAction.longPress(x1, y2).moveTo(x1, y1).release().perform();*/
	}

}
