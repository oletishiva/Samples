package core;

/**
 * Created by Bharath Kumar Anumolu
 * Key names to send keycode
 */
public enum Key {
    BACK_BUTTON(4),
    ENTER_BUTTON(66);

    private int value;

    Key(int value) {
        this.value = value;
    }

    public int getValue(){
        return value;
    }
}
