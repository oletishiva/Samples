package tests;

import core.BasePage;
import core.TestBase;
import io.appium.java_client.MobileElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pageobjects.HomePageObjects;
import pageobjects.SignInPageObjects;

public class SignOutTests extends TestBase {
    HomePageObjects h1;
    BasePage g1;
    SignInPageObjects s1;
    String navigatorResourceId="com.walmart.grocery:id/design_navigation_view";

    @Test(groups = { "100logOut"})
    public void signOut()
    {
        h1=new HomePageObjects(appiumDriver);
        g1=new BasePage(appiumDriver);
        s1=new SignInPageObjects(appiumDriver);
        h1.getnavDrawer().click();
        MobileElement element=g1.scrollToElementByName("Sign out",navigatorResourceId);
        element.click();
        if(s1.getSignInButton().isDisplayed())
            Reporter.log("<font color='green'>"+ "User Signed out Successfully" +"</font>" ,true);
    }

}
