package tests;


import core.BasePage;
import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pageobjects.CartPageObject;
import pageobjects.SearchAddRemovePageObjects;
import pageobjects.SignInPageObjects;

import static io.appium.java_client.touch.offset.ElementOption.element;
import java.util.List;

import static java.time.Duration.ofSeconds;


public class SearchAddRemoveTests extends TestBase {


    @Test(groups = {"100searchAdd"})
    public void searchAndAdd() {
        SignInPageObjects sis = new SignInPageObjects(getDriver());
        SearchAddRemovePageObjects searh = new SearchAddRemovePageObjects(getDriver());
        BasePage gen = new BasePage(getDriver());
        CartPageObject cp = new CartPageObject(getDriver());
        searh.getSearchBtn().click();
        // searh.getSearchBox().click();
        //   searh.getSearchBox().clear();
        searh.getSearchBox().sendKeys("beer");
        gen.sendKeyEvent(Key.ENTER_BUTTON);
        if (searh.getAddList().get(0).isDisplayed()) {
            Reporter.log("<font color='green'>" + searh.getAddList().get(0).getText() + "</font>" + "Is Present", true);
            searh.getAddList().get(0).click();
        }
        gen.verifyElementPresent(searh.getPlusSymbol());
        gen.verifyElementPresent(searh.getSubtractSymbol());
        gen.verifyElementPresent(searh.getNoOfItems());
        gen.sendKeyEvent(Key.BACK_BUTTON);
        cp.getCartBtn().click();
        List<MobileElement> items = cp.getCartViewList();
        System.err.println("Items in Card:" + cp.getCartViewList().size());

        for (MobileElement ele : cp.getCartViewList()) {
            System.err.println(ele.findElement(By.id("com.walmart.grocery:id/title")).getText());
           // cp.getCartCollapsedQuantityView().click();
            ele.findElement(By.id("com.walmart.grocery:id/collapsed_quantity_view")).click();
            new WebDriverWait(getDriver(), 30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@resource-id='com.walmart.grocery:id/amount']")));
            cp.getCartItems().click();
            cp.getCartItemRemove().click();

            new BasePage(getDriver()).waitSeconds(30);

        }

        if(cp.getCartEmptyId().isDisplayed())
        {
            Reporter.log("<font color='green'>" + cp.getCartEmptyId().findElement(By.xpath("//*[@class='android.widget.TextView']")).getText() + "</font>" + "Is Present", true);
        }
        gen.sendKeyEvent(Key.BACK_BUTTON);
    }


}
