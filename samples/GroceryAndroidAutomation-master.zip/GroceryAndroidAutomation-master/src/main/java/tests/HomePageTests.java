package tests;


import core.TestBase;
import org.testng.annotations.Test;
import pages.HomePage;




public class HomePageTests extends TestBase {



    @Test(groups = { "101navigationItems"})
    public void verifyNavigationDrawerItems()
    {

        HomePage h1=new HomePage(new TestBase().getDriver());
        h1.getyNavigationDrawerItems();

    }

    @Test(groups = { "102HorizontalTabularItems"})

    public void verifyHorizontalTabularItemsInHomePage()
    {
    	HomePage h1=new HomePage(new TestBase().getDriver());
        h1.clickHomeInHambergerMenu();
        h1.getHorizontalTabularItemsInHomePage();
    }
   







}
