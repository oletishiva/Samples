package tests;

import core.TestBase;
import org.testng.Assert;
import org.testng.annotations.Test;
import pageobjects.SignInPageObjects;
import pages.SignInPage;

public class SignInTestOld extends TestBase {

    @Test(groups = {"100loginErrorValidation"}, priority = 0)
    public void loginErrorValidationTest() {
        System.err.println("Appium driver:" + getDriver());
        System.err.println("Appium driver:" + appiumDriver);
        SignInPage signInPage = new SignInPage(appiumDriver);
        signInPage.splashScreenNextButtonClick();
        signInPage.splashScreenNextButtonClick();
        signInPage.splashScreenNextButtonClick();

        //click on SignInButton
        signInPage.clickSignInButton();
        signInPage.clickSignInButton();

        System.err.println(signInPage.getUseramePasswordErrorText());
        Assert.assertEquals(signInPage.getUseramePasswordErrorText(),
                "Please enter your email address", "The error is displayed..");

        //enter the user name  error message for password
        signInPage.enterUserName("qualitytesting98@gmail.com");
        signInPage.clickSignInButton();

        Assert.assertEquals(signInPage.getUseramePasswordErrorText(), "Please enter a password", "The error message for password is displayed..");
        signInPage.clearUserName();
    }

    @Test(groups = {"101login"})
    public void signIn() {
        SignInPageObjects sis = new SignInPageObjects(appiumDriver);
        sis.getUsername().clear();
        sis.getUsername().sendKeys("qualitytesting98@gmail.com");
        appiumDriver.hideKeyboard();
        sis.getPassword().click();
        sis.getPassword().sendKeys("android1");
        appiumDriver.hideKeyboard();
        sis.getSignInButton().click();

        try {
            if (sis.getCloseBtn().isDisplayed())
                sis.getCloseBtn().click();
        } catch (Exception e) {

        }
    }

    @Test(groups = {"onlyLogin"})
    public void signInOnly() {
        SignInPageObjects sis = new SignInPageObjects(appiumDriver);
        sis.getUsername().clear();
        sis.getUsername().sendKeys("qualitytesting98@gmail.com");
        appiumDriver.hideKeyboard();
        sis.getPassword().click();
        sis.getPassword().sendKeys("android1");
        appiumDriver.hideKeyboard();
        sis.getSignInButton().click();

        try {
            if (sis.getCloseBtn().isDisplayed())
                sis.getCloseBtn().click();
        } catch (Exception e) {

        }
    }

}
