package pageobjects;

import core.BasePage;
import core.BasePageObject;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class HomePageObjects extends BasePageObject {

    public HomePageObjects(AndroidDriver driver) {
        super(driver);
    }

    @AndroidFindBy(xpath ="//android.widget.ImageButton[@content-desc='Open navigation drawer']")
    MobileElement navDrawer;

    @AndroidFindBy(id = "com.walmart.grocery:id/close")
    MobileElement closebtn;

    public MobileElement getnavDrawer() {
        return navDrawer;

    }

    public MobileElement getCloseBtn() {
        return closebtn;

    }
}
