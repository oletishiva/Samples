package tests;

import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import screens.HomeScreen;
import screens.SignInScreen;
import screens.SplashScreen;

import java.util.concurrent.TimeUnit;

public class SignInTests extends TestBase{





    @Test(groups = { "100UserNameErrorValidation"})
    public void auserNameErrorValidation(){
        SplashScreen splash=new SplashScreen(new TestBase().getDriver());
        SignInScreen s1=new SignInScreen(new TestBase().getDriver());
        HomeScreen h1=new HomeScreen(new TestBase().getDriver());

        splash.clickBtnNext();

        s1.clickSignIn();
        s1.clickSignIn();
        s1.userNameErrorValidation();
    }

    @Test(groups = { "101PasswordErrorValidation"})
    public void passWordErrorValidation(){
        SplashScreen splash=new SplashScreen(new TestBase().getDriver());
        SignInScreen s1=new SignInScreen(new TestBase().getDriver());
        HomeScreen h1=new HomeScreen(new TestBase().getDriver());

        s1.enterUserName("qualitytesting98@gmail.com");
        s1.clickSignIn();
    }

    @Test(groups = { "102Login"})
     public void signIn()
    {
        SplashScreen splash=new SplashScreen(new TestBase().getDriver());
        SignInScreen s1=new SignInScreen(new TestBase().getDriver());
        HomeScreen h1=new HomeScreen(new TestBase().getDriver());

        s1.login("qualitytesting98@gmail.com","android1");
        h1.clickCancelButtonIFExistsInHomeScreen();
    }

}
