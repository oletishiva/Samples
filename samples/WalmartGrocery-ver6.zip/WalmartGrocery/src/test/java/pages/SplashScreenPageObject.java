package pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SplashScreenPageObject {

    @AndroidFindBy(xpath = "//*[@text='NEXT']")
    MobileElement btnNext;

    public MobileElement getButtonNext()
    {
        return btnNext;
    }
}
