package core;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Driver extends TestBase{

       public static AndroidDriver<MobileElement> appiumDriver;

    public Driver() {
        this.appiumDriver = super.getDriver();
    }
}
