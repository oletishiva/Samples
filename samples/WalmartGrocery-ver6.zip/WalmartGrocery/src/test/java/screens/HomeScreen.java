package screens;

import core.Driver;
import core.Key;
import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.service.local.AppiumDriverLocalService;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.aventstack.extentreports.Status;

import pages.GeneralPage;
import pages.HomePageObjects;
import pages.SignInUserScreen;
import tests.HomePageTests;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class HomeScreen extends GeneralPage {


    GeneralPage g1;
    SignInUserScreen s1;
    

    String[] navDrawerItms = { "Home","Favorites","Departments","Reserve a time","Your Orders","Payment Methods","Contact Us","Refer & get $10 off","Refer & get $10 off","About Walmart Grocery","Walmart App","Sign out","Version 3.4.0-qa-debug" };
    List<String> navigationItems= Arrays.asList( navDrawerItms );

    String[] tabularItems = { "HOME","FAVORITES","DEPARTMENTS"};
    List<String> tabularItemList= Arrays.asList( tabularItems );
    String navigatorResourceId="com.walmart.grocery:id/design_navigation_view";
    String horizontalScrollViewTabularResourceID="com.walmart.grocery:id/tab_layout";


    HomePageObjects homePageTests=new HomePageObjects();
    public HomeScreen(AppiumDriver<MobileElement> driver){
        super(appiumDriver);
        PageFactory.initElements(new AppiumFieldDecorator(appiumDriver, 30, TimeUnit.SECONDS), homePageTests);

    }




    public void clickCancelButtonIFExistsInHomeScreen()
    {

        try {
            if (homePageTests.getCloseBtn().isDisplayed())
                homePageTests.getCloseBtn().click();
        } catch (Exception e) {

        }
    }

    public void getyNavigationDrawerItems()
    {

        homePageTests.getnavDrawer().click();

        for(String str:navigationItems) {

            if(new GeneralPage(appiumDriver).scrollAndVerifyElement(str, navigatorResourceId))
             // Reporter.log("<font color='green'>"+ str.toString() +"</font>" ,true);
            	test.log(Status.PASS,"<font color='green'>"+str.toString()+"</font>"+ "Is Present");
            	
            else
             //  Reporter.log("<font color='red'>"+ str.toString() +"</font>" ,false);
               test.log(Status.FAIL,"<font color='green'>"+str.toString()+"</font>"+ "Is not Present");


        }


    }

    public void getHorizontalTabularItemsInHomePage()
    {

        for(String str:tabularItemList) {

            if(new GeneralPage(appiumDriver).scrollAndVerifyElement(str, horizontalScrollViewTabularResourceID))
               // Reporter.log("<font color='green'>"+ str.toString() +"</font>" ,true);
            	test.log(Status.PASS,"<font color='green'>"+str.toString()+"</font>"+ "Is Present");
            else
              // Reporter.log("<font color='red'>"+ str.toString() +"</font>" ,false);
           test.log(Status.FAIL,"<font color='green'>"+str.toString()+"</font>"+ "Is not Present");


        }



    }

    public void clickHomeInHambergerMenu()
    {

        MobileElement element=new GeneralPage(appiumDriver).scrollToElementByName("Home",navigatorResourceId);
        element.click();
    }
    
    public void signOut()
    {
    	homePageTests.getnavDrawer().click();
    	MobileElement element=new GeneralPage(appiumDriver).scrollToElementByName("Sign out",navigatorResourceId);
        element.click();
        
        if(appiumDriver.findElementByXPath("//android.widget.Button[@text='SIGN IN' or @text='Sign In']").isDisplayed())
            //Reporter.log("<font color='green'>"+ "User Signed out Successfully" +"</font>" ,true);
        	test.log(Status.PASS, "<font color='green'>"+ "User Signed out Successfully" +"</font>");
        else
        	test.log(Status.FAIL, "<font color='green'>"+ "User Signed out Failed" +"</font>");	

    }
}
