package testngExamples;

import org.testng.annotations.Test;

public class HomeTests {
	
	@Test
	public void verifyNavigationDrawerItems()
	{
		System.err.println("verifyNavigationDrawerItems");
	}
	@Test
	public void verifyHorizontalTabularItemsInHomePage()
	{
		System.err.println("verifyHorizontalTabularItemsInHomePage");
	}
	@Test
	public void aaaaa()
	{
		System.err.println("aaaaa");
	}

}
