package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

import java.util.Arrays;
import java.util.List;

public class HomePageObjects extends GeneralPage {



    public HomePageObjects(AppiumDriver driver) {
        super(driver);
    }

    @AndroidFindBy(xpath ="//android.widget.ImageButton[@content-desc='Open navigation drawer']")
    MobileElement navDrawer;

    public MobileElement getnavDrawer() {
        return navDrawer;

    }
}
