package pages;

import core.Key;
import core.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebElement;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import utils.Log4Test;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

/**
 * Created by chv on 07.02.2017.
 *
 * General Page
 */
public class GeneralPage extends TestBase{

    protected AppiumDriver driver;

    public GeneralPage(AppiumDriver driver){
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver, 30, TimeUnit.SECONDS), this);
    }

    /**
     * Press Back button on android device
     */
    public void pressBackButton() {
        Log4Test.test("Press Back button");
        sendKeyEvent(Key.BACK_BUTTON);
    }

    /**
     * Press button from Key enum
     */
    public void pressButton(Key key) {
        Log4Test.test("Press " + key + " button");
        sendKeyEvent(key);
    }

    /**
     * Send key event method, for pressing android keys
     */
    public void sendKeyEvent(Key key) {
        ((AndroidDriver) driver).pressKeyCode(key.getValue());
    }

    /**
     * Tap with JavaScriptExecutor
     */
    public void tapJs(MobileElement element){
        HashMap<String, Integer> coords = new HashMap<String, Integer>();
        coords.put("x", element.getLocation().getX());
        coords.put("y", element.getLocation().getY());
        driver.executeScript("mobile: tap", coords);

    }

    /**
     * Set slider value, 0 - min value
     */
    public void setSliderValue(MobileElement slider, int value){
        int startX = slider.getLocation().getX();
        int yAxis = slider.getLocation().getY();

        int moveToXDirection = value + startX;
        new TouchAction(driver)
                .longPress(startX, yAxis)
                .moveTo(moveToXDirection, yAxis)
                .release()
                .perform();
    }

    /**
     * Tap an element
     * @param element - element to tap
     */
    protected void tap(MobileElement element){
        new TouchAction(driver).tap(element).perform();
    }

    public static void scrollToElement(AndroidDriver driver, String elementName, boolean scrollDown) {
        String listID = ((RemoteWebElement) driver.findElementByAndroidUIAutomator("new UiSelector().className(\"android.widget.ListView\")")).getId();
        String direction;
        if (scrollDown) {
            direction = "down";
        } else {
            direction = "up";
        }
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", direction);
        scrollObject.put("element", listID);
        scrollObject.put("text", elementName);
        driver.executeScript("mobile: scrollTo", scrollObject);
    }

    public MobileElement scrollToElementByName(String elementName, String listId) {
        MobileElement element = (MobileElement) ((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()" +
                ".resourceId(\"" + listId + "\"))" +
                ".scrollIntoView(new UiSelector().text(\"" + elementName + "\"));");
        return element;
    }

public void waitSeconds(int sec)
{
    try
    {
        Thread.sleep(sec);
    }
    catch (Exception e)
    {

    }
}

    public void clickElementUsingBy(By ele)
    {
        waitForVisibilityOf(ele);
        driver.findElement(ele).click();
    }
    public void clickButtonUsingFindBy(MobileElement element)
    {
        element.click();
    }

    public void clear(MobileElement element)
    {
        element.clear();
    }

    public void enterText(MobileElement element,String text)
    {
        element.sendKeys(text);
    }

    protected void waitForVisibilityOf(By mobileElement) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(mobileElement));


    }

    public void verifyElementPresent(MobileElement element)
    {
        try
        {
            if(element.isDisplayed())
                Reporter.log("<font color='green'>"+element.getText()+"</font>"+ "Is Present" ,true);
        }
        catch(Exception e)
        {
            Reporter.log("<font color='red'>"+element+"</font>"+ "Is not Present" ,true);
        }
    }

    public Boolean scrollAndVerifyElement(String elementName, String listId) {
        // appiumDriver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+visibleText+"\").instance(0))").click();


        MobileElement element = (MobileElement) ((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()" +
                ".resourceId(\"" + listId + "\"))" +
                ".scrollIntoView(new UiSelector().text(\"" + elementName + "\"));");

      /*  MobileElement element = appiumDriver.findElement(MobileBy.AndroidUIAutomator(
                "new UiScrollable(new UiSelector().resourceId(\""+listId+"\")).getChildByText("
                        + "new UiSelector().className(\""+className+"\"), \""+elementName+"\")"));*/

        Boolean result=false;
        try
        {
            if(element.isDisplayed())
                result= true;
        }
        catch (Exception e)
        {  return result;}


        return result;
    }

}
