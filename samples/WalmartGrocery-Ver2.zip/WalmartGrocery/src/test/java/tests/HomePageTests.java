package tests;

import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pages.GeneralPage;
import pages.HomePageObjects;
import pages.SignInUserScreen;

import java.util.Arrays;
import java.util.List;

public class HomePageTests extends TestBase {

    String[] navDrawerItms = { "Home","Favorites","Departments","Reserve a time","Your Orders","Payment Methods","Contact Us","Refer & get $10 off","Refer & get $10 off","About Walmart Grocery","Walmart App","Sign out","Version 3.4.0-qa-debug" };
    List<String> navigationItems= Arrays.asList( navDrawerItms );

    String[] tabularItems = { "HOME","FAVORITES","DEPARTMENTS"};
    List<String> tabularItemList= Arrays.asList( tabularItems );

    HomePageObjects h1;
    GeneralPage g1;
    SignInUserScreen s1;
    String navigatorResourceId="com.walmart.grocery:id/design_navigation_view";
    String horizontalScrollViewTabularResourceID="com.walmart.grocery:id/tab_layout";

    @Test(groups = { "101navigationItems"})
    public void verifyNavigationDrawerItems()
    {
        h1=new HomePageObjects(appiumDriver);
        g1=new GeneralPage(appiumDriver);
        s1=new SignInUserScreen(appiumDriver);
        h1.getnavDrawer().click();

        for(String str:navigationItems) {

            if(g1.scrollAndVerifyElement(str, navigatorResourceId))
            Reporter.log("<font color='green'>"+ str.toString() +"</font>" ,true);
           else
                Reporter.log("<font color='red'>"+ str.toString() +"</font>" ,false);


        }
        g1.sendKeyEvent(Key.BACK_BUTTON);


    }

    @Test(groups = { "102HorizontalTabularItems"})
    public void verifyHorizontalTabularItemsInHomePage()
    {
        h1=new HomePageObjects(appiumDriver);
        g1=new GeneralPage(appiumDriver);
        s1=new SignInUserScreen(appiumDriver);

        for(String str:tabularItemList) {

            if(g1.scrollAndVerifyElement(str, horizontalScrollViewTabularResourceID))
                Reporter.log("<font color='green'>"+ str.toString() +"</font>" ,true);
            else
                Reporter.log("<font color='red'>"+ str.toString() +"</font>" ,false);


        }



    }

    /*@Test(groups = { "103logOut"})
    public void signOut()
    {
        h1=new HomePageObjects(appiumDriver);
        g1=new GeneralPage(appiumDriver);
        s1=new SignInUserScreen(appiumDriver);
        h1.getnavDrawer().click();
        MobileElement element=g1.scrollToElementByName("Sign out",navigatorResourceId);
        element.click();
        if(s1.getSignInButton().isDisplayed())
            Reporter.log("<font color='green'>"+ "User Signed out Successfully" +"</font>" ,true);



    }*/







}
