package tests;

/**
 * Created by chv on 07.02.2017.
 *
 * Test data
 */
public class TestData {

    public static final String APP_VERSION = "v.0.5.10";
}
