package tests;


import core.Key;
import core.TestBase;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.SearchAddRemove;
import pages.SignInUserScreen;
import pages.GeneralPage;
import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import java.util.List;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofSeconds;


public class SearchAddRemoveTests extends TestBase {


    @Test(groups = {"100searchAdd"})
    public void searchAndAdd() {
        SignInUserScreen sis = new SignInUserScreen(appiumDriver);
        SearchAddRemove searh = new SearchAddRemove(appiumDriver);
        GeneralPage gen = new GeneralPage(appiumDriver);
        CartPage cp = new CartPage(appiumDriver);
        searh.getSearchBtn().click();
        // searh.getSearchBox().click();
        //   searh.getSearchBox().clear();
        searh.getSearchBox().sendKeys("beer");
        gen.sendKeyEvent(Key.ENTER_BUTTON);
        if (searh.getAddList().get(0).isDisplayed()) {
            Reporter.log("<font color='green'>" + searh.getAddList().get(0).getText() + "</font>" + "Is Present", true);
            searh.getAddList().get(0).click();
        }
        gen.verifyElementPresent(searh.getPlusSymbol());
        gen.verifyElementPresent(searh.getSubtractSymbol());
        gen.verifyElementPresent(searh.getNoOfItems());
        gen.sendKeyEvent(Key.BACK_BUTTON);
        cp.getCartBtn().click();
        List<MobileElement> items = cp.getCartViewList();
        System.err.println("Items in Card:" + cp.getCartViewList().size());

        for (MobileElement ele : cp.getCartViewList()) {
            System.err.println(ele.findElement(By.id("com.walmart.grocery:id/title")).getText());
           // cp.getCartCollapsedQuantityView().click();
            ele.findElement(By.id("com.walmart.grocery:id/collapsed_quantity_view")).click();
            new WebDriverWait(appiumDriver, 30).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@resource-id='com.walmart.grocery:id/amount']")));
            cp.getCartItems().click();
            cp.getCartItemRemove().click();

            new GeneralPage(appiumDriver).waitSeconds(30);

//*[@resource-id='com.walmart.grocery:id/amount']

        /*

            Point location = ele.getLocation();
            Point center = ele.getCenter();
            System.err.println("location:"+location);
            System.err.println("center:"+center.getX() +":"+center.getY()+":{"+center +"}");
*/
            /*TouchAction swipe = new TouchAction(appiumDriver)
                    .press(element(ele,-10, center.y - location.y))
                    .waitAction(waitOptions(ofSeconds(2)))
                    .moveTo(element(ele,100,center.y - location.y))
                    .release();
            swipe.perform();*/
            /*Point center1 = ele.getCenter();
            TouchAction dragNDrop = new TouchAction(appiumDriver)
                    .longPress(longPressOptions()
                            .withPosition(point(center1.x, center1.y))
                            .withDuration(ofSeconds(10)))
                    .moveTo(point(0, center1.y))
                    .release();
            dragNDrop.perform();

            TouchAction remove = new TouchAction(appiumDriver)
                    .longPress(longPressOptions()
                            .withPosition(point(center1.x, center1.y))
                            .withDuration(ofSeconds(10)))
                    .moveTo(point(-100, 0))
                    .release();
            remove.perform();*/

        }

        if(cp.getCartEmptyId().isDisplayed())
        {
            Reporter.log("<font color='green'>" + cp.getCartEmptyId().findElement(By.xpath("//*[@class='android.widget.TextView']")).getText() + "</font>" + "Is Present", true);
        }
        gen.sendKeyEvent(Key.BACK_BUTTON);
    }


}
