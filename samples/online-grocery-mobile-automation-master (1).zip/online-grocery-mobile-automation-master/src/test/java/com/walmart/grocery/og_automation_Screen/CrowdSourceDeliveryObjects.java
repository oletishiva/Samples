package com.walmart.grocery.og_automation_Screen;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CrowdSourceDeliveryObjects {
	WebDriver driver;

	public CrowdSourceDeliveryObjects(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy( className = "XCUIElementTypeSearchField" )
	WebElement Search;
	
	public WebElement keywordSearch() {
		return Search;
		
	}
}
