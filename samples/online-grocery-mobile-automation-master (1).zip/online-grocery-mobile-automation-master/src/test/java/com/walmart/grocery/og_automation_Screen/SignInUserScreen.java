package com.walmart.grocery.og_automation_Screen;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInUserScreen {
	WebDriver driver;		
	public SignInUserScreen(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(name = "SignInButton")
	WebElement SignInButton;
	@FindBy( className = "XCUIElementTypeTextField" )
	WebElement Username;
	@FindBy( className = "XCUIElementTypeSecureTextField" )
	WebElement Password;
	@FindBy(name = "Search")
	WebElement Search;
	@FindBy(className = "XCUIElementTypeButton")
	WebElement Account;
	@FindBy(name = "ZipCode")
	WebElement ZipCode;
	
	
	public WebElement signInButton() {
		return SignInButton;
		
	}
	public WebElement username() {
		return Username;
		
	}
	public WebElement password() {
		return Password;
		
	}
	public WebElement account() {
		return Account;
		
	}
	public WebElement zipCode() {
		return ZipCode;
	}
	

}
