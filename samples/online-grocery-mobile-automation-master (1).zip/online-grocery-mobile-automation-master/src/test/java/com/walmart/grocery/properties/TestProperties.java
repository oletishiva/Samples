package com.walmart.grocery.properties;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestProperties {
	public static Properties prop = new Properties();
	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("//Users//vn0ef3o//eclipse-workspace//og-automation//src//test//resources//properties//og_walmart.properties");
		prop.load(fis);
		System.out.println(prop.getProperty("explicit.wait"));
	
	}
}
