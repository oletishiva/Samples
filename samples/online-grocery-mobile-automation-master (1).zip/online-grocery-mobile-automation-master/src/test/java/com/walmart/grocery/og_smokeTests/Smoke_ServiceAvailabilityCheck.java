package com.walmart.grocery.og_smokeTests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.SignInUserScreenOriginal;
import com.walmart.grocery.og_base.TestBase;

public class Smoke_ServiceAvailabilityCheck extends TestBase{
	@BeforeTest
	public void init() {
		sis = new SignInUserScreenOriginal(driver);
	}
	@Test(priority= 1)
	public void IntroductionScreen(){
	sis.localMockServerSetup();
	}
	@Test(priority= 2)
	public void enterZipCode(){
	sis.serviceAvailabilityCheck();
	}
}
