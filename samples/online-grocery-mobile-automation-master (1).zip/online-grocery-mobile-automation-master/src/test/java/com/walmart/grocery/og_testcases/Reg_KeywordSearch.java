package com.walmart.grocery.og_testcases;

import java.util.List;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.KeywordSearchScreen;
import com.walmart.grocery.og_base.TestBase;

import io.appium.java_client.ios.IOSElement;

public class Reg_KeywordSearch extends TestBase {

	@BeforeTest
	public void init() {
		kss = new KeywordSearchScreen(driver);
	}
	@Test(priority = 4)
	public void SignInUser() {
		kss.SignInUser();
	}
	@Test(priority = 5)
	public void KeywordSearch() throws InterruptedException {
		kss.KeywordSearch();
	}
	@Test(priority=6)
	public void toolBarButtonsDisplayed() throws InterruptedException {
		kss.CheckTabbarItems();	
	}
	@Test(priority=7)
	public void swtichToDeparmentScreen() {
		kss.departmentsScreen();
		System.out.println("I am in the KeySeacrh Screen");
		List<IOSElement> list = driver.findElementsByClassName("XCUIElementTypeStaticText");
		for (IOSElement st : list) {
			System.out.println(st.getText());
		}
	}	
}
