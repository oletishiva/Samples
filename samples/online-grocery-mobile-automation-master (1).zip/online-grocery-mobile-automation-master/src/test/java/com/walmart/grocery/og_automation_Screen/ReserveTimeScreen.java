package com.walmart.grocery.og_automation_Screen;

import com.walmart.grocery.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;

public class ReserveTimeScreen extends ScreenBase{

	public ReserveTimeScreen(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
