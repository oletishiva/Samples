package com.walmart.grocery.og_testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.SignInUserScreenOriginal;
import com.walmart.grocery.og_base.TestBase;;

public class Reg_SignInExistingUser extends TestBase{
	@BeforeTest
	public void init() {
		sis = new SignInUserScreenOriginal(driver);
	}
	@Test(priority= 1)
	public void IntroductionScreen(){
	sis.localMockServerSetup();
	}
	@Test(priority= 2)
	public void SignInUserTest() throws InterruptedException{
	sis.signInUser();
	}
	@Test(priority=3)
	public void toolBarButtonsDisplayed() {
		sis.toolBarButtonsDisplayed();
	}
	@Test(priority=4)
	public void SignOutUserTest() {
		sis.signOutUser();
	}
	
}
