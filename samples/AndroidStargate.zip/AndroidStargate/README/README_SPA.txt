stargate SPA Usage Documentation (Setting up the SPA)

--Setting up your System for SPA--

SPA ANDROID: (CHROME)
References: http://paul.kinlan.me/installing-chrome-for-android-on-an-emulator/ 
APK Download location for Chromium: http://commondatastorage.googleapis.com/chromium-browser-continuous/index.html?prefix=Android/295676/ 

1.make sure you have installed chrome.apk in your emulator.
	As per google, you cannot install chrome browser in emulator. To do this you have to build the chromium project.
	Appium supports only chrome browsers whose version > 28
	We uploaded a sample apk of chrome in our external folder. Version = 35.0
	However, there are some chrome apk's you can get from internet too.
	This apk we uploaded in External folder works in API > 18. 
	So if you want to run in API 17, you have to download chrome apk which supports/works in API 17.
	Android emulator must start with 'Use HOST GPU' option.
	Without this option, chrome would not run in emulator. 
	In sgConfig.properties, please pass browser as 'chrome'
	
2. You can the latest Chromedriver from http://chromedriver.storage.googleapis.com/index.html 
	By default appium comes with a chromedriver which will be in the location : ~\AppiumForWindows\node_modules\appium\build\chromedriver\windows.
	you can copy the latest driver here and start your execution.

KNOWN ISSUE:
1. Scroll does not work.

SPA IOS: (SAFARI)
1) In sgConfig.properties, please pass browser as 'safari'