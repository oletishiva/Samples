stargate OCR Usage Documentation (Setting up the ocr)

--Setting up your System for OCR--

1.make sure you have installed Windows/mac Tesseract binaries form 
	win - https://code.google.com/p/tesseract-ocr/downloads/list/tesseract-ocr-setup-3.02.02.exe
	mac - http://www.malcolmhardie.com/ocr/

2.install vc++ 2012 redistributes on your system
3.make sure to add your external tess4j,jna,jai_imageio jars to your project
4.Good to go!!


Trouble shooting - 

1.in case of classnotfoundexception while doing ocr ,check whether you have added referenced tesseract jars to 
your project.
2.in case of unsatisfied link error,make sure to install vc++ 2012 into your system

*for more info on tesseract/tess4j ,visit - http://tess4j.sourceforge.net/usage.html

methods related information is provided as comments above corresponding methods.