/**
 * 
 */
/**
 * 
 */
package org.kony.qa.stargate.wrappers.appy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;

import java.util.HashMap;

import org.kony.qa.stargate.common.Constants;
import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.common.SgConstants.ScrollDirection;
import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.interactions.Actions;

/**
 * Convenient class for doing most frequent operations. Element specific
 * operations here can also be done with SgElement instance. If you have
 * multiple operations to be performed on a single Element (for example, click,
 * getText(), takeScreenShotAndCompare() ..) then SgElement instance is best bet
 * for performance reasons. Otherwise each call to this class's static method
 * will create and destroy SgElement for its operation
 * 
 * @author Sanyasi Naidu
 * 
 */
/*
 * Change list: Created by Sanyasi Naidu 15th July 2014: Modified by Kiran.Chava
 * according to Stargate architecture requirements
 * 
 * 2014/Aug/16 : Kiran.Chava : Added swipe specific functionalities. Improved
 * the implementation of most of the methods here.
 */
public class Gestures {

    // to swipe we don't want to start at the edges. We will start swipes a
    // little inside of edges. This is more prone to succeed.
    private static final int EPSILON = 10;

    /**
     * click an element by its displayed name. This is a convenient static
     * method for sgElement.click();
     * 
     * @param text
     * @throws Exception
     */
    public static void clickByName(String text) throws Exception {
	SgElement sgElement = SgElement.getSgElement("name", text);
	sgElement.click();
    }

    /**
     * Click on the ListBox/ComboBox Element which is value for IOS and name for
     * rest of the platform
     * 
     * @param text
     * @throws Exception
     */
    public static void clickOnListBox(String text) throws Exception {
	clickByName(text);
    }

    /**
     * Click by the value. This is same as clickByName for non-SPA platforms.
     * But for SPA platforms this takes value instead of name
     * 
     * @param text
     * @throws Exception
     */
    public static void clickByValue(String text) throws Exception {
	SgElement sgElement = SgElement.getSgElement("value", text);
	sgElement.click();
    }

    public static void dragForBrowser(SgElement sliderElement, int x, int y) {

    }

    /**
     * Clicks an element by given xpath. Convenient method for
     * sgElement.click();
     * 
     * @param text
     * @throws Exception
     */
    public static void clickByXPath(String text) throws Exception {
	SgElement sgElement = SgElement.getSgElement("xpath", text);
	sgElement.click();
    }

    /**
     * Press an element by name. note: make sure you call release() after this
     * method. Use sgElement.press() if you have to pressByclass and other
     * requirements.
     * 
     * @param text
     * @throws Exception
     */
    public static void pressByName(String text) throws Exception {
	SgElement sgElement = SgElement.getSgElement("name", text);
	sgElement.press();
    }

    public static void clickByClass(String className) throws Exception {
	SgElement sgElement = SgElement.getSgElement("class", className);
	sgElement.click();
    }

    public static void clickByClassWithIndex(String className, int index)
	    throws Exception {
	SgElement sgElement = SgElement.getSgElement("class", className, index);
	sgElement.click();
    }

    public static void click(String locatorType, String locator)
	    throws Exception {
	SgElement sgElement = SgElement.getSgElement(locatorType, locator);
	sgElement.click();
    }

    /**
     * 
     * @param locatorType
     * @param locator
     * @throws Exception
     */
    public static void tap(String locatorType, String locator) throws Exception {
	Wait.waitForEnable(locatorType, locator);
	click(locatorType, locator);
    }

    // Applicable to android
    public static void pressBack() throws Exception {
	Driver driver = Driver.getInstance();
	((AppiumDriver) driver.appy).sendKeyEvent(AndroidKeyCode.BACK);
    }

    /**
     * Press Menu followed by an item with given name. We try this twice if we
     * don't find an element name. This two twice attempt will ensure success if
     * in first attempt we pressed menu too early and splash screen was alive
     * 
     * @param name
     * @throws Exception
     */
    public static void pressMenuItem(String name) throws Exception {
	pressMenuItem(name, 0);
    }

    public static void pressMenuItem(String name, int index) throws Exception {
	// We do polling for ten times, each time waiting 5 sec.
	int count = 10;
	do {
	    try {
		pressMenu();
		SgElement menuElement = SgElement.getSgElement("name", name,
			false);
		Thread.sleep(Constants.SHORT_DELAY);
		menuElement.click();
		break;
	    } catch (Exception e) {
		Thread.sleep(5000);
	    }
	    if (count == 7) {
		Driver.restart();
	    }
	    count--;
	} while (count > 0);
    }

    /**
     * Press Menu for Android. silently returns for iOS and other.
     * 
     * @throws Exception
     */
    public static void pressMenu() throws Exception {
	Keyboard.sendKeyEvent(AndroidKeyCode.MENU);
    }

    /**
     * Press Home for Android. silently returns for iOS and other.
     * 
     * @throws Exception
     */
    public static void pressHome() throws Exception {
	Keyboard.sendKeyEvent(AndroidKeyCode.HOME);
    }

    /**
     * scrolls until an element is visible
     * 
     * @param direction
     * @param elementText
     * @throws Exception
     */
    public static void scrollUntilVisible(String direction, String elementText)
	    throws Exception {
	scrollUntilVisibleBy(direction, "name", elementText);
    }

    /**
     * 
     * @param direction
     * @param locatorType
     * @param locator
     * @throws Exception
     */
    public static void scrollUntilVisibleBy(String direction,
	    String locatorType, String locator) throws Exception {
	scrollUntilVisibleBy(direction, locatorType, locator, true);
    }

    /**
     * 
     * @param direction
     * @param locatorType
     * @param locator
     * @param tryBothDirections
     *            If this is true, then we try UP after DOWN and vice-versa.
     * @throws Exception
     */
    public static void scrollUntilVisibleBy(String direction,
	    String locatorType, String locator, boolean tryBothDirections)
	    throws Exception {
	int scrollCount = 5;

	int count = 0;
	do {
	    // See if the element is visible.
	    if (SgElement.isElementVisible(locatorType, locator)) {
		return;
	    }
	    switch (direction) {
	    case "UP":
		swipeUp();
		break;
	    case "DOWN":
		swipeDown();
		break;
	    case "RIGHT":
		swipeRight();
		break;
	    case "LEFT":
		swipeLeft();
		break;
	    default:
		throw new StargateException(
			"Invalid direction received. Only UP, DOWN, RIGHT, LEFT are allowed. Current value is : "
				+ direction);
	    }

	    // We try 5 times, each time there is enough timeout in finding
	    // elements. This must be more than enough.
	    count++;
	} while (count < scrollCount);
	// We are here that means, the element is not yet visible.
	if (tryBothDirections) {
	    String directionNew;
	    switch (direction) {
	    case "UP":
		directionNew = "DOWN";
		break;
	    case "DOWN":
		directionNew = "UP";
		break;
	    case "RIGHT":
		directionNew = "LEFT";
		break;
	    case "LEFT":
		directionNew = "RIGHT";
		break;
	    default:
		throw new StargateException(
			"Invalid direction received. Only UP, DOWN, RIGHT, LEFT are allowed. Current value is : "
				+ direction);
	    } // end of switch
	    tryBothDirections = false; // be careful. don't go into infinite
	    scrollUntilVisibleBy(directionNew, locatorType, locator,
		    tryBothDirections);
	}
    }

    /**
     * This Function lets the user to change the orientation of the device. test
     * cases need not to call this,this is used by ScreenshotUtil class.
     * isResetScreenshotFolderPaths if true sets all the folder path variables
     * in sgcpabilties.
     * 
     * @param orientation
     * @param isSetFolderPath
     * @throws Exception
     */
    static void setOrientation(String orientation,
	    boolean isResetScreenshotFolderPaths) throws Exception {
	Gestures.setOrientation(orientation);
	Driver driver = Driver.getInstance();
	if (isResetScreenshotFolderPaths) {
	    driver.sgCapabilities.setBaselineImageDirectory();
	    driver.sgCapabilities.setActualImageDirectory();
	    driver.sgCapabilities.setDiffImageDirectory();
	    driver.sgCapabilities.setErrorimageDirectory();
	}
    }

    /**
     * This Function lets the user to change the orientation of the device.
     * 
     * @param orientation
     * @throws Exception
     */

    public static void setOrientation(String orientation) throws Exception {
	Driver driver = Driver.getInstance();
	orientation = orientation.toUpperCase();
	try {
	    switch (orientation) {
	    case "PORTRAIT":
		if (((AppiumDriver) driver.appy).getOrientation() != ScreenOrientation.PORTRAIT) {
		    ((AppiumDriver) driver.appy)
			    .rotate(ScreenOrientation.PORTRAIT);
		}
		break;

	    case "LANDSCAPE":
		if (((AppiumDriver) driver.appy).getOrientation() != ScreenOrientation.LANDSCAPE) {
		    ((AppiumDriver) driver.appy)
			    .rotate(ScreenOrientation.LANDSCAPE);
		}

		break;
	    }
	} catch (Exception e) {
	    Thread.sleep(Constants.SHORT_DELAY);
	    // polling continously if screen rotation is changed to default
	    // orientation or not otherwise we should throw a exception.
	    int counter = 10;
	    orientation = driver.getOrientation();
	    while (counter != 0) {
		if (!orientation.equalsIgnoreCase(SgConfig.getInstance()
			.getDefaultOrientation())) {
		    orientation = driver.getOrientation();
		} else {
		    return;
		}
		counter--;
	    }
	    throw new StargateException(
		    "some exception is generated while throwing the exception");
	}

    }

    /**
     * This Function returns the orientation of the device.
     * 
     * @param orientation
     * @throws Exception
     */
    public static ScreenOrientation getOrientation(String orientation)
	    throws Exception {
	Driver driver = Driver.getInstance();
	return ((AppiumDriver) driver.appy).getOrientation();
    }

    /**
     * swipe's screen right by 65%
     * 
     * @throws Exception
     */
    public static void swipeRight() throws Exception {
	swipeRight(65);

    }

    public static void swipe(int startx, int starty, int endx, int endy)
	    throws Exception {
	swipe(startx, starty, endx, endy, true);
    }

    /**
     * swipe's screen with given coordinates.
     * 
     * @param startx
     * @param starty
     * @param endx
     * @param endy
     *            * @param isScrollable -- false if element/form is swipable ,
     *            true if element/form is Scrollable
     * @throws Exception
     */
    public static void swipe(int startx, int starty, int endx, int endy,
	    boolean isScrollable) throws Exception {

	Gestures.swipe(startx, starty, endx, endy, 1200, isScrollable);
    }

    public static void swipe(int startx, int starty, int endx, int endy,
	    int swipeval) throws Exception {
	swipe(startx, starty, endx, endy, swipeval, true);
    }

    public static void swipe(int startx, int starty, int endx, int endy,
	    int swipeval, boolean isScrollable) throws Exception {
	Driver driver = Driver.getInstance();
	((AppiumDriver) driver.appy)
		.swipe(startx, starty, endx, endy, swipeval);
    }

    public static void swipeRight(int percent) throws Exception {
	swipeRight(percent, true);
    }

    /**
     * Swipe to the right of the Screen
     * 
     * @param percent
     * @param isScrollable
     *            -- false if element/form is swipable , true if element/form is
     *            Scrollable
     * @throws Exception
     */
    public static void swipeRight(int percent, boolean isScrollable)
	    throws Exception {

	Dimension resolution = Driver.getScreenResolution();
	int startx, starty, endx, endy;
	int widthToSwipe = percent * resolution.width / 100;
	starty = resolution.height / 2; // swipe at screen center
	endy = resolution.height / 2;
	startx = (resolution.width - widthToSwipe) / 2;
	endx = startx + widthToSwipe;
	// Handle worst boundary case.
	if (endx > resolution.width) {
	    endx = resolution.width - EPSILON;
	}
	swipe(startx, starty, endx, endy, isScrollable);
    }

    /**
     * swipes left half of screen. we don't fail/throw if we are already at left
     * edge.
     * 
     * @throws Exception
     */
    public static void swipeLeft() throws Exception {
	swipeLeft(65);
    }

    public static void swipeLeft(int percent) throws Exception {
	swipeLeft(percent, true);
    }

    /**
     * swipe screen to left for given percent width
     * 
     * @param percent
     * @param isScrollable
     *            -- false if element/form is swipable , true if element/form is
     *            Scrollable
     * @throws Exception
     */
    public static void swipeLeft(int percent, boolean isScrollable)
	    throws Exception {
	Dimension resolution = Driver.getScreenResolution();
	int startx, starty, endx, endy;
	int widthToSwipe = percent * resolution.width / 100;
	starty = resolution.height / 2; // swipe at screen center
	endy = resolution.height / 2;
	startx = resolution.width - EPSILON;
	startx = resolution.width - ((resolution.width - widthToSwipe) / 2);
	endx = startx - widthToSwipe;
	// Handle worst boundary case.
	if (endx <= 0) {
	    endx = EPSILON;
	}
	swipe(startx, starty, endx, endy, isScrollable);
    }

    /**
     * swipe screen to top 65%
     * 
     * @throws Exception
     */
    public static void swipeUp() throws Exception {
	swipeUp(65);
    }

    public static void swipeDown(int percent) throws Exception {
	swipeDown(percent, true);
    }

    /**
     * swipe screen to down for given percent of height
     * 
     * @param percent
     * @param isScrollable
     *            -- false if element/form is swipable , true if element/form is
     *            Scrollable
     * @throws Exception
     */
    public static void swipeDown(int percent, boolean isScrollable)
	    throws Exception {
	SgLog.entry("swipeDown");
	Dimension resolution = Driver.getScreenResolution();
	int startx, starty, endx, endy;
	int heightToSwipe = percent * resolution.height / 100;
	starty = resolution.height - ((resolution.height - heightToSwipe) / 2);
	endy = starty - heightToSwipe;
	startx = resolution.width / 2;
	endx = resolution.width / 2;
	// Handle worst boundary case.
	if (endy <= 0) {
	    endy = EPSILON;
	}
	swipe(startx, starty, endx, endy, isScrollable);
    }

    /**
     * swipe down by 65%
     * 
     * @throws Exception
     */
    public static void swipeDown() throws Exception {
	swipeDown(65);
    }

    public static void swipeUp(int percent) throws Exception {
	swipeUp(percent, true);
    }

    /**
     * swipe screen up for given percent of height
     * 
     * @param percent
     * @param isScrollable
     *            -- false if element/form is swipable , true if element/form is
     *            Scrollable
     * @throws Exception
     */
    public static void swipeUp(int percent, boolean isScrollable)
	    throws Exception {
	Dimension resolution = Driver.getScreenResolution();
	int startx, starty, endx, endy;
	int heightToSwipe = percent * resolution.height / 100;
	starty = (resolution.height - heightToSwipe) / 2;
	endy = starty + heightToSwipe;
	startx = resolution.width / 2;
	endx = resolution.width / 2;
	// Handle worst boundary case.
	if (endy > resolution.height) {
	    endy = endy - EPSILON;
	}
	swipe(startx, starty, endx, endy, isScrollable);
    }

    /**
     * Swipes screen in given direction.
     * 
     * @param currentDirection
     * @throws Exception
     */
    public static void swipe(ScrollDirection currentDirection) throws Exception {

	switch (currentDirection) {
	case UP:
	    swipeUp();
	    break;
	case DOWN:
	    swipeDown();
	    break;
	case LEFT:
	    swipeLeft();
	    break;
	case RIGHT:
	    swipeRight();
	    break;
	}
    }

    public static void clickOnPopUp(String popUp) throws Exception {
    Wait.mustWaitForVisible("name", popUp);
	Gestures.clickByName(popUp);
    }

    /**
     * Tap at a Given Location(x,y)
     * 
     * @param x
     * @param y
     * @throws Exception
     */
    public static void tapAtLocation(int x, int y,
	    boolean tryWithJavaScriptExecutor) throws Exception {
	if (tryWithJavaScriptExecutor) {
	    Driver driver = Driver.getInstance();
	    HashMap<String, String> arguments = new HashMap<String, String>();
	    arguments.put("tapCount", "1");
	    arguments.put("touchCount", "1");
	    arguments.put("duration", "0.5");
	    arguments.put("x", Integer.toString(x));
	    arguments.put("y", Integer.toString(y));
	    JavascriptExecutor js = (JavascriptExecutor) driver.appy;
	    js.executeScript("mobile: tap", arguments);
	} else {
	    tapAtLocation(x, y);
	}
    }

    public static void tapAtLocation(int x, int y) throws Exception {
	Driver driver = Driver.getInstance();
	TouchAction ta = new TouchAction((AppiumDriver) driver.appy);
	try {
	    ta.tap(x, y);
	    ta.perform();

	} catch (Exception e) {
	    throw e;
	}
    }

    public static void tap(SgElement sgElement) throws Exception {
	Driver driver = Driver.getInstance();
	TouchAction ta = new TouchAction((AppiumDriver) driver.appy);
	ta.tap(sgElement);
	ta.perform();

    }

    public static void press(SgElement sgElement) throws Exception {
	Driver driver = Driver.getInstance();
	TouchAction ta = new TouchAction((AppiumDriver) driver.appy);
	ta.press(sgElement);
	ta.perform();
    }

    /**
     * release a press()
     * 
     * @throws Exception
     */
    public static void release() throws Exception {
	Driver driver = Driver.getInstance();

	TouchAction ta = new TouchAction((AppiumDriver) driver.appy);
	ta.release();
	ta.perform();

    }

    public static void moveTo(int x, int y) throws Exception {
	Driver driver = Driver.getInstance();
	TouchAction ta = new TouchAction((AppiumDriver) driver.appy);
	ta.moveTo(x, y);
	ta.perform();
    }

    /**
     * This method is used when we try to navigate from one form to other form
     * 
     * @param clickLabel
     * @param waitLabel
     * @throws Exception
     */
    public static void navigateToFormByName(String clickLabelOnCurrentForm,
	    String waitLabelOnNewForm) throws Exception {
	Gestures.clickByName(clickLabelOnCurrentForm);
	// Make sure the waitLabel is present in visible portion of the form
	// i.e., at top of the form
	Wait.mustWaitForVisible("name", waitLabelOnNewForm);
    }

    /**
     * It returns the TouchAction object to perform coordinate based touch
     * actions.
     * 
     * @return TouchAction
     */
    public static TouchAction getTouchActionItem() throws Exception {
	TouchAction actionItem = null;
	Driver driver = Driver.getInstance();
	actionItem = new TouchAction((AppiumDriver) driver.appy);
	return actionItem;
    }

    /**
     * It returns alert's text message
     * 
     * @return popupText
     * @throws Exception
     */
    public static String getPopUpText() throws Exception {
	SgLog.entry("Entered: getPopUpText");
	if (Wait.waitForEnable("class", "android.widget.FrameLayout")) {
	    SgElement testImageElement = SgElement.getSgElement("class",
		    "android.widget.TextView");
	    return testImageElement.getText();
	} else {
	    throw new StargateException("Alert not found");
	}

    }

    /**
     * It moves the scrollable element to the distance given in terms of offset.
     * 
     * @param element
     * @param xOffset
     * @param yOffset
     * @throws Exception
     */
    public static void swipeElement(SgElement element, int xOffset, int yOffset)
	    throws Exception {
	Driver driver = Driver.getInstance();
	Actions action = new Actions(driver.appy);
	SgLog.info("Inputs for swipeElement - element : " + element);
	action.clickAndHold(element).moveByOffset(xOffset, yOffset).release()
		.perform();
    }

    /**
     * It double taps on an element at its center.
     * 
     * @param locatorType
     * @param locator
     * @throws Exception
     */
    public static void doubleTap(String locatorType, String locator)
	    throws Exception {
	Wait.waitForEnable(locatorType, locator);
	SgElement sgElement = SgElement.getSgElement(locatorType, locator);
	Point center = sgElement.getCenter();
	sgElement.doubleTap(center.x, center.y);
    }

    /**
     * It executes pan on an element at its co-ordinate.
     * 
     * @param x
     * @param y
     * @throws Exception
     */
    public static void pan(int x, int y) {
	try {
	    Driver driver = Driver.getInstance();
	    TouchAction t1 = new TouchAction((AppiumDriver) driver.appy);
	    TouchAction t2 = new TouchAction((AppiumDriver) driver.appy);
	    t1.press(x, y); // x=100, y=500
	    t2.press(x + 20, y).moveTo(100, 0).release();
	    MultiTouchAction ma = new MultiTouchAction(
		    (AppiumDriver) driver.appy);
	    ma.add(t1).add(t2);
	    ma.perform();
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    /**
     * It executes pinch on an element at its co-ordinate.
     * 
     * @param x
     * @param y
     * @throws Exception
     */
    public static void pinch(int x, int y) {
	try {
	    Driver driver = Driver.getInstance();
	    TouchAction t1 = new TouchAction((AppiumDriver) driver.appy);
	    TouchAction t2 = new TouchAction((AppiumDriver) driver.appy);
	    t1.press(x, y).moveTo(100, 0); // x=200, y=500
	    t2.press(x, y + 100).moveTo(-100, 0).release();
	    MultiTouchAction ma = new MultiTouchAction(
		    (AppiumDriver) driver.appy);
	    ma.add(t1).add(t2);
	    ma.perform();
	} catch (Exception e) {
	    e.printStackTrace();
	}

    }

    /**
     * It double click on an element at its given co-ordinate.
     * 
     * @param x
     * @param y
     * @throws Exception
     */
    public static void doubleTap(int x, int y) {
	try {
	    Driver driver = Driver.getInstance();
	    TouchAction touch = new TouchAction((AppiumDriver) driver.appy);
	    touch.tap(x, y).perform().waitAction(50).tap(x, y).perform();
	} catch (Exception e) {
	    e.printStackTrace();
	}

    }
}