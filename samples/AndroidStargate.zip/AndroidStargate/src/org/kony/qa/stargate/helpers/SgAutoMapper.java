/**
 * 
 */
package org.kony.qa.stargate.helpers;

import com.google.common.collect.BiMap;

/**
 * @author Naidu
 * 
 *         This class will help you in mapping the different widget classes
 *         between android & ios. The tester only needs to pass either Android
 *         Or iOS class names in the JSOn object. We will try to map the classes
 *         here so that each one who automate test case using appium need not to
 *         do one their own. however, this will not work for xpath.
 * 
 */
public class SgAutoMapper {

    static BiMap<String, String> mapAndroidToiOS;
    static BiMap<String, String> mapiOSToAndroid;
    static BiMap<String, String> mapWindowsToAndroid;
    static BiMap<String, String> mapAndroidToWindows;

    /**
     * @param className
     *            -- Widget Class Name
     * @return a string which is required platform widget class name
     * @throws Exception
     *             in case of wrong platform/wrong class name.
     */

    public static String getMappedClass(String className) throws Exception {
	String newClass = null;
	if (Common.isJson(className)) {
	    newClass = Common.convertJSONtoString(className, "Android");
	} else {
	    newClass = className;
	}
	return newClass;

    }

}
