/**
 * 
 */
package org.kony.qa.stargate.wrappers.appy;

import io.appium.java_client.MobileBy;

import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Kiran.Chava
 * 
 */
public class Wait {

    /**
     * Waits for an Element to Be Visible, default Command Timeout is 90 secs.
     * 
     * 
     * @param locatorType
     * @param locator
     * @return --true if element appeared --false if element din't appear
     * @throws Exception
     */
    public static Boolean waitForVisible(String locatorType, String locator)
	    throws Exception {
	int waitTime = 30;
	if (Wait.waitForVisible(locatorType, locator, waitTime))
	    return true;
	return false;
    }

    /**
     * Waits For An Element until for the given amount of Time.
     * 
     * @param locatorType
     * @param locator
     * @param time
     * @return
     * @throws Exception
     */

    public static Boolean waitForVisible(String locatorType, String locator,
	    int time) throws Exception {
	try {
	    Driver driver = Driver.getInstance();

	    WebDriverWait wait = new WebDriverWait(driver.appy, time);
	    switch (locatorType) {
	    case "xpath":
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(MobileBy.xpath(locator)));
		break;
	    case "id":
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(MobileBy.id(locator)));
		break;
	    case "name":
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(MobileBy.name(locator)));

		break;
	    case "tagname":
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(MobileBy.tagName(locator)));
		break;
	    case "class":
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(MobileBy.className(locator)));
		break;
	    }

	} catch (Exception e) {
	    SgLog.warn(e.getStackTrace().toString());
	    return false;
	}
	return true;
    }

    /**
     * waits for enable, if not found then throws StargateExecption()
     * 
     * @param locatorType
     * @param locator
     */
    public static void mustWaitForEnable(String locatorType, String locator)
	    throws Exception {
	if (!Wait.waitForEnable(locatorType, locator)) {
	    throw new StargateException("Wait for element enable failed. "
		    + locatorType + "  : " + locator);
	}
    }

    /**
     * waits for enable for a maximum of fixed interval, if not found then
     * throws StargateExecption()
     * 
     * @param locatorType
     * @param locator
     */
    public static void mustWaitForEnable(String locatorType, String locator,
	    int time) throws Exception {
	if (!Wait.waitForEnable(locatorType, locator, time)) {
	    throw new StargateException("Wait for element enable failed. "
		    + locatorType + "  : " + locator);
	}
    }

    /**
     * waits for visible, if not found then throws StargateException
     * 
     * @param locatorType
     * @param locator
     */
    public static void mustWaitForVisible(String locatorType, String locator)
	    throws Exception {
	if (!Wait.waitForVisible(locatorType, locator)) {
	    throw new StargateException("Wait for element visible failed. "
		    + locatorType + "  : " + locator);
	}
    }

    public static void mustWaitForVisible(String locatorType, String locator,
	    int time) throws Exception {
	if (!Wait.waitForVisible(locatorType, locator, time)) {
	    throw new StargateException("Wait for element visible failed. "
		    + locatorType + "  : " + locator);
	}
    }

    /**
     * WaitForenable of given element, make sure you check return value. Or use
     * mustWaitForEnable function
     * 
     * @param locatorType
     * @param locator
     * @return
     * @throws Exception
     */
    public static Boolean waitForEnable(String locatorType, String locator)
	    throws Exception {
	int waitTime = 30;
	if (Wait.waitForEnable(locatorType, locator, waitTime))
	    return true;
	return false;
    }

    /**
     * Must Wait for PopUp, use this when you must want that element to be
     * visible
     * 
     * @param locatorType
     * @param locator
     * @throws Exception
     */
    public static void mustWaitForPopup(String locatorType, String locator)
	    throws Exception {
	if (!waitForPopUp(locatorType, locator))
	    throw new StargateException("Pop Up Element din't appear");
    }

    /**
     * Wait for a PopUP element , specially used for desktop
     * 
     * @param locatorType
     * @param locator
     * @return
     * @throws Exception
     */
    public static Boolean waitForPopUp(String locatorType, String locator)
	    throws Exception {
	try {
	    Wait.mustWaitForVisible(locatorType, locator);
	} catch (Exception e) {
	    SgLog.warn(e.getStackTrace().toString());
	    SgLog.exit("waitForPopup = false");
	    return false;
	}
	return true;
    }

    public static Boolean waitForEnable(String locatorType, String locator,
	    int time) throws Exception {
	try {
	    Driver driver = Driver.getInstance();
	    WebDriverWait wait = new WebDriverWait(driver.appy, time);
	    switch (locatorType) {
	    case "xpath":
		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.xpath(locator)));
		break;
	    case "id":
		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.id(locator)));
		break;
	    case "name":

		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.name(locator)));
		break;
	    case "value":

		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.name(locator)));
		break;
	    case "tagname":
		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.tagName(locator)));
		break;
	    case "class":
		wait.until(ExpectedConditions.elementToBeClickable(MobileBy
			.className(locator)));
		break;
	    }
	} catch (Exception e) {
	    SgLog.warn(e.getStackTrace().toString());
	    SgLog.exit("waitForEnable = false");
	    return false;
	}

	return true;
    }
}
