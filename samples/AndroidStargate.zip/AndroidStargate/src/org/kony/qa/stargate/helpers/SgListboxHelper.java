/**
 * 
 */
package org.kony.qa.stargate.helpers;

import org.kony.qa.stargate.wrappers.appy.Gestures;
import org.kony.qa.stargate.wrappers.appy.SgElement;

/**
 * @author Kiran.Chava
 *
 */
public class SgListboxHelper {
    /**
     * listBox is UIAPicker on iOS and a custom implementation on Android
     * 
     * @param name
     * @throws Exception
     */
    public static void choose(String name) throws Exception {
	Gestures.clickByName(name);
    }

    /**
     * for accessing a particular picker index.
     * 
     * @param name
     * @param pickerIndex
     * @throws Exception
     */
    public static void chooseOnMultiple(String name, int pickerIndex)
	    throws Exception {
	Gestures.clickByName(name);
    }

    public static void sendValueToListBox(SgElement listElement,
	    String visibleName, String name) throws Exception {
	sendValueToListBox(listElement, visibleName, name, null);
    }

    public static void sendValueToListBox(SgElement listElement,
	    String visibleName, String name, String imageName) throws Exception {
	sendValueToListBox(listElement, visibleName, name, null, imageName);
    }

    public static void sendValueToListBox(SgElement listElement,
	    String visibleName, String name, SgElement sgElement,
	    String imageName) throws Exception {
	listElement.sendKeys(name);
    }
}
