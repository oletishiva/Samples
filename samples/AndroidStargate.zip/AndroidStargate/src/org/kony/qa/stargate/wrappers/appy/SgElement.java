/**
 * 
 */
package org.kony.qa.stargate.wrappers.appy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.FindsByAccessibilityId;
import io.appium.java_client.FindsByAndroidUIAutomator;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.TouchAction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.kony.qa.stargate.helpers.Common;
import org.kony.qa.stargate.common.Constants;
import org.kony.qa.stargate.helpers.SgAutoMapper;
import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.common.SgConstants.ScrollDirection;
import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.FileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;

import com.google.common.collect.ImmutableMap;

/**
 * @author Kiran.Chava
 * 
 */
/*
 * Change list: Created on July 15th: Based upon Naidu's initial code by
 * Kiran.Chava
 */
public class SgElement extends RemoteWebElement implements
	FindsByAccessibilityId, FindsByAndroidUIAutomator {

    public WebElement webElement;

    public SgElement(WebElement originalElement, WebDriver parentDriver) {

	webElement = originalElement;
	this.id = ((RemoteWebElement) originalElement).getId();
	// The super doesn't need the parent object at ALL, it's terrible that
	// it asks for one, when it only needs it for setFoundBy()
	super.setParent((RemoteWebDriver) parentDriver);
    }

    /**
     * Constructor added to get the element with proper identifier. With the
     * only constructor above SgElement's identifier shown as unknown locator.
     * Fixed with this overloaded constructor
     * 
     * @param context
     * @param identifier
     * @param term
     * @param originalElement
     */
    public SgElement(SearchContext context, String identifier, String term,
	    WebElement originalElement) {

	webElement = originalElement;
	this.id = ((RemoteWebElement) originalElement).getId();
	// The super doesn't need the parent object at ALL, it's terrible that
	// it asks for one, when it only needs it for setFoundBy()
	super.setParent((RemoteWebDriver) context);
	super.setFoundBy(context, identifier, term);
    }

    protected FileDetector fileDetector;

    public List<WebElement> findElements(By by) {
	return by.findElements(this);
    }

    public WebElement findElement(By by) {
	return by.findElement(this);
    }

    public WebElement findElementByAndroidUIAutomator(String using) {
	return findElement("-android uiautomator", using);
    }

    public List<WebElement> findElementsByAndroidUIAutomator(String using) {
	return findElements("-android uiautomator", using);
    }

    public WebElement findElementByAccessibilityId(String using) {
	return findElement("accessibility id", using);
    }

    public List<WebElement> findElementsByAccessibilityId(String using) {
	return findElements("accessibility id", using);
    }

    public void setValue(String value) {
	ImmutableMap.Builder builder = ImmutableMap.builder();
	builder.put("id", id).put("value", value);
	execute(MobileCommand.SET_VALUE, builder.build());
    }

    public Point getCenter() throws Exception {
	Point upperLeft = this.getLocation();
	Dimension dimensions = this.getSize();

	return new Point(upperLeft.getX() + dimensions.getWidth() / 2,
		upperLeft.getY() + dimensions.getHeight() / 2);
    }

    /**
     * 
     * @param name
     * @return
     * @throws Exception
     */
    public static SgElement getTextBoxElementByName(String name)
	    throws Exception {
	SgElement sgElement = null;
	// On iOS it is value, and on Android it is name. (spa name will work as
	// we map it to xpath later)
	sgElement = SgElement.getTextBoxOrTextAreaByName(name);

	return sgElement;
    }

    /**
     * 
     * @param name
     * @return
     * @throws Exception
     */
    public static SgElement getTextAreaElementByName(String name)
	    throws Exception {
	SgElement sgElement = null;
	// On iOS it is value, and on Android it is name. (spa name will work as
	// we map it to xpath later)
	sgElement = SgElement.getTextBoxOrTextAreaByName(name);
	return sgElement;
    }

    /*
     * Returns text box / text Area element by name. We need this separate
     * function instead of getSgelement as on some devices (e.g... Samsung
     * core2duo) some text is appending automatically.
     */
    private static boolean toAppendText = false; // saves time to remember

    private static SgElement getTextBoxOrTextAreaByName(String name)
	    throws Exception {
	// scroll = true by default
	return SgElement.getTextBoxOrTextAreaByName(name, true);
    }

    /**
     * returns an element with given name. Use this to handle samsung device
     * special case where name changes dynamically
     * 
     * @param name
     * @param isScroll
     * @return
     * @throws Exception
     */
    public static SgElement getTextBoxOrTextAreaByName(String name,
	    boolean isScroll) throws Exception {
	String appendedTextOnSamsungCore2duo = ". Double tap to edit.";
	String appendedTextOnSamsungCore2duo_editMode = ". Editing.";
	if (!toAppendText) {
	    try {
		SgElement sgElement = SgElement.getSgElement("name", name,
			isScroll);
		return sgElement;
	    } catch (Exception e) {
		try {
		    String newText = name + appendedTextOnSamsungCore2duo;
		    SgElement sgElement = SgElement.getSgElement("name",
			    newText, isScroll);
		    toAppendText = true;
		    return sgElement;
		} catch (Exception e2) {
		    String newText = name
			    + appendedTextOnSamsungCore2duo_editMode;
		    SgElement sgElement = SgElement.getSgElement("name",
			    newText, isScroll);
		    toAppendText = true;
		    return sgElement;
		}
	    }
	} else {
	    // we know for sure this device needs extra text.
	    try {
		String newText = name + appendedTextOnSamsungCore2duo;
		SgElement sgElement = SgElement.getSgElement("name", newText,
			isScroll);
		return sgElement;
	    } catch (Exception e) {
		String newText = name + appendedTextOnSamsungCore2duo_editMode;
		SgElement sgElement = SgElement.getSgElement("name", newText,
			isScroll);
		return sgElement;

	    }
	}
    }

    /**
     * 
     * @param locatorType
     *            (xpath or id or name or value or tagname or class) caution:
     *            finding by name for textbox/textarea you must use
     *            getTextBoxElementByName() and getTextAreaElementByName()
     * @param locator
     * @return WebElement
     * @throws Exception
     */
    public static SgElement getSgElement(String locatorType, String locator)
	    throws Exception {
	return getSgElement(locatorType, locator, true); // by default we scroll
    }

    /**
     * Get element from only visible area. Use this for elements like popups
     * where trying to scroll will fail test case
     * 
     * @param locatorType
     * @param locator
     * @return
     * @throws Exception
     */
    public static SgElement getSgElementFromVisible(String locatorType,
	    String locator) throws Exception {
	// don't scroll we are interested in only visible area
	boolean isScroll = false;
	return getSgElement(locatorType, locator, isScroll);
    }

    public void swipeLeft() throws Exception {
	swipeLeft(50);
    }

    public void swipeLeft(int percentWidthToSwipe) throws Exception {
	swipeLeft(percentWidthToSwipe, true);
    }

    /**
     * Swipes left at element's location.
     * 
     * @param percentWidthToSwipe
     *            How much you want to swipe?
     * @param isScrollable
     *            Is Element Scrollable or Not
     * @throws Exception
     */
    public void swipeLeft(int percentWidthToSwipe, boolean isScrollable)
	    throws Exception {
	Driver driver = Driver.getInstance();
	Dimension resolution = Driver.getScreenResolution();
	Dimension size = this.getSize();
	Point centerPoint = new Point(0, 0);

	centerPoint = this.getCenter();
	int startx, starty, endx, endy;
	int widthToSwipe = percentWidthToSwipe * size.width / 100;
	starty = centerPoint.y;
	endy = centerPoint.y;
	startx = centerPoint.x + widthToSwipe / 2;
	endx = centerPoint.x - widthToSwipe / 2;

	// Handle worst boundary case.
	if (endx <= 0) {
	    endx = 10;
	}
	if (startx > resolution.width) {
	    startx = resolution.width - 10;
	}
	((AppiumDriver) driver.appy).swipe(startx, starty, endx, endy, 500);

    }

    public void swipeRight(int percentWidthToSwipe) throws Exception {
	swipeRight(percentWidthToSwipe, true);
    }

    /**
     * Swipes right for given width in an element.
     * 
     * @param percentWidthToSwipe
     * @throws Exception
     */
    public void swipeRight(int percentWidthToSwipe, boolean isScrollable)
	    throws Exception {
	Driver driver = Driver.getInstance();
	Dimension resolution = Driver.getScreenResolution();
	Dimension size = this.getSize();
	Point centerPoint = new Point(0, 0);
	centerPoint = this.getCenter();
	int startx, starty, endx, endy;
	int widthToSwipe = percentWidthToSwipe * size.width / 100;
	starty = centerPoint.y;
	endy = centerPoint.y;
	startx = centerPoint.x - widthToSwipe / 2;
	endx = centerPoint.x + widthToSwipe / 2;

	// Handle worst boundary case.
	if (startx <= 0) {
	    startx = 10;
	}
	if (endx > resolution.width) {
	    endx = resolution.width - 10;
	}
	((AppiumDriver) driver.appy).swipe(startx, starty, endx, endy, 500);

    }

    /**
     * swipes Right in current element 50% of width.
     * 
     * @throws Exception
     */
    public void swipeRight() throws Exception {
	swipeRight(50);
    }

    /**
     * swipes right the slider element by given width.
     * 
     * @param percentHeightToSwipe
     * @throws Exception
     */
    public void swipeRightSlider(int percentWidthToSwipe) throws Exception {
	swipeRight(percentWidthToSwipe);
    }

    /**
     * swipes left the slider element by given width.
     * 
     * @param percentHeightToSwipe
     * @throws Exception
     */
    public void swipeLeftSlider(int percentWidthToSwipe) throws Exception {
	swipeLeft(percentWidthToSwipe);
    }

    public void swipeBottom(int percentHeightToSwipe) throws Exception {
	swipeBottom(percentHeightToSwipe, true);
    }

    public void swipeBottom(int percentHeightToSwipe, boolean isScrollable)
	    throws Exception {
	Driver driver = Driver.getInstance();
	Dimension resolution = Driver.getScreenResolution();
	Dimension size = this.getSize();
	Point centerPoint = new Point(0, 0);
	centerPoint = this.getCenter();
	int startx, starty, endx, endy;
	int heightToSwipe = percentHeightToSwipe * size.height / 100;
	startx = centerPoint.x;
	endx = centerPoint.x;
	starty = centerPoint.y - heightToSwipe / 2;
	endy = centerPoint.y + heightToSwipe / 2;
	// Handle worst boundary case.
	if (starty <= 0) {
	    starty = 10;
	}
	if (endy > resolution.height) {
	    endy = resolution.height - 10;
	}
	((AppiumDriver) driver.appy).swipe(startx, starty, endx, endy, 500);

    }

    /**
     * swipes Down in current element 50% of width.
     * 
     * @throws Exception
     */
    public void swipeBottom() throws Exception {
	swipeBottom(50);
    }

    public void swipeTop(int percentHeightToSwipe) throws Exception {
	swipeTop(percentHeightToSwipe, true);
    }

    public void swipeTop(int percentHeightToSwipe, boolean isScrollable)
	    throws Exception {
	Driver driver = Driver.getInstance();
	Dimension resolution = Driver.getScreenResolution();
	Dimension size = this.getSize();
	Point centerPoint = new Point(0, 0);
	centerPoint = this.getCenter();
	int startx, starty, endx, endy;
	int heightToSwipe = percentHeightToSwipe * size.height / 100;
	startx = centerPoint.x;
	endx = centerPoint.x;
	starty = centerPoint.y + heightToSwipe / 2;
	endy = centerPoint.y - heightToSwipe / 2;
	// Handle worst boundary case.
	if (starty <= 0) {
	    starty = 10;
	}
	if (endy > resolution.height) {
	    endy = resolution.height - 10;
	}
	((AppiumDriver) driver.appy).swipe(startx, starty, endx, endy, 500);

    }

    /**
     * swipes Top in current element 50% of width.
     * 
     * @throws Exception
     */
    public void swipeTop() throws Exception {
	swipeTop(50);
    }

    /**
     * This is same as getSgElement when index = 0; When index is not zero, it
     * first calls getSgElements to get all elements for given locator strategy
     * and returns given index.
     * 
     * @param locatorType
     * @param locator
     * @param index
     * @return
     * @throws Exception
     */
    public static SgElement getSgElement(String locatorType, String locator,
	    int index) throws Exception {
	boolean isScroll = true;
	return getSgElement(locatorType, locator, isScroll, index);
    }

    /**
     * This is same as getSgElement when index = 0; When index is not zero, it
     * first calls getSgElements to get all elements for given locator strategy
     * and returns given index.
     * 
     * @param locatorType
     * @param locator
     * @param isScroll
     * @param index
     * @return
     * @throws Exception
     */
    public static SgElement getSgElement(String locatorType, String locator,
	    boolean isScroll, int index) throws Exception {
	if (index == 0) {
	    return getSgElement(locatorType, locator, isScroll);
	}
	return getSgElements(locatorType, locator).get(index);
    }

    /**
     * get the element. note: we don't wait for element to be active. Make sure
     * the element is present before calling this method.
     * 
     * @param locatorType
     *            id, class, name, xpath, tagname, value
     * @param locator
     * @param isScroll
     * @return
     * @throws Exception
     */
    public static SgElement getSgElement(String locatorType, String locator,
	    boolean isScroll) throws Exception {

	Driver driver = Driver.getInstance();
	if (isScroll) {
	    // If scroll is true, then let us make sure we scroll enough to keep
	    // the element visible. This will search in all four directions.
	    Gestures.scrollUntilVisibleBy("DOWN", locatorType, locator, true);
	}

	WebElement webElement = null;

	try {

	    switch (locatorType) {
	    case "xpath":

		String newXpath = null;
		newXpath = Common.convertJSONtoString(locator,
			driver.sgCapabilities.getMobilePlatformName());
		if (newXpath == null) {
		    newXpath = locator;
		}
		webElement = (driver.appy)
			.findElement(MobileBy.xpath(newXpath));

		break;
	    case "id":
		webElement = ((AppiumDriver) driver.appy).findElement(MobileBy
			.id(locator));

		break;
	    case "name":

		// Removing two or more consecutive spaces in IOs and
		// considering them as single space because that is how
		// Kony
		// apps is behaving in IOS.
		webElement = (driver.appy).findElement(MobileBy.name(locator));

		break;
	    case "value":
		webElement = (driver.appy).findElement(MobileBy.name(locator));
		break;
	    case "tagname":
		webElement = (driver.appy).findElement(MobileBy
			.tagName(locator));
		break;
	    case "class":
		String newClass = SgAutoMapper.getMappedClass(locator);
		webElement = (driver.appy).findElement(MobileBy
			.className(newClass));
		break;
	    }

	    SgElement sgElementFound = ConvertWebElementToSgElement(webElement,
		    true, locatorType, locator);

	    return sgElementFound;
	} catch (Exception e) {
	    SgLog.warn("Received an exception. This is most likely an error/failure of test case"
		    + " unless test case is expecting this exception.");
	    throw new StargateException(
		    "An element could not be located with given parameters { 'type' : "
			    + locatorType + " , 'value' : " + locator + " }");
	}
    }

    public void click() {
	super.click();
    }

    public void scrollTo() throws Exception {
	Driver driver = Driver.getInstance();
	Thread.sleep(100);

	HashMap<String, String> arguments = new HashMap<String, String>();
	arguments.put("element", this.getId());
	JavascriptExecutor js = (JavascriptExecutor) ((AppiumDriver) driver.appy);
	js.executeScript("mobile: scrollTo", arguments);

	Thread.sleep(100);

    }

    /*
     * Converts given webElement to our SgElement a simple caste won't work
     */
    private static SgElement ConvertWebElementToSgElement(
	    WebElement webElement, boolean isSleep, String locatorType,
	    String locator) throws Exception {
	Driver driver = Driver.getInstance();
	SgElement sgElement = new SgElement(driver.appy, locatorType, locator,
		webElement);
	sgElement.setParent((AppiumDriver) driver.appy);

	String id = ((RemoteWebElement) (webElement)).getId();
	sgElement.setId(id);

	sgElement.setFileDetector(((AppiumDriver) driver.appy)
		.getFileDetector());

	/*
	 * when we find the element by scrolling, Scrollbar is still visible for
	 * 1-2 Seconds and we are unable to click on the Element due to this
	 * behaviour.So waiting for 2 Seconds before returning the Element
	 */
	if (isSleep) {
	    Thread.sleep(Constants.MEDIUM_DELAY);
	}
	return sgElement;

    }

    public static String getTextBy(String locatorType, String locator)
	    throws Exception {
	SgElement sgElement = SgElement.getSgElement(locatorType, locator);
	return sgElement.getText();
    }

    /**
     * getElements for given locatorType/locator combination. Caution: This
     * gives only those currently visible on screen. To identify single element
     * by auto scroll up and down use other getElement functions in this class.
     * 
     * @param locatorType
     * @param locator
     * @return
     * @throws Exception
     */
    public static List<SgElement> getSgElements(String locatorType,
	    String locator) throws Exception {

	List<WebElement> webElements = null;
	try {
	    Driver driver = Driver.getInstance();
	    switch (locatorType) {
	    case "xpath":
		String newXpath = Common.convertJSONtoString(locator,
			driver.sgCapabilities.getMobilePlatformName());
		if (newXpath == null) {
		    newXpath = locator;
		}
		webElements = driver.appy
			.findElements(MobileBy.xpath(newXpath));

		break;
	    case "id":
		webElements = driver.appy.findElements(MobileBy.id(locator));

		break;
	    case "name":
		webElements = driver.appy.findElements(MobileBy.name(locator));

		break;
	    case "value":
		webElements = driver.appy.findElements(MobileBy.name(locator));

		break;
	    case "tagname":
		webElements = driver.appy.findElements(MobileBy
			.tagName(locator));

		break;
	    case "class":
		String newClass = SgAutoMapper.getMappedClass(locator);
		webElements = driver.appy.findElements(MobileBy
			.className(newClass));
		break;
	    }
	    // For each webElement we found - convert it to SgElement
	    List<SgElement> sgElements = new ArrayList<SgElement>();
	    for (WebElement webEle : webElements) {
		sgElements.add(ConvertWebElementToSgElement(webEle, false,
			locatorType, locator));
	    }

	    return sgElements;
	} catch (Exception e) {
	    SgLog.warn("Received an exception. This is most likely an error/failure of test case"
		    + " unless test case is expecting this exception.");
	    throw e;
	}
    }

    /**
     * Find the element satisfying two conditions.
     * 
     * How this works? First it gets all elements satisfying locator1 and then
     * picks up first element in array satisfying locator2 conditions
     * 
     * @param locatorType1
     *            id, name, class, xpath, tagname
     * @param locator1
     * @param locatorType2
     *            id, name, class, xpath, tagname, nameRegx nameRegx is special
     *            here. It will identify by name but via regular expression
     *            match instead of whole name
     * @param locator2
     * @return
     * @throws Exception
     */
    public static SgElement getSgElementMultiLocator(String locatorType1,
	    String locator1, String locatorType2, String locator2)
	    throws Exception {
	return SgElement.getSgElementMultiLocator(locatorType1, locator1,
		locatorType2, locator2, true);
    }

    public static SgElement getSgElementsMultiLocator(String locatorType1,
	    String locator1, String locatorType2, String locator2, int ind)
	    throws Exception {
	if (locatorType1.equals("nameRegx")) {
	    SgLog.error("LocatorType1 doesn't accept nameRegx. Only locatorType2 accepts this ");
	    throw new StargateException(
		    "LocatorType = nameRegx is supported only for locatorType2 param");
	}
	List<SgElement> sgElements = SgElement.getSgElements(locatorType1,
		locator1);
	String locator2New = initForMultiLocator(locatorType1, locator1,
		locatorType2, locator2);

	SgElement sgElementLocated = null;
	int count = 0;
	for (SgElement sgEle : sgElements) {
	    sgElementLocated = multiLocator(sgEle, locatorType2, locator2New,
		    true);
	    if (sgElementLocated == null) {
		continue;
	    } else {
		if (count == ind)
		    return sgElementLocated;
		count++;
	    }
	}
	// end of for

	throw new NoSuchElementException(
		"Couldn't locate element with given combination of locators"
			+ locatorType1 + locator1 + locator2 + locatorType2);

    }

    /**
     * Find element satisfying two conditions.
     * 
     * @param locatorType1
     *            id, name, xpath, class
     * @param locator1
     * @param locatorType2
     *            id, name, xpath, class, nameRegx
     * @param locator2
     *            Compatibility note: Desktop: second locator2 is always json
     *            with desktop xpath irrespective of whatever locatorType2 value
     *            is. exampple:
     *            "{Android:'PQ-48021(.*)', Desktop:'//*[@id=\"frmdismiss_button1182812896269641\"]'}"
     * 
     * 
     * @param isScroll
     * @return
     * @throws Exception
     */
    public static SgElement getSgElementMultiLocator(String locatorType1,
	    String locator1, String locatorType2, String locator2,
	    boolean isScroll) throws Exception {
	for (ScrollDirection currentDirection : ScrollDirection.UP
		.getDeclaringClass().getEnumConstants()) {
	    int count = 5; // we try ten times in each direction.
	    do {
		try {
		    // Find the element and return it if found.
		    return SgElement.getSgElementMultiLocatorFromVisible(
			    locatorType1, locator1, locatorType2, locator2);
		} catch (Exception e) {
		    SgLog.extraVerbose("Ignoring exception while trying to locate an element in visible area. We will proceed by scrolling further");
		}
		// We don't find it in current visible area, let us scroll
		Gestures.swipe(currentDirection);
		count--;
	    } while (count > 0);
	}
	throw new StargateException(
		"getSgElementMultiLocator couldn't find the requested element.");
    }

    public static SgElement multiLocator(SgElement sgEle, String locatorType2,
	    String locator2New, boolean multiple) throws Exception {
	boolean found = false;
	switch (locatorType2) {
	case "id":
	    if (sgEle.getId().equals(locator2New)) {
		found = true;
	    }
	    break;
	case "value":
	    if (sgEle.getAttribute("value").equals(locator2New)) {
		found = true;
	    }
	    break;
	case "name":
	    String currentText = sgEle.getText();
	    // Removing two or more consecutive spaces in IOs and
	    // considering them as single space because that is how Kony
	    // apps is
	    // behaving in IOS.
	    SgLog.extraVerbose("Current text is : " + currentText);
	    if (currentText.equals(locator2New)) {
		found = true;
	    }
	    break;
	case "nameRegx":
	    String currentTextforRegx = sgEle.getText();
	    if (currentTextforRegx.matches(locator2New)) {
		found = true;
	    }
	    break;
	case "tagname":
	    if (sgEle.getTagName().equals(locator2New)) {
		found = true;
	    }
	    break;
	case "class":
	    String newClass = SgAutoMapper.getMappedClass(locator2New);
	    if (sgEle.getAttribute("class").equals(newClass)) {
		found = true;
	    }
	    break;
	}
	if (found == true) {
	    if (multiple == false) {
		if (sgEle.getLocation().y >= 0) {
		    return sgEle;
		} else {
		    return null;
		}
	    } else {
		return sgEle;
	    }
	}
	return null;
    }

    public static String initForMultiLocator(String locatorType1,
	    String locator1, String locatorType2, String locator2)
	    throws Exception {
	String locator2CurrentPlatform = Common.convertJSONtoString(locator2,
		Driver.getInstance().sgCapabilities.getMobilePlatformName());
	String locator2New = null;
	if (locator2CurrentPlatform == null) {
	    locator2New = Common.convertJSONtoString(locator2, "NATIVE");
	    if (locator2New == null) {
		locator2New = locator2;
	    }
	} else {
	    // JSON contains Android/iOS
	    locator2New = locator2CurrentPlatform;
	}
	return locator2New;
    }

    public static SgElement getSgElementMultiLocatorFromVisible(
	    String locatorType1, String locator1, String locatorType2,
	    String locator2) throws Exception {
	if (locatorType1.equals("nameRegx")) {
	    throw new StargateException(
		    "LocatorType = nameRegx is supported only for locatorType2 param");
	}

	List<SgElement> sgElements = SgElement.getSgElements(locatorType1,
		locator1);
	String locator2New = initForMultiLocator(locatorType1, locator1,
		locatorType2, locator2);
	SgElement sgElementLocated = null;
	for (SgElement sgEle : sgElements) {
	    sgElementLocated = multiLocator(sgEle, locatorType2, locator2New,
		    false);
	    if (sgElementLocated == null) {
		continue;
	    } else {
		return sgElementLocated;
	    }
	} // end of for

	throw new NoSuchElementException(
		"Couldn't locate element with given combination of locators"
			+ locatorType1 + locator1 + locator2 + locatorType2);
    }

    public boolean isElementVisible() throws Exception {
	Dimension resolution = Driver.getScreenResolution();
	Point location = getLocation();

	if (location.x == 0 && location.y == 0) {
	    SgLog.warn("location is returned as 0,0. "
		    + "If the element is really at 0,0 top left corner then good. "
		    + "Otheriwse this may be due to a bug in either Appium server or xcode");
	}
	if ((location.x >= resolution.width || location.x < 0)) {
	    return false;
	}

	if ((location.y >= resolution.height || location.y < 0)) {
	    return false;
	}
	return true;
    }

    public static boolean isElementVisible(String locatorType, String locator) {
	try {
	    SgElement sgElement = SgElement.getSgElement(locatorType, locator,
		    false);
	    // on some platforms we are able to get sgElement even though it is
	    // currently not in visible portion. let us get position and
	    // validate it falls under screen resolution
	    return sgElement.isElementVisible();
	} catch (Exception e) {
	    return false;
	}
    }

    public String commonGetText(boolean isTextBoxOrArea) {

	if (!isTextBoxOrArea) {
	    return super.getText();
	} else {
	    String text = super.getText();
	    // If its a textArea or TextBox, we look whether the
	    // returned(getText) contains Double Tap to Edit or Editing.
	    // Then
	    // we'll get the index of second last dot and return a string
	    // from
	    // index 0 to secondLastDot.index-1
	    if (text.contains(". Double tap to edit.")
		    || text.contains(". Editing.")) {
		int dotCount = 0;
		int i = text.length();
		for (i = text.length() - 1; i >= 0; i--) {
		    if (text.charAt(i) == '.') {
			dotCount++;
			if (dotCount == 2) {
			    break;
			}
		    }
		}
		text = text.substring(0, i);
	    }
	    return text;
	}

    }

    public String getText() {
	return commonGetText(false);
    }

    public String getText(boolean isTextBoxOrArea) {
	return commonGetText(isTextBoxOrArea);
    }

    public boolean isChecked() {
	if (this.getAttribute("checked").toUpperCase().equals("TRUE")) {
	    return true;
	}
	return false;
    }

    /**
     * Take screenshot of only this element and compare with baseline image
     * 
     * @param string
     */
    public void takeScreenshotAndCompare(String imageName) throws Exception {
	boolean isComparisonInBothOrientations = false;
	isComparisonInBothOrientations = SgConfig.getInstance()
		.isComparisonInBothOrientations();
	takeScreenshotAndCompare(imageName, isComparisonInBothOrientations);
    }

    /**
     * Take screenshot of only this element and compare with baseline image.
     * isComparisonInBothOrientations if true then takeScreenshotAndCompare will
     * be taken in current orientation,then orientation will be changed and
     * takes screenshot and compares.
     * 
     * @param imageName
     * @param isComparisonInBothOrientations
     * @throws Exception
     */
    public void takeScreenshotAndCompare(String imageName,
	    boolean isComparisonInBothOrientations) throws Exception {
	String orientation = Driver.getInstance().getOrientation();
	// taking screenshot and comparing in current orientation.
	takeScreenshotAndCompare(imageName, orientation);
	if (isComparisonInBothOrientations) {
	    // Now let us change orientation and perform screenshot and
	    // compare again.
	    if (orientation.equalsIgnoreCase("portrait")) {
		Gestures.setOrientation("landscape", true);
		takeScreenshotAndCompare(imageName, "landscape");
		// reverting the orientation to previous one.
		Gestures.setOrientation("portrait", true);
	    } else if (orientation.equalsIgnoreCase("landscape")) {
		Gestures.setOrientation("portrait", true);
		takeScreenshotAndCompare(imageName, "portrait");
		Gestures.setOrientation("landscape", true);
	    }
	}
    }

    /**
     * Take screenshot of only this element and compare with baseline image.
     * according to orientation parameters are called.
     * 
     * @param imageName
     * @param orientation
     * @throws Exception
     */

    public void takeScreenshotAndCompare(String imageName, String orientation)
	    throws Exception {

	/*
	 * How this works? Get size of element, get location and figure out
	 * exact four corners followed by take screenshot of that area
	 */
	Point location = this.getLocation();
	Dimension size = this.getSize();
	Driver driver = Driver.getInstance();
	Dimension resolution = Driver.getScreenResolution();
	if (orientation.equalsIgnoreCase("PORTRAIT")) {
	    this.getDimensions(orientation, imageName, location, size,
		    resolution.width, resolution.height,
		    driver.sgCapabilities.screenshotFullImageWidth,
		    driver.sgCapabilities.screenshotFullImageHeight);
	} else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
	    this.getDimensions(orientation, imageName, location, size,
		    resolution.height, resolution.width,
		    driver.sgCapabilities.screenshotFullImageWidth,
		    driver.sgCapabilities.screenshotFullImageHeight);
	}
    }

    public void getDimensions(String Orientation, String imageName,
	    Point location, Dimension size, int resolutionWidth,
	    int resolutionHeight, int imageWidth, int imageHeight)
	    throws Exception {
	int startX = 0, startY = 0, endX = 0, endY = 0, sizeWidth, sizeHeight, locationX, locationY;
	if (resolutionWidth != imageWidth) {
	    // The image size and location are given as per screenResolution
	    // But our imagecrop works with actual image size
	    // If they are one and same not an issue, if they are not
	    // then we need to change location and size as per actual image
	    // size.
	    sizeWidth = size.width * imageWidth / resolutionWidth;
	    locationX = location.x * imageWidth / resolutionWidth;
	} else {
	    sizeWidth = size.width;
	    locationX = location.x;
	}
	if (resolutionHeight != imageHeight) {
	    sizeHeight = size.height * imageHeight / resolutionHeight;
	    locationY = location.y * imageHeight / resolutionHeight;
	} else {
	    sizeHeight = size.height;
	    locationY = location.y;
	}

	startX = locationX;
	startY = locationY;

	if (Orientation.equalsIgnoreCase("PORTRAIT")) {
	    endX = imageWidth - sizeWidth - startX;
	    endY = imageHeight - sizeHeight - startY;
	} else if (Orientation.equalsIgnoreCase("LANDSCAPE")) {
	    endX = imageHeight - sizeWidth - startX;
	    endY = imageWidth - sizeHeight - startY;
	}
	if (Orientation.equalsIgnoreCase("PORTRAIT")) {
	    ScreenshotUtil.takeScreenshotAndCompare(imageName, startX, startY,
		    endX, endY);
	} else if (Orientation.equalsIgnoreCase("LANDSCAPE")) {
	    ScreenshotUtil.takeScreenshotAndCompare(imageName, startY, endX,
		    endY, startX);
	}
    }

    /**
     * This will try to keep the element at the center. For most of the cases it
     * will indeed keep the element at center. But if element is on top of form
     * then we can not keep it at center. Use this function before calling
     * ScreenshotUtil.takeScreenshotandCompare - this will avoid taking
     * screenshots at random positions. If you are using
     * element.takeScreenShotandCompare then this function may not be required
     * for you.
     */
    /**
     * Try to keep element to center of screen
     * 
     * @param isHorizontal
     *            true or false. True --> try to keep horizontal. False ignore
     *            horizontal
     * @param isVertical
     *            true or false. True --> try to keep vertical center. False
     *            ignore vertical
     * @param forced
     *            true or false. True --> forced tryKeepAtCenter using other
     *            private Function tryKeepAtCenterVerticalAndroid. False uses
     *            the original function. Use false if the element can't actually
     *            come to center and you just want to try only once. It will
     *            save time.
     * @throws Exception
     */
    public void tryKeepAtCenter(boolean isHorizontal, boolean isVertical,
	    boolean forced) throws Exception {

	if (isHorizontal == false && isVertical == false) {
	    return; // if nothing to do then return here itself.
	}

	/*
	 * How this works? Get Screen Resolution and in turn height and width of
	 * current screen. Get Current position of the element. Try to move the
	 * element to center.
	 */
	int startx, starty, endx, endy;
	int EPSILON = 40; // 40 pixels.
	Dimension resolution = Driver.getScreenResolution();
	Point centerPoint = this.getCenter();
	// Keep horizontal center
	if (isHorizontal) {
	    starty = 100;
	    endy = 100;
	    startx = centerPoint.x;
	    endx = resolution.width / 2;
	    // Boundary condition check.
	    if (startx > resolution.width) {
		int overflow = startx - resolution.width;
		startx = resolution.width - overflow;
		endx = endx - overflow;
	    }
	    if (((endx - startx) > 0) && (endx - startx) < EPSILON) {
		SgLog.info("Element is almost at center. If we swipe now it will click the element. Thus not swiping ");
	    } else {
		Gestures.swipe(startx, starty, endx, endy);
	    }
	}
	// Keep vertical center
	if (isVertical) {
	    if (forced) {
		tryKeepAtCenterVerticalForAndroid();
		Thread.sleep(Constants.SHORT_DELAY);
		return;
	    }
	    startx = 100;
	    endx = 100;
	    starty = centerPoint.y;
	    endy = resolution.height / 2;
	    // Boundary condition check.
	    if (starty > resolution.height) {
		int overflow = starty - resolution.height;
		starty = resolution.height - overflow;
		endy = endy - overflow;
	    }
	    if (((endy - starty) > 0) && (endy - starty) < EPSILON) {
		SgLog.info("Element is almost at center. If we swipe now it will click the element. Thus not swiping ");
	    } else {
		Gestures.swipe(startx, starty, endx, endy);
	    }
	}

	// without this delay some times we are seeing vertical in swipe line.
	Thread.sleep(Constants.SHORT_DELAY);
    }

    private void tryKeepAtCenterVerticalForAndroid() throws Exception {
	Dimension resolution = Driver.getScreenResolution();
	Point centerOfScreen = new Point(resolution.width / 2,
		resolution.height / 2);
	Point elementCenter = this.getCenter();
	// try first swiping directly
	Gestures.swipe(elementCenter.x, elementCenter.y, elementCenter.x,
		centerOfScreen.y, 2000);
	for (int i = 0; i < 7; i++) {
	    // checking if the element center is within the boundry of +- 1
	    // pixels from Screen center
	    elementCenter = this.getCenter();
	    if ((elementCenter.y > (centerOfScreen.y - 1))
		    && (elementCenter.y < centerOfScreen.y + 1))
		break;
	    // if elementCenter is greater, we move it above center and swipe
	    // again.
	    Dimension sizeOfElement = this.getSize();
	    if ((elementCenter.y > centerOfScreen.y)) {
		int newVertivalLocation = elementCenter.y
			- (sizeOfElement.height / 2) - 50;
		if (newVertivalLocation > SgConfig.getInstance()
			.getImageCropStartY()) {
		    Gestures.swipe(elementCenter.x, elementCenter.y,
			    elementCenter.x, newVertivalLocation, 2000);
		}
		// just to avoid the unnecessary swipe if the location is
		// reached within limits we perform following check
		elementCenter = this.getCenter();
		if ((elementCenter.y > (centerOfScreen.y - 1))
			&& (elementCenter.y < centerOfScreen.y + 1))
		    break;
	    } else {
		// if elementCenter is above center, we swipe it +50 to bottom
		// of center.
		int newVertivalLocation = elementCenter.y
			+ (sizeOfElement.height / 2) + 50;
		if (newVertivalLocation < resolution.height) {
		    Gestures.swipe(elementCenter.x, elementCenter.y,
			    elementCenter.x, newVertivalLocation, 2000);
		}
		elementCenter = this.getCenter();
		if ((elementCenter.y > (centerOfScreen.y - 1))
			&& (elementCenter.y < centerOfScreen.y + 1))
		    break;
	    }
	    elementCenter = this.getCenter();
	    Dimension size = this.getSize();
	    if ((centerOfScreen.y < elementCenter.y)
		    && ((elementCenter.y - centerOfScreen.y) > (size.height / 2))) {
		Gestures.swipe(elementCenter.x, elementCenter.y,
			elementCenter.x, centerOfScreen.y, 2000);
	    } else if ((centerOfScreen.y > elementCenter.y)
		    && ((centerOfScreen.y - elementCenter.y) > (size.height / 2))) {
		Gestures.swipe(elementCenter.x, elementCenter.y,
			elementCenter.x, centerOfScreen.y, 2000);
	    }
	}
    }

    /**
     * For keeping the element at center of screen.
     * 
     * @throws Exception
     */
    public void tryKeepAtCenter() throws Exception {
	tryKeepAtCenter(false, true);
    }

    /**
     * For keeping the element at center of Screen.
     * 
     * @param horizontal
     *            true or false , true sets horizontal swipe true.
     * @param vertical
     *            true or false , true sets vertical swipe true.
     * @throws Exception
     */
    public void tryKeepAtCenter(boolean horizontal, boolean vertical)
	    throws Exception {
	boolean forced = false;
	tryKeepAtCenter(horizontal, vertical, forced);
    }

    /**
     * Use the forced parameter as false when you are sure that the element
     * can't be bought to center but you just want to fix location for
     * Screenshot. It will help save time by avoiding forcing 7 times trying to
     * keep at center.
     * 
     * @param forced
     * @throws Exception
     */
    public void tryKeepAtCenter(boolean forced) throws Exception {
	tryKeepAtCenter(false, true, forced);
    }

    /**
     * Press an element by name. note: make sure you call release() after this
     * method. Use sgElement.press() if you have to pressByclass and other
     * requirements.
     * 
     * @param text
     * @throws Exception
     */
    public void press() throws Exception {
	Driver driver = Driver.getInstance();
	TouchAction ta = new TouchAction((AppiumDriver) driver.appy)
		.press(this);
	ta.perform();
    }

    /**
     * Clicks at left top corner of the element Default click() will click at
     * center. Use this if you have a special need.
     * 
     * @throws Exception
     */
    public void clickAtLeftTopCorner() throws Exception {
	Point location = getLocation();
	int x, y;
	x = location.x + 1;
	y = location.y + 1;

	HashMap<String, String> arguments = new HashMap<String, String>();
	arguments.put("tapCount", "1");
	arguments.put("touchCount", "1");
	arguments.put("duration", "0.5");
	arguments.put("x", Integer.toString(x));
	arguments.put("y", Integer.toString(y));
	Driver driver = Driver.getInstance();
	JavascriptExecutor js = (JavascriptExecutor) driver.appy;
	js.executeScript("mobile: tap", arguments);

    }

    /**
     * Moves current element to Top, if possible. Consider using
     * tryMoveToTop(3000) instead of this method. We cannot fix this method due
     * to backward compatibility issues.
     * 
     * @throws Exception
     */
    @Deprecated
    public void tryMoveToTop() throws Exception {
	tryMoveToTop(1200);
    }

    /**
     * tryMovetoTop - use this method with scrollSpeed = 3000 for better
     * results.
     * 
     * @param scrollSpeed
     * @throws Exception
     */
    public void tryMoveToTop(int scrollSpeed) throws Exception {
	SgLog.entry("tryMoveToTop");
	Point firstElementLocation = null;
	int topMostY = SgConfig.getInstance().getImageCropStartY();
	// Getting first element under the WidgetClass whose y coordinate is
	// greater that topMostY
	firstElementLocation = getLocation();
	Dimension resolution = Driver.getScreenResolution();
	// Swiping to bring the first element to top
	if (firstElementLocation.y >= topMostY) {
	    Gestures.swipe(resolution.width / 2, firstElementLocation.y,
		    resolution.width / 2, topMostY, scrollSpeed);
	} else {
	    Gestures.swipe(resolution.width / 2, topMostY,
		    resolution.width / 2, (topMostY - firstElementLocation.y),
		    scrollSpeed);
	}
    }

    /**
     * This move the current element to bottom of the Screen. This is the best
     * method to go with for both Ios and Android as trymoveToTop doesn't behave
     * same for both platforms.Please use this to make it work for both.
     * 
     * @param scrollSpeed
     * @throws Exception
     */
    public void tryMoveToBottom(int scrollSpeed) throws Exception {
	if (this.isElementVisible()) {
	    Point location = this.getLocation();
	    Gestures.swipe(
		    location.x,
		    location.y,
		    location.x,
		    Driver.getScreenResolution().height - this.getSize().height,
		    scrollSpeed);
	} else {
	    this.tryKeepAtCenter();
	    Point location = this.getLocation();
	    Gestures.swipe(
		    location.x,
		    location.y,
		    location.x,
		    Driver.getScreenResolution().height - this.getSize().height,
		    scrollSpeed);
	}

    }

    /**
     * It double taps on an element on a native platform at the given
     * co-ordinates
     * 
     * @param x
     * @param y
     * @throws Exception
     */
    public void doubleTap(int x, int y) throws Exception {
	Driver driver = Driver.getInstance();
	HashMap<String, String> arguments = new HashMap<String, String>();
	arguments.put("tapCount", "2");
	arguments.put("touchCount", "1");
	arguments.put("duration", "0.0");
	arguments.put("x", Integer.toString(x));
	arguments.put("y", Integer.toString(y));
	JavascriptExecutor js = (JavascriptExecutor) driver.appy;
	js.executeScript("mobile: tap", arguments);
	js.executeScript("mobile: tap", arguments);

    }

    /**
     * Verifies whether the password text is displayed as expected or not
     * 
     * @param textBoxElement
     * @param passwordText
     * @throws Exception
     */
    public void verifyPassword(String passwordText) throws Exception {
	if (passwordText.equalsIgnoreCase(this.getText())
		|| (passwordText.equalsIgnoreCase(""))) {
	    throw new StargateException("Password text is not as expected!");
	}
    }

    /**
     * This is an overrided function for getLocation() in Remote webElement.
     */
    public Point getLocation() {
	Point location = super.getLocation();

	return location;
    }

}