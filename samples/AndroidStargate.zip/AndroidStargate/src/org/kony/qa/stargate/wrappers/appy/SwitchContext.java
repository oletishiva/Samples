package org.kony.qa.stargate.wrappers.appy;

/**
 * @author SPA_Web_QA_team
 * adopted as per requirements of Stargate
 * This class is useful in switching context when working on SPA automation
 */
import io.appium.java_client.android.AndroidDriver;

import java.util.Set;

public class SwitchContext {
    public enum Context {
	NATIVE(0), WEB(1);
	private int value;

	private Context(int value) {
	    this.value = value;
	}

	public int getValue() {
	    return this.value;
	}
    };

    public static void switchToNativeContext() {
	switchContext(Context.NATIVE);
    }

    public static void switchToWebViewContext() {
	Driver driver = null;
	try {
	    driver = Driver.getInstance();
	    if (((AndroidDriver) driver.appy).getContext().equals("NATIVE_APP")) {
		switchContext(Context.WEB);
	    }

	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    private static void switchContext(Context context) {
	try {
	    Driver driver = Driver.getInstance();
	    Set<String> contextNames = ((AndroidDriver) driver.appy)
		    .getContextHandles();
	    ((AndroidDriver) driver.appy).context((String) contextNames
		    .toArray()[context.getValue()]);

	} catch (Exception e) {
	    System.out.println(e.getMessage());
	}
    }

}
