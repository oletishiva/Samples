package org.kony.qa.stargate.wrappers.appy;

import org.kony.qa.stargate.common.SgConfig;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * A listener to relaunch driver if there are successive failures.
 * 
 * @author Kiran.Chava
 *
 */
public class SgReInitDriverListener implements ITestListener {

    private int successiveFailCount = 0;
    private boolean unsetForce = false;

    @Override
    public void onTestStart(ITestResult result) {

    }

    private void handleUnsetForce() {
	if (unsetForce) {
	    try {
		SgConfig sgConfig = SgConfig.getInstance();
		sgConfig.setForce(false);
		unsetForce = false;
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
    }

    private void handleNotAPass() {
	handleUnsetForce();
	try {
	    SgConfig sgConfig = SgConfig.getInstance();
	    if (sgConfig.getResetSuccessiveFailCount() == 0) {
		return; // Nothing to do, if zero.
	    }
	    successiveFailCount++;
	    if (successiveFailCount >= sgConfig.getResetSuccessiveFailCount()) {
		successiveFailCount = 0;
		// we exceeded number of consecutive failures.
		// Let us make sure next test run will re-init appium driver.
		if (sgConfig.isForce()) {
		    // force is already set, nothing to do.
		} else {
		    // Set force, and remember to unset it in next test run
		    sgConfig.setForce(true);
		    unsetForce = true;
		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}

    }

    @Override
    public void onTestSuccess(ITestResult result) {
	// If there is a pass, then reset fail counter
	successiveFailCount = 0;
	handleUnsetForce();
    }

    @Override
    public void onTestFailure(ITestResult result) {
	handleNotAPass();

    }

    @Override
    public void onTestSkipped(ITestResult result) {
	handleNotAPass();

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	handleNotAPass();

    }

    @Override
    public void onStart(ITestContext context) {
	handleNotAPass();
    }

    @Override
    public void onFinish(ITestContext context) {
	// Nothing for now.
    }

}
