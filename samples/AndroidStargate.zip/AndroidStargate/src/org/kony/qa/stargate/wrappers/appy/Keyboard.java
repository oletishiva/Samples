/**
 * 
 */
package org.kony.qa.stargate.wrappers.appy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidKeyCode;

import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

/**
 * @author Kiran.Chava
 * 
 */
public class Keyboard {
    public static void sendKeyEvent(Integer code) throws Exception {

	try {
	    Driver driver = Driver.getInstance();
	    ((AppiumDriver) driver.appy).sendKeyEvent(code);
	} catch (Exception e) {
	    throw e;
	}
    }

    public static void sendKeysByXpath(String xpath, String text)
	    throws Exception {
	typeText("xpath", xpath, text);
    }

    public static void sendKeysByName(String name, String text)
	    throws Exception {
	typeText("name", name, text);
    }

    public static void sendKeysByValue(String name, String text)
	    throws Exception {
	typeText("value", name, text);
    }

    public static void sendKeysByClass(String className, String text)
	    throws Exception {
	typeText("class", className, text);
    }

    /**
     * Type given text.
     * 
     * @param locatorType
     * @param locator
     * @param text
     * @throws Exception
     */
    public static void typeText(String locatorType, String locator, String text)
	    throws Exception {
	SgElement sgElement = SgElement.getSgElement(locatorType, locator);
	sgElement.sendKeys(text);
    }

    /**
     * convenient function for pressing enter.
     * 
     * @throws Exception
     */
    public static void pressEnter() throws Exception {
	Keyboard.sendSplKey("ENTER");
    }

    /**
     * Convenient function for pressing escape.
     * 
     * @throws Exception
     */
    public static void pressEscape() throws Exception {
	Keyboard.sendSplKey("ESCAPE");
    }

    /**
     * Enter special key.
     * 
     * @param key
     * @throws Exception
     */
    public static void sendSplKey(String key) throws Exception {
	try {
	    if (key.equalsIgnoreCase("ENTER")) {
		sendKeyEvent(AndroidKeyCode.ENTER);
	    } else if (key.equalsIgnoreCase("ESCAPE")) {
		sendKeyEvent(AndroidKeyCode.BACK);
	    } else if (key.equalsIgnoreCase("NEXT")
		    || key.equalsIgnoreCase("DONE")) {
		sendKeyEvent(16);
	    }
	} catch (Exception e) {

	}

    }

    /**
     * To Hover on to the particular element.
     * 
     * @param element
     * @throws Exception
     */
    public static void moveAndHover(SgElement element) throws Exception {
	Driver driver = Driver.getInstance();
	Actions action = new Actions(driver.appy);
	action.moveToElement(element);
	action.perform();
    }

    /**
     * This function checks for the text on popUp and clicks on OK Button only
     * if the text does not match and we have to fail the testcase.
     * 
     * @param text
     * @param OKButton
     * @return
     * @throws Exception
     */
    public static boolean assertPopUpText(String text, String OKButton)
	    throws Exception {
	String popUpText = Gestures.getPopUpText();
	if (!popUpText.trim().equalsIgnoreCase(text.trim())) {
	    Gestures.clickOnPopUp(OKButton);
	    Assert.fail("The popUp text are not same !!");
	} else {
	    return true;
	}
	return false;
    }

}
