/**
 *  Copyright (C) 2014 Kony, Inc. 
 *  Package appy 
 *  Platform QA Kony wrapper for Appium
 */
package org.kony.qa.stargate.wrappers.appy;

import java.io.FileInputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.kony.qa.stargate.common.Constants;
import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.common.SgConstants;
import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.helpers.Common;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

/*
 * ChangeLog: 
 * Aug 16th 2014: Kiran.Chava : Implemented support for 
 * multiple driver instances in a single test case
 */
/**
 * Driver class: This is starting point and only point to access Appium from
 * test cases. How this works? Test case will call Driver.init(capabilities)
 * This will complete all the initialization of this singleton class. When any
 * wrapper class needs make appium class it class first Driver.getInstance() and
 * then makes call driver.appy.Click();
 * 
 * @author KH1409
 * 
 */
public class Driver {
	// this appy is protected.
	// Only wrapper classes can access this.
	// Test cases have to call wrapper class methods to reach appium.
	// This protection is required to make framework more scalable/portable
	protected WebDriver appy;
	private static Driver driver = null;
	private static HashMap<String, Driver> multiDrivers = new HashMap<String, Driver>();
	private static Object mutex = new Object();
	private static HashMap<String, Object> multiMutexes = new HashMap<String, Object>();
	public SgCapabilities sgCapabilities = null;
	// the below value default is taken as per lab device
	protected static double dpr = 1.5;

	public static double getDpr() {
		return dpr;
	}

	// Private constructor only init() can call this.
	// do not call this from getInstance()
	// getInstance assumes init is already called. If not it must throw
	private Driver(SgCapabilities sgCapabilities) throws Exception {

		// Let us store sgCapabilities received in driver instance.
		// This will enable us to make calls like driver.sgCapabilities.isSPA()
		// from
		// both test cases and geusters and other appy wrapper functions.
		this.sgCapabilities = sgCapabilities;
		// We need to pass desiredCapabilities to AppiumDriver.
		// Let us get desiredCapabilities from capabilities instance.
		DesiredCapabilities desiredCapabilities = sgCapabilities.getDesiredCapabilities();
		SgConfig sgConfig = SgConfig.getInstance();
		String urlOfAppiumServer = sgConfig.getUrl();
		appy = new AndroidDriver(new URL(urlOfAppiumServer), desiredCapabilities);

	}

	/**
	 * init a driver and associate it with key. This is required only if your
	 * tests need multiple drivers. For single driver use initi(SgCapabilities)
	 * 
	 * @param sgCapabilities
	 * @param key
	 * @throws Exception
	 */
	public static void init(SgCapabilities sgCapabilities, String key) throws Exception {
		if (key == null) {
			// Default driver. Not a multi driver
			if (driver != null) {
				if (driver.sgCapabilities.isReInitRequired(sgCapabilities) == false) {
					return;
				} else {
					try {
						driver.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			// Make this threadsafe.
			synchronized (mutex) {
				driver = new Driver(sgCapabilities);
			}
		} else {
			// Multi driver
			if (multiDrivers.get(key) != null) {
				if (multiDrivers.get(key).sgCapabilities.isReInitRequired(sgCapabilities) == false) {
					return;
				} else {
					driver.close();
				}
			}
			// Make this threadsafe.
			Object tmpMutext = multiMutexes.get(key);
			if (tmpMutext == null) {
				tmpMutext = new Object();
			}
			synchronized (multiMutexes.get(key)) {
				multiDrivers.put(key, new Driver(sgCapabilities));
			}
		}

	}

	/**
	 * get the 'default' instance of Driver currently active for this test case.
	 * If you are using multiple instances of Driver for your tests call
	 * getInstnace(key)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Driver getInstance() throws Exception {
		return getInstance(null);
	}

	/**
	 * Get instance of Driver Associated with key. This is needed only if your
	 * tests require multiple drivers. For single driver tests use getInstnace()
	 * 
	 * @param key
	 * @return
	 * @throws Exception
	 */

	public static Driver getInstance(String key) throws Exception {
		if (key == null) {
			// Default driver case
			if (driver == null) {
				throw new StargateException("Driver.getInstance() is called before calling Driver.init()");
			}
			return driver;
		} else {
			// Multi driver case.
			if (multiDrivers.get(key) == null) {
				String errorMessage = "Driver.getInstance(key) is called before calling "
						+ "Driver.init(SgCapabilities, key) for key : " + key;
				throw new StargateException(errorMessage);
			}
			return multiDrivers.get(key);
		}
	}

	public static boolean isDriverInitialized() throws Exception {
		return Driver.isDriverInitialized(null);
	}

	public static boolean isDriverInitialized(String key) throws Exception {
		if (key == null) {
			// Default driver case
			if (driver == null) {
				return false; // driver is NOT initialized.
			}
			return true; // driver is initialized.
		} else {
			// Multi driver case.
			if (multiDrivers.get(key) == null) {
				return false;
			}
			return true;
		}
	}

	/**
	 * builds and returns app URL from browserUrl of properties file and appName
	 * from sgcapabilities. By default this is used for both SPA and Desktop
	 * testing
	 * 
	 * @param url
	 * @param appName
	 * @return
	 * @throws Exception
	 */
	public static String getAppUrl(String url, String appName) throws Exception {
		if (url == null) {
			url = SgConfig.getInstance().getBrowserUrl();
		}
		// browserURL in properties file will be of the form
		// http://192.168.1.101:8888
		// We need to make it to something like
		// http://192.168.1.101:8888/dummyApp/p
		if (SgConfig.getInstance().getIsFullURL()) {
			return url;
		}
		if (!url.endsWith("/")) {
			url += "/";
		}
		// if appname is given like relativeDirectory/appName remove
		// relative path.

		String lastword = "p";
		url = url + appName.substring(appName.lastIndexOf("/") + 1) + "/" + lastword;
		return url;
	}

	/**
	 * This is the heart of Driver class. This must be the first one to call to
	 * access anything in driver class. As this is important to understand how
	 * to use Driver, init, getInstance, appy bear with me for belwo verbose
	 * comments. == User Scenario: Automating Single test case == If we are
	 * automating one test case. Well and good. One test class, one test method.
	 * In that test method in beforetest method (if you are using testNG) call
	 * Driver.init(sgCapabilities) (note: see SgCapabilities class for more
	 * info) This SgCapabily from test by skipping wrapper classes. If you need
	 * any functionality not covered in current wrapper classes, write another
	 * new method or class in wrapper package. == User Scenario: Automating Two
	 * test cases of same mobile application == Call Driver.init(Sgcapabilities)
	 * in beforeMethod of test case 1 and complete test case 1. Now again make
	 * sure you call Driver.init(SgCapabilities) in test case 2 also! init will
	 * check capabilities and make a decision to re-initialize appiumdriver or
	 * not. If test case 2 SgCapabilities are same as currently activer
	 * driver.SgCapabilities - then init won't reinitialize ities contains apk
	 * name (or regsuite or mobile application) we are actually going to test.
	 * Then you can proceed to make calls to other appy wrapper classes. for
	 * example Gestures.clickByName() You must never access appium directl *
	 * driver. Simply returns. Your next Driver.getInstance() will return you
	 * same driver. -- This enables us to run test case 1 and test case 2 in any
	 * order. This keeps each test case virtually independant. This also takes
	 * care of not initializing AppiumDriver unnecessarily. Thus not penalizing
	 * performance for test case independence.
	 * 
	 * == User Scenario: Automating two test cases of different mobile
	 * applications == Call Driver.init(SgCapabilities) in test case 1
	 * (SgCapabilities contains apk name) Complete test case 1. -- Now in test
	 * case 2 call Driver.init(SgCapabilities) with new apk name in
	 * SgCapabilities. init will see that our currently active
	 * driver.sgCapabilities and new sgCapabilities are not same and closes (or
	 * tearDown's) - currently active driver and creates new driver. -- This
	 * design will ensure test cases are completely indepenant and can run in
	 * any order any time.
	 * 
	 * @return void.
	 * @param sgCapabilities
	 *            SgCapabilities instance with all capabilities filled.
	 * 
	 */
	public static void init(SgCapabilities sgCapabilities) throws Exception {
		init(sgCapabilities, null);
	}

	/**
	 * Close the current driver instance.
	 * 
	 * @throws Exception
	 */
	public void close() throws Exception {
		((AppiumDriver) Driver.getInstance().appy).closeApp();
		System.out.println("clicking home");
		// ((AppiumDriver)
		// Driver.getInstance().appy).sendKeyEvent(AndroidKeyCode.HOME);
		if (null != driver.getAppy()) {
			System.out.println("sleeping..");
			// Thread.sleep(10000);
			System.out.println("killing driver");
			driver.getAppy().quit();
		}
		System.out.println("in driver.close(): uninstalling app");
		Common.executeCommand(false, "adb uninstall " + driver.sgCapabilities.getPackageName());
	}

	/**
	 * Use this to Launch your application in the emulator/device at any point
	 * of time during your execution.
	 * 
	 * @throws Exception
	 */
	public void launchApp() throws Exception {
		((AppiumDriver) this.appy).launchApp();
	}

	/**
	 * Use this to close your application in the emulator/device at any point of
	 * time during your execution.
	 * 
	 * @throws Exception
	 */
	public void closeApp() throws Exception {
		((AppiumDriver) this.appy).closeApp();
	}

	public static Dimension getScreenResolution(Driver driver) throws Exception {
		Dimension dimension = driver.getAppy().manage().window().getSize();
		return dimension;
	}

	/**
	 * Returns screen resolution of current device/emulator.
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Dimension getScreenResolution() throws Exception {
		try {
			return getScreenResolution(driver);
		} catch (Exception e) {
			Properties properties = new Properties();
			FileInputStream fileInputStream = new FileInputStream(SgConstants.sgConfigPropertiesFileName);
			properties.load(fileInputStream);
			Dimension dimensionFromProperties = new Dimension(Integer.parseInt((String) properties.get("screenWidth")),
					Integer.parseInt((String) properties.get("screenHeight")));
			return dimensionFromProperties;
		}
	}

	void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				boolean isWebPageLoaded = false;
				if (((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete")) {
					if (driver.getTitle().length() != 0) {
						isWebPageLoaded = true;
					} else {
						isWebPageLoaded = false;
					}
				}
				return isWebPageLoaded;
			}
		};
		org.openqa.selenium.support.ui.Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(50, TimeUnit.SECONDS).pollingEvery(2, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);
		wait.until(pageLoadCondition);
	}

	/**
	 * Restarts the app on tester's request
	 * 
	 * @return void
	 * @throws Exception
	 */
	public static void restart() throws Exception {
		boolean isForceTrue = false;
		Driver driver = Driver.getInstance();
		SgCapabilities sgCapabilitiesBackup = driver.sgCapabilities;
		if (!sgCapabilitiesBackup.isForce()) {
			isForceTrue = true;
			sgCapabilitiesBackup.setForce(true);
		}
		Driver.init(sgCapabilitiesBackup);
		if (isForceTrue) {
			sgCapabilitiesBackup.setForce(false);
		}
	}

	/**
	 * We realunch the app without uninstalling it. We just exit the app and
	 * relaunch again.
	 * 
	 * @throws Exception
	 */
	public static void relaunchApp() throws Exception {
		String command = "adb shell am force-stop " + Driver.getInstance().sgCapabilities.getPackageName();
		Common.executeCommand(false, command);
		// relaunch the app
		Thread.sleep(Constants.LONG_DELAY);
		command = "adb shell am start -n " + Driver.getInstance().sgCapabilities.getPackageName() + "/"
				+ Driver.getInstance().sgCapabilities.getActivityName();
		Common.executeCommand(false, command);
	}

	/**
	 * This coomand can be used to kill the app and exit from same.
	 * 
	 * @throws Exception
	 */
	public static void exitTheApp() throws Exception {
		String command = "adb shell am force-stop " + Driver.getInstance().sgCapabilities.getPackageName();
		Common.executeCommand(false, command);
	}

	/*
	 * returns number of active windows for desktop
	 */
	public static int activeBrowserInstances() throws Exception {
		Driver driver = Driver.getInstance();
		Set<String> handles = driver.appy.getWindowHandles();
		int size = handles.size();
		return size;
	}

	public String getOrientation() throws Exception {
		// returns the orientation of display portrait or landscape
		try {

			String orientation = ((AppiumDriver) this.appy).getOrientation().value();
			return orientation;
		} catch (Exception e) {
			SwitchContext.switchToWebViewContext();
			return "PORTRAIT";
		}
	}

	/**
	 * this function refers to Display Pixel Ratio, used for mapping the display
	 * independent pixels to physical pixels. If needed to verify the return
	 * value, please open the given URL in your device browser:
	 * www.devicepixelratio.com
	 * 
	 * @return
	 * @throws Exception
	 */
	public double getDPR() throws Exception {
		try {
			return getDPR();
		} catch (Exception e) {
			return SgConfig.getInstance().getDevicePixelRatio();
		}
	}

	public WebDriver getAppy() {
		return appy;
	}
} // end of Driver class.