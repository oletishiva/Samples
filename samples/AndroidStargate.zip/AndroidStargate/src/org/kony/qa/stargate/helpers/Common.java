/**
 * 
 */
package org.kony.qa.stargate.helpers;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ProcessBuilder.Redirect;
import java.util.Arrays;

import net.sf.json.JSONObject;

import org.kony.qa.stargate.common.Constants;
import org.kony.qa.stargate.logger.SgLog;
import org.kony.qa.stargate.wrappers.appy.Driver;

/**
 * @author KH1409
 * 
 */
public class Common {

    public static void takeScreenshot(File filepath) throws Exception {
	executeCommand(false,
		"adb shell /system/bin/screencap -p /sdcard/a.png");
	executeCommand(false, "adb pull /sdcard/a.png " + filepath.toString());
	return;
    }

    public static void tryClickIOSDone() {

    }

    /**
     * Helps to Copy a file from the given path of Device.
     * 
     * @param path
     *            - path of the the file in device to be copied to System.
     * @return - Path to Actual Directory
     * @throws Exception
     */

    public static String copyFromDevice(String path) throws Exception {
	Driver driver = Driver.getInstance();
	// The copied file will go to Actual Image Directory , and the name of
	// the
	// file will remain Same
	String actual = driver.sgCapabilities.getActualImageDirectory();
	executeCommand(false, "adb pull" + path + actual);
	return actual;
    }

    private static <T> T[] concat(T[] first, T[] second) {
	T[] result = Arrays.copyOf(first, first.length + second.length);
	System.arraycopy(second, 0, result, first.length, second.length);
	return result;
    }

    public static void executeCommand(Boolean waitFor, String... command) {
	String[] winCmd = { "cmd", "/c" };
	String[] fullCommand = concat(winCmd, command);
	ProcessBuilder pb = new ProcessBuilder(fullCommand);
	File log = new File("log");
	pb.redirectErrorStream(true);
	pb.redirectOutput(Redirect.appendTo(log));
	try {
	    Process p = pb.start();
	    if (waitFor) {
		p.waitFor();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    /**
     * sends the command to console, executes it and returns the output from
     * console
     * 
     * @param command
     * @return
     * @throws Exception
     */
    public static String executeCommandWithConsoleOPReturn(String command)
	    throws Exception {

	Process proc = Runtime.getRuntime().exec(command);
	// Read the output
	String consoleOut = "";
	String errorOut = "";
	BufferedReader reader = new BufferedReader(new InputStreamReader(
		proc.getInputStream()));
	BufferedReader stdError = new BufferedReader(new InputStreamReader(
		proc.getErrorStream()));
	String line = "";
	while ((line = reader.readLine()) != null) {
	    consoleOut = consoleOut + line;
	}
	while ((line = stdError.readLine()) != null) {
	    errorOut = errorOut + line;
	}
	proc.waitFor();
	System.out.println("Console output is: " + consoleOut + "\n");
	if (!errorOut.equals("")) {
	    System.out.println("The error out is:" + errorOut + "\n");
	}
	if (consoleOut == "") {
	    return errorOut;
	} else {
	    return consoleOut + " " + errorOut;
	}
    }

    public static void startadbLog() {
	executeCommand(false, "adb logcat");
    }

    public static void stopadbLog() {
	executeCommand(false, "adb logcat -c");
    }

    public static void clickCameraAndroid() throws Exception {
	Thread.sleep(Constants.VERY_SHORT_DELAY);
	executeCommand(false, "adb shell input keyevent KEYCODE_CAMERA");
    }

    /**
     * Unistall the application , only applicable for Android
     * 
     * @param packageName
     *            --package name of the application
     * @throws Exception
     */
    public static void unistallApp(String packageName) throws Exception {
	unistallApp(packageName);
    }

    public static void executeBatchFile(String batchFileLocation) {
	// The batch file to execute
	final File batchFile = new File(batchFileLocation);

	// The output file. All activity is written to this file
	final File outputFile = new File(String.format(
		"output\\output_%tY%<tm%<td_%<tH%<tM%<tS.txt",
		System.currentTimeMillis()));

	// The argument to the batch file.
	final String argument = "";

	// Create the process
	final ProcessBuilder processBuilder = new ProcessBuilder(
		batchFile.getAbsolutePath(), argument);
	// Redirect any output (including error) to a file. This avoids
	// deadlocks
	// when the buffers get full.
	processBuilder.redirectErrorStream(true);
	processBuilder.redirectOutput(outputFile);

	// Add a new environment variable
	processBuilder.environment().put("message", "Executing the batch file");

	// Set the working directory. The batch file will run as if you are in
	// this
	// directory.
	processBuilder.directory(new File(batchFileLocation));

	// Start the process and wait for it to finish.
	Process process = null;
	try {
	    process = processBuilder.start();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	int exitStatus = 0;
	try {
	    exitStatus = process.waitFor();
	} catch (InterruptedException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	System.out.println("Processed finished with status: " + exitStatus);
    }

    public static String tryReadKeyFromJson(String JSONstring, String key) {
	return convertJSONtoString(JSONstring, key);
    }

    public static String convertJSONtoString(String JSONstring, String key) {
	if (isJson(JSONstring)) {
	    JSONObject json = JSONObject.fromObject(JSONstring);
	    if(json == null)
	    	return null;
	    else if(json.get(key) == null)
	    	return null;
	    else
	    {
	    	SgLog.info(json.get(key).toString());
	    	return json.get(key).toString();
	    }
	}

	return JSONstring;
    }

    // This function reads the JSON string based on the Key user provides and
    // returns the value.
    /*
     * public static String tryReadKeyFromJson(String JSONstring, String key) {
     * return convertJSONtoString(JSONstring, key); }
     */

    public static boolean isJson(String className) {
	try {
	    JSONObject.fromObject(className);
	    return true;
	} catch (Exception e) {
	    return false;
	}
    }

    public static void runAppleScript(String[] cmd) throws Exception {
	String lsString;
	Process process = Runtime.getRuntime().exec(cmd);
	BufferedReader bufferedReader = new BufferedReader(
		new InputStreamReader(process.getErrorStream()));
	while ((lsString = bufferedReader.readLine()) != null) {
	    SgLog.error(lsString);
	}

    }

    /*
     * public static void tryClickIOSDone() throws Exception { SgPlatformHandler
     * pf = SgFactory.getPlatformHandler(); pf.clickDone(); }
     */
}
