package org.kony.qa.stargate.wrappers.appy;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.im4java.core.CompareCmd;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;
import org.kony.qa.stargate.helpers.Common;
import org.kony.qa.stargate.common.FileHelper;
import org.kony.qa.stargate.common.ImageCropper;
import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.Assert;

/**
 * A test case simply calls
 * ScreenshotUtil.takeScreenshotAndCompare("NameOfImageWithoutExtension") How it
 * works? : When test case needs to compare screenshot it calls
 * takeScreenshotAndCompare. This class will take a screenshot via Appium and
 * compares the same with a predefined baseline image.
 * 
 * @FAQ
 * 
 *      ?Where is this predefined baseline image? Ans: In sgconfig.properties we
 *      give screenshotsRootDirectory. In this directory we expect baseline
 *      images.
 * 
 *      ?How baseline images are created? Ans: Whenever you want to create
 *      baseline images for a particular mobileOS/deviceType combination (for
 *      example Android/Emulator) make sure your tests are run on that
 *      combination. Then in sgconfig.properties set the value of
 *      isBaseLineScreenshotMode = true; If this value is true then our function
 *      testScreenshotAndCompare will create a baseline instead of performing
 *      validation. This is very handy.
 * 
 *      ?What is the sub directory structure for these screenshot images? Ans:
 *      We have three top level directories in screenshotsRootDirectory.
 *      baseline --> This is the expected images location. actual --> this is
 *      the live screenshots taken while tests are being run for validation.
 *      diff --> This is where we store diff of both baseline and actual images.
 *      Inside each of these three directories we have
 *      mobileOS/deviceType/appName/screenshotPrefixFolder/ :: mobileOS and
 *      deviceType are read from sgconfig.properties file. These are handled in
 *      SgCapabilities class. appName is set by test case and available in
 *      SgCapabilities. screenshotPrefixFolder is read from sgconfig.properties
 *      file.
 * 
 *      ?What is this preFix? Why do we need this? Ans: The directory structure
 *      we have is <root>/<actual/baseline/diff>/<mobileOS>/<deviceType>/ This
 *      enables us to have baseline per each of platform/device we support. But
 *      for some reason what if we want to maintain multiple baseline images for
 *      same combination of mobileOS/deviceType? prefix solves that problem. By
 *      default prefix will be main. By changing prefix we could support
 *      multiple baseline images for a single combination of
 *      mobileOS/deviceType. This prefix also comes handy when we are analyzing
 *      failures and want to take a new baseline for testing purpose without
 *      touching existing main baseline
 * 
 * @author venkat.saddala
 * 
 */
public class ScreenshotUtil {

    /**
     * Utility method to take screenshot and log it for analysis.
     * 
     * @param imageName
     * @throws Exception
     */
    public static void takeScreenshotAndLog(String imageName) throws Exception {
	Driver driver = Driver.getInstance();
	SgConfig sgConfig = SgConfig.getInstance();
	String validImage = null;
	File filePath = null;
	String imagePath = driver.sgCapabilities.getActualImageDirectory()
		+ imageName + "." + sgConfig.getImageExtension();
	validImage = imagePath;

	new File(driver.sgCapabilities.getActualImageDirectory()).mkdirs();
	filePath = new File(imagePath);

	try {
	    int count = 0;
	    // In Ios sometimes it fails to take Screenshots(timesd out taking
	    // Screenshot Error).So through this
	    // while condition , we'll keep looping around until the screnshot
	    // will be taken.
	    // Count <=0 just to make it go to getScreenshot() method
	    // once.
	    // Otherwise if the image is already there it won't take a new one
	    // at all.
	    while ((!FileHelper.isFileExists(validImage) && count < 10)
		    || count <= 0) {
		try {
		    getScreenshot(filePath);
		} catch (Exception e) {
		    SgLog.warn("Failed taking Screenshot of" + validImage
			    + ", trying again.");
		}
		count++;
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	    throw e;
	}

	// logging image to Budha server

	SgLog.logImageToBudha(1, imagePath,
		imageName + "." + sgConfig.getImageExtension(), "Test Case"
			+ imageName + "failed");

    }

    /**
     * Utility method to take screenshot and save it with the given and in the
     * given folder
     * 
     * @param imageNameWithExtensionWithFullPath
     * @throws Exception
     */
    public static void executeTakeScreenshot(
	    String imageNameWithExtensionWithFullPath) throws Exception {
	File temp = new File(imageNameWithExtensionWithFullPath);
	temp.getParentFile().mkdirs();
	File filePath = new File(imageNameWithExtensionWithFullPath);
	getScreenshot(filePath);
    }

    /**
     * Utility method to take screenshot into the actual folder with the image
     * name as test case name
     * 
     * @param imageName
     * @param imageCropStartX
     * @param imageCropStartY
     * @param imageCropEndX
     * @param imageCropEndY
     * @throws Exception
     */
    public static void takeScreenshot(String imageName, int imageCropStartX,
	    int imageCropStartY, int imageCropEndX, int imageCropEndY)
	    throws Exception {
	Driver driver = Driver.getInstance();
	File filePath = null;
	SgConfig sgConfig = SgConfig.getInstance();
	String validImage = null;
	if (sgConfig.getPlatformOS().toUpperCase() != "LINUX") {
	    if (sgConfig.isBaseLineScreenshotMode()) {
		String baselineImage = driver.sgCapabilities
			.getBaselineImageDirectory()
			+ imageName
			+ "."
			+ sgConfig.getImageExtension();
		validImage = baselineImage;
		new File(driver.sgCapabilities.getBaselineImageDirectory())
			.mkdirs();
		filePath = new File(baselineImage);
	    } else {
		String actualImage = driver.sgCapabilities
			.getActualImageDirectory()
			+ imageName
			+ "."
			+ SgConfig.getInstance().getImageExtension();
		validImage = actualImage;
		new File(driver.sgCapabilities.getActualImageDirectory())
			.mkdirs();
		filePath = new File(actualImage);
	    }
	} else {
	    sgConfig.setScreenshotsRootDirectory(System.getProperty(
		    "appium.screenshots.dir",
		    System.getProperty("java.io.tmpdir", "")));
	    validImage = sgConfig.getScreenshotsRootDirectory()
		    + File.separator + imageName + sgConfig.getImageExtension();
	    filePath = new File(validImage);
	}
	try {
	    int count = 0;
	    // In Ios sometimes it fails to take Screenshots(timesd out taking
	    // Screenshot Error).So through this
	    // while condition , we'll keep looping around until the screnshot
	    // will be taken.
	    // Count <=0 just to make it go to getScreenshot() method
	    // once.
	    // Otherwise if the image is already there it won't take a new one
	    // at all.
	    while ((!FileHelper.isFileExists(validImage) && count < 10)
		    || count <= 0) {
		try {
		    getScreenshot(filePath);
		} catch (Exception e) {
		    SgLog.warn("Failed taking Screenshot of" + validImage
			    + ", trying again.");
		}
		count++;
	    }
	    // Crops the image based on given (x,y) coordinates and writes
	    // the
	    // cropped image to the given
	    // location
	    ImageCropper.cropImage(filePath.getAbsolutePath(), imageCropStartX,
		    imageCropStartY, imageCropEndX, imageCropEndY);
	} catch (Exception e) {
	    e.printStackTrace();
	    throw e;
	}
    }
   

    /**
     * Utility method to take screenshot into the actual folder with the image
     * name as test case name. This takes screenshot immediately. Make sure the
     * page is loaded before calling this. <see this class level comments for
     * much verbose info>
     * 
     * @param imageName
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName)
	    throws Exception {
	boolean isComparisonInBothOrientations = false;
	isComparisonInBothOrientations = SgConfig.getInstance()
		.isComparisonInBothOrientations();
	ScreenshotUtil.takeScreenshotAndCompare(imageName,
		isComparisonInBothOrientations);
    }
    
    /**
     * Utility method to take screenshot and compare with
     * baseline Image as testCase name with threadSholdValue
     */
    public static void takeScreenshotAndCompareWithThreshold(String imageName,double threadsholdval)
    	    throws Exception {
    	double imageMagickDiffThreshold = 0.015;
    	boolean isComparisonInBothOrientations = false;
    	isComparisonInBothOrientations = SgConfig.getInstance()
    		.isComparisonInBothOrientations();
		try {
			imageMagickDiffThreshold = SgConfig.getInstance()
					.getImageMagickDiffThreshold();
			SgConfig.getInstance().setImageMagickDiffThreshold(threadsholdval);
			ScreenshotUtil.takeScreenshotAndCompare(imageName,
		    		isComparisonInBothOrientations);
		} catch (Exception e) {
			throw e;
		} finally {
			// reverting back the threshold value
			SgConfig.getInstance().setImageMagickDiffThreshold(
					imageMagickDiffThreshold);
		}	
        }
    

    /**
     * isComparisonInBothOrientations is parameter if it is true the comparison
     * will be done in other orientation also, with corresponding baseline
     * image.
     * 
     * @param imageName
     * @param isComparisonInBothOrientations
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    boolean isComparisonInBothOrientations) throws Exception {
	String orientation = Driver.getInstance().getOrientation();
	// taking screenshot and comparing in current orientation.
	ScreenshotUtil.takeScreenshotAndCompare(imageName, orientation);
	if (isComparisonInBothOrientations) {
	    // Now let us change orientation and perform screenshot and
	    // compare again.
	    if (orientation.equalsIgnoreCase("portrait")) {
		Gestures.setOrientation("landscape", true);
		takeScreenshotAndCompare(imageName, "landscape");
		// reverting the orientation to previous one.
		Gestures.setOrientation("portrait", true);
	    } else if (orientation.equalsIgnoreCase("landscape")) {
		Gestures.setOrientation("portrait", true);
		takeScreenshotAndCompare(imageName, "portrait");
		Gestures.setOrientation("landscape", true);
	    } else {
		throw new StargateException("excepting portrait and landscape "
			+ "as orientation values current orientation is"
			+ orientation);
	    }
	}
    }
    
    /**
     * isComparisonInBothOrientations is parameter if it is true the comparison
     * will be done in other orientation also, with corresponding baseline
     * image withThreshold Value.
     * 
     * @param imageName
     * @param isComparisonInBothOrientations
     * @param thresholdValue
     * @throws Exception
     */
    
    
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    boolean isComparisonInBothOrientations,double threadsholdval) throws Exception {
    	String orientation = Driver.getInstance().getOrientation();
    	// taking screenshot and comparing in current orientation.
    	ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName,orientation,threadsholdval);
    	if (isComparisonInBothOrientations) {
    	    // Now let us change orientation and perform screenshot and
    	    // compare again.
    	    if (orientation.equalsIgnoreCase("portrait")) {
    		Gestures.setOrientation("landscape", true);
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName,"landscape",threadsholdval);
    		// reverting the orientation to previous one.
    		Gestures.setOrientation("portrait", true);
    	    } else if (orientation.equalsIgnoreCase("landscape")) {
    		Gestures.setOrientation("portrait", true);
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName,"portrait",threadsholdval);
    		Gestures.setOrientation("landscape", true);
    	    } else {
    		throw new StargateException("excepting portrait and landscape "
    			+ "as orientation values current orientation is"
    			+ orientation);
    	    }
    	}
        }
    

    public static void takeScreenshotAndCompare(String imageName,
	    String orientation) throws Exception {
	// Test case wants to take a screenshot of whole screen and compare. Yet
	// we do crop as given in sgconfig.properties file. This helps us to
	// crop top bar. For example battery level indicator must not be a
	// reason for failing test case.
	int imageCropStartX, imageCropStartY, imageCropEndX, imageCropEndY;
	imageCropStartX = imageCropStartY = imageCropEndX = imageCropEndY = 0;
	SgConfig sgConfig = SgConfig.getInstance();
	if (orientation.equalsIgnoreCase("portrait")) {
	    // If portrait, then we cut in the same directions given
	    // from sgconfig.properties.
	    imageCropStartX = sgConfig.getImageCropStartX();
	    imageCropStartY = sgConfig.getImageCropStartY();
	    imageCropEndX = sgConfig.getImageCropEndX();
	    imageCropEndY = sgConfig.getImageCropEndY();

	} else if (orientation.equalsIgnoreCase("landscape")) {
	    SgLog.info("We are in landscape mode!");
	    imageCropStartX = sgConfig.getImageCropStartY();
	    imageCropStartY = sgConfig.getImageCropEndX();
	    imageCropEndX = sgConfig.getImageCropEndY();
	    imageCropEndY = sgConfig.getImageCropStartX();
	} else {
	    throw new StargateException(
		    "Only Portrait and landscape are expected outputs for orientation. Current orientation is "
			    + orientation);
	}

	takeScreenshotAndCompare(imageName, imageCropStartX, imageCropStartY,
		imageCropEndX, imageCropEndY);

    }
    
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    String orientation,double threadsholdval) throws Exception {
    	// Test case wants to take a screenshot of whole screen and compare. Yet
    	// we do crop as given in sgconfig.properties file. This helps us to
    	// crop top bar. For example battery level indicator must not be a
    	// reason for failing test case.
    	int imageCropStartX, imageCropStartY, imageCropEndX, imageCropEndY;
    	imageCropStartX = imageCropStartY = imageCropEndX = imageCropEndY = 0;
    	SgConfig sgConfig = SgConfig.getInstance();
    	if (orientation.equalsIgnoreCase("portrait")) {
    	    // If portrait, then we cut in the same directions given
    	    // from sgconfig.properties.
    	    imageCropStartX = sgConfig.getImageCropStartX();
    	    imageCropStartY = sgConfig.getImageCropStartY();
    	    imageCropEndX = sgConfig.getImageCropEndX();
    	    imageCropEndY = sgConfig.getImageCropEndY();

    	} else if (orientation.equalsIgnoreCase("landscape")) {
    	    SgLog.info("We are in landscape mode!");
    	    imageCropStartX = sgConfig.getImageCropStartY();
    	    imageCropStartY = sgConfig.getImageCropEndX();
    	    imageCropEndX = sgConfig.getImageCropEndY();
    	    imageCropEndY = sgConfig.getImageCropStartX();
    	} else {
    	    throw new StargateException(
    		    "Only Portrait and landscape are expected outputs for orientation. Current orientation is "
    			    + orientation);
    	}
    	double imageMagickDiffThreshold = 0.015;
    	try {
			imageMagickDiffThreshold = SgConfig.getInstance()
					.getImageMagickDiffThreshold();
			SgConfig.getInstance().setImageMagickDiffThreshold(threadsholdval);
			takeScreenshotAndCompare(imageName, imageCropStartX, imageCropStartY,
		    		imageCropEndX, imageCropEndY);
		} catch (Exception e) {
			throw e;
		} finally {
			// reverting back the threshold value
			SgConfig.getInstance().setImageMagickDiffThreshold(
					imageMagickDiffThreshold);
		}	
    
        }

    /**
     * Takes a screenshot, crops the image to given x,y x,y Ecluid params and
     * compares the same with baseline image.
     * 
     * @param imageName
     * @param imageCropStartX
     * @param imageCropStartY
     * @param imageCropEndX
     * @param imageCropEndY
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    int imageCropStartX, int imageCropStartY, int imageCropEndX,
	    int imageCropEndY) throws Exception {

	takeScreenshot(imageName, imageCropStartX, imageCropStartY,
		imageCropEndX, imageCropEndY);

	// If we are in baseline we don't need to call compare
	if (SgConfig.getInstance().isBaseLineScreenshotMode()) {
	    return;
	}

	String extension = SgConfig.getInstance().getImageExtension();
	// Now compare with predefined baseline
	Driver driver = Driver.getInstance();
	String konyPlugin = SgConfig.getInstance().getKonyPlugin();

	// This variable will keep track of which folder to look for
	// Baselineimage, if there will be image file (with same name) be
	// present in kony plugin specific folder , effectiveBaselineFolder will
	// be eqaul to the path to that kony Plugin specific directory
	// otherwise it will be same as baseline mainFolder

	// The idea behind this logic is. there are some Kony plugin specific
	// Screenshot. SO we will keep that in Kony plugin specific folder.
	// So while comparing we first check in the kony Plugin specific folder
	// folder whether the image is present or not.
	// If the image is not present there will go and look into the main
	// folder.
	// If the image is present in konyPlugin specific folder. We'll compare
	// with this and testCase fails if images are not same or pass if they
	// are same
	String effectiveBaselineFolder = driver.sgCapabilities
		.getBaselineImageDirectory();

	String actualImage = driver.sgCapabilities.getActualImageDirectory()
		+ imageName + "." + extension;
	String baselineImage = "";
	if (SgConfig.getInstance().getPlatformOS().toUpperCase() != "LINUX") {
	    // Checking if image is preenet in Kony Plugin SPecific baseline
	    // Folder
	    if (!FileHelper.isFileExists(effectiveBaselineFolder + konyPlugin
		    + File.separator + imageName + "." + extension)) {
		SgLog.extraVerbose("Kony Plugin Specific Image :: "
			+ driver.sgCapabilities.getBaselineImageDirectory()
			+ konyPlugin
			+ File.separator
			+ imageName
			+ "."
			+ extension
			+ " is not present so fallingBack to generic Baseline Folder");
	    } else {
		effectiveBaselineFolder += konyPlugin + File.separator;
	    }
	    baselineImage = effectiveBaselineFolder + imageName + "."
		    + extension;
	} else {
	    baselineImage = effectiveBaselineFolder
		    + File.separator
		    + SgConfig.getInstance().getScreenshotPrefixFolder()
		    + File.separator
		    + Driver.getInstance().sgCapabilities
			    .getappWithRelativePath() + File.separator
		    + imageName + "." + extension;

	}
	boolean rv = compareImages(baselineImage, actualImage, imageName);

	if (rv == true) {
	    // return here if comparison is success.
	    SgLog.logImageToBudha(5,
		    driver.sgCapabilities.getDiffImageDirectory() + imageName
			    + "." + extension, imageName + "." + extension,
		    "Diff image on pass");
	    // upload baseline image to budha
	    SgLog.logImageToBudha(4, effectiveBaselineFolder + imageName + "."
		    + extension, imageName + "." + extension,
		    "Baseline image on pass");
	    // upload actual image to budha
	    SgLog.logImageToBudha(3,
		    driver.sgCapabilities.getActualImageDirectory() + imageName
			    + "." + extension, imageName + "." + extension,
		    "Actual image on pass");
	    return;
	} else { // Else try with twin images or throw

	    // This skip should be kept here only becasue if skipScreenshotMode
	    // is true ,it still means we need to have diff image.
	    // It just means setting it to true so that , test Case should not
	    // fail even if images are not same.
	    // If skip is enabled then skip after printing a warning
	    if (SgConfig.getInstance().getSkipScreenshotMode()) {
		SgLog.warn("Skipping Image comparision fail result passing via exception. "
			+ "To fail the test case on incorrect screenshots, "
			+ "Please change skipScreenshotMode to false");
		return;
	    }

	    // Log to Budha START
	    // Comparison is done, let us log to budha the failure images.
	    // upload diff image to budha
	    SgLog.logImageToBudha(1,
		    driver.sgCapabilities.getDiffImageDirectory() + imageName
			    + "." + extension, imageName + "." + extension,
		    "Diff image on fail");
	    // upload baseline image to budha
	    SgLog.logImageToBudha(4, effectiveBaselineFolder + imageName + "."
		    + extension, imageName + "." + extension,
		    "Baseline image on fail");
	    // upload actual image to budha
	    SgLog.logImageToBudha(2,
		    driver.sgCapabilities.getActualImageDirectory() + imageName
			    + "." + extension, imageName + "." + extension,
		    "Actual image on fail");
	    // Log to Budha END

	    int twinImageCounter = 1;
	    String twinImageWithFullPath = effectiveBaselineFolder + imageName
		    + "_twin_" + twinImageCounter + "." + extension;
	    for (twinImageCounter = 1;; twinImageCounter++) {
		String twinBaseLineImage = effectiveBaselineFolder + imageName
			+ "_twin_" + twinImageCounter + "." + extension;
		String diffImageName = imageName + "_twin_" + twinImageCounter;
		if (FileHelper.isFileExists(twinImageWithFullPath)) {
		    boolean resultFlag = compareImages(twinBaseLineImage,
			    actualImage, diffImageName);
		    if (!resultFlag) {
			SgLog.logImageToBudha(1,
				driver.sgCapabilities.getDiffImageDirectory()
					+ diffImageName + "." + extension,
				diffImageName + "." + extension, "Twin("
					+ twinImageCounter
					+ ") Diff image on twin fail");
			// upload baseline image to budha
			SgLog.logImageToBudha(4, effectiveBaselineFolder
				+ twinBaseLineImage, imageName + "_twin_"
				+ twinImageCounter + "." + extension, "Twin("
				+ twinImageCounter
				+ ") Baseline image on twin fail");
			continue;
		    } else {
			SgLog.logImageToBudha(5,
				driver.sgCapabilities.getDiffImageDirectory()
					+ diffImageName + "." + extension,
				diffImageName + "." + extension, "Twin("
					+ twinImageCounter
					+ ") Diff image on twin pass");
			// upload baseline image to budha
			SgLog.logImageToBudha(4, effectiveBaselineFolder
				+ twinBaseLineImage, imageName + "_twin_"
				+ twinImageCounter + "." + extension, "Twin("
				+ twinImageCounter
				+ ") Baseline image on twin pass");
			return;
		    }
		}
		throw new StargateException(
			"Current screen is not same as expected baseline image."
				+ " :: actual image: " + actualImage
				+ " :: Expected baseline image: "
				+ baselineImage);
	    }
	}
    }
    
    /**
     * Takes a screenshot, crops the image to given x,y x,y and Threshold Value Ecluid params and
     * compares the same with baseline image.
     * 
     * @param imageName
     * @param imageCropStartX
     * @param imageCropStartY
     * @param imageCropEndX
     * @param imageCropEndY
     * @param thresholdValue
     * @throws Exception
     */
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    int imageCropStartX, int imageCropStartY, int imageCropEndX,
    	    int imageCropEndY,double threadsholdvalue) throws Exception {

    	takeScreenshot(imageName, imageCropStartX, imageCropStartY,
    		imageCropEndX, imageCropEndY);

    	// If we are in baseline we don't need to call compare
    	if (SgConfig.getInstance().isBaseLineScreenshotMode()) {
    	    return;
    	}

    	String extension = SgConfig.getInstance().getImageExtension();
    	// Now compare with predefined baseline
    	Driver driver = Driver.getInstance();
    	String konyPlugin = SgConfig.getInstance().getKonyPlugin();

    	// This variable will keep track of which folder to look for
    	// Baselineimage, if there will be image file (with same name) be
    	// present in kony plugin specific folder , effectiveBaselineFolder will
    	// be eqaul to the path to that kony Plugin specific directory
    	// otherwise it will be same as baseline mainFolder

    	// The idea behind this logic is. there are some Kony plugin specific
    	// Screenshot. SO we will keep that in Kony plugin specific folder.
    	// So while comparing we first check in the kony Plugin specific folder
    	// folder whether the image is present or not.
    	// If the image is not present there will go and look into the main
    	// folder.
    	// If the image is present in konyPlugin specific folder. We'll compare
    	// with this and testCase fails if images are not same or pass if they
    	// are same
    	String effectiveBaselineFolder = driver.sgCapabilities
    		.getBaselineImageDirectory();

    	String actualImage = driver.sgCapabilities.getActualImageDirectory()
    		+ imageName + "." + extension;
    	String baselineImage = "";
    	if (SgConfig.getInstance().getPlatformOS().toUpperCase() != "LINUX") {
    	    // Checking if image is preenet in Kony Plugin SPecific baseline
    	    // Folder
    	    if (!FileHelper.isFileExists(effectiveBaselineFolder + konyPlugin
    		    + File.separator + imageName + "." + extension)) {
    		SgLog.extraVerbose("Kony Plugin Specific Image :: "
    			+ driver.sgCapabilities.getBaselineImageDirectory()
    			+ konyPlugin
    			+ File.separator
    			+ imageName
    			+ "."
    			+ extension
    			+ " is not present so fallingBack to generic Baseline Folder");
    	    } else {
    		effectiveBaselineFolder += konyPlugin + File.separator;
    	    }
    	    baselineImage = effectiveBaselineFolder + imageName + "."
    		    + extension;
    	} else {
    	    baselineImage = effectiveBaselineFolder
    		    + File.separator
    		    + SgConfig.getInstance().getScreenshotPrefixFolder()
    		    + File.separator
    		    + Driver.getInstance().sgCapabilities
    			    .getappWithRelativePath() + File.separator
    		    + imageName + "." + extension;

    	}
    	boolean rv;
    	double imageMagickDiffThreshold = 0.015;
    	try {
			imageMagickDiffThreshold = SgConfig.getInstance()
					.getImageMagickDiffThreshold();
    		 SgConfig.getInstance().setImageMagickDiffThreshold(threadsholdvalue);
    		 rv = compareImages(baselineImage, actualImage, imageName);
    	}catch (Exception e) {
			throw e;
		} finally {
			// reverting back the threshold value
			SgConfig.getInstance().setImageMagickDiffThreshold(
					imageMagickDiffThreshold);
		}	
    	if (rv == true) {
    	    // return here if comparison is success.
    	    SgLog.logImageToBudha(5,
    		    driver.sgCapabilities.getDiffImageDirectory() + imageName
    			    + "." + extension, imageName + "." + extension,
    		    "Diff image on pass");
    	    // upload baseline image to budha
    	    SgLog.logImageToBudha(4, effectiveBaselineFolder + imageName + "."
    		    + extension, imageName + "." + extension,
    		    "Baseline image on pass");
    	    // upload actual image to budha
    	    SgLog.logImageToBudha(3,
    		    driver.sgCapabilities.getActualImageDirectory() + imageName
    			    + "." + extension, imageName + "." + extension,
    		    "Actual image on pass");
    	    return;
    	} else { // Else try with twin images or throw

    	    // This skip should be kept here only becasue if skipScreenshotMode
    	    // is true ,it still means we need to have diff image.
    	    // It just means setting it to true so that , test Case should not
    	    // fail even if images are not same.
    	    // If skip is enabled then skip after printing a warning
    	    if (SgConfig.getInstance().getSkipScreenshotMode()) {
    		SgLog.warn("Skipping Image comparision fail result passing via exception. "
    			+ "To fail the test case on incorrect screenshots, "
    			+ "Please change skipScreenshotMode to false");
    		return;
    	    }

    	    // Log to Budha START
    	    // Comparison is done, let us log to budha the failure images.
    	    // upload diff image to budha
    	    SgLog.logImageToBudha(1,
    		    driver.sgCapabilities.getDiffImageDirectory() + imageName
    			    + "." + extension, imageName + "." + extension,
    		    "Diff image on fail");
    	    // upload baseline image to budha
    	    SgLog.logImageToBudha(4, effectiveBaselineFolder + imageName + "."
    		    + extension, imageName + "." + extension,
    		    "Baseline image on fail");
    	    // upload actual image to budha
    	    SgLog.logImageToBudha(2,
    		    driver.sgCapabilities.getActualImageDirectory() + imageName
    			    + "." + extension, imageName + "." + extension,
    		    "Actual image on fail");
    	    // Log to Budha END

    	    int twinImageCounter = 1;
    	    String twinImageWithFullPath = effectiveBaselineFolder + imageName
    		    + "_twin_" + twinImageCounter + "." + extension;
    	    for (twinImageCounter = 1;; twinImageCounter++) {
    		String twinBaseLineImage = effectiveBaselineFolder + imageName
    			+ "_twin_" + twinImageCounter + "." + extension;
    		String diffImageName = imageName + "_twin_" + twinImageCounter;
    		if (FileHelper.isFileExists(twinImageWithFullPath)) {
    		    boolean resultFlag = compareImages(twinBaseLineImage,
    			    actualImage, diffImageName);
    		    if (!resultFlag) {
    			SgLog.logImageToBudha(1,
    				driver.sgCapabilities.getDiffImageDirectory()
    					+ diffImageName + "." + extension,
    				diffImageName + "." + extension, "Twin("
    					+ twinImageCounter
    					+ ") Diff image on twin fail");
    			// upload baseline image to budha
    			SgLog.logImageToBudha(4, effectiveBaselineFolder
    				+ twinBaseLineImage, imageName + "_twin_"
    				+ twinImageCounter + "." + extension, "Twin("
    				+ twinImageCounter
    				+ ") Baseline image on twin fail");
    			continue;
    		    } else {
    			SgLog.logImageToBudha(5,
    				driver.sgCapabilities.getDiffImageDirectory()
    					+ diffImageName + "." + extension,
    				diffImageName + "." + extension, "Twin("
    					+ twinImageCounter
    					+ ") Diff image on twin pass");
    			// upload baseline image to budha
    			SgLog.logImageToBudha(4, effectiveBaselineFolder
    				+ twinBaseLineImage, imageName + "_twin_"
    				+ twinImageCounter + "." + extension, "Twin("
    				+ twinImageCounter
    				+ ") Baseline image on twin pass");
    			return;
    		    }
    		}
    		throw new StargateException(
    			"Current screen is not same as expected baseline image."
    				+ " :: actual image: " + actualImage
    				+ " :: Expected baseline image: "
    				+ baselineImage);
    	    }
    	}
        }
    

    public static void logImageToBudha(String imageFullPath,
	    String imageNameWithExtension, boolean isActual, String comments,
	    boolean force) throws Exception {
	return;
	// String logLevel = "VERBOSE";
	// String message = comments;
	// if (isActual) {
	// message += " <br>:::: __ACTUAL__ image ::::<br> ";
	// } else {
	// message += " <br>:::: EXPECTED image :::: <br> ";
	// }
	// SgLog.getInstance().asyncInsertLogsWithImage(imageFullPath,
	// imageNameWithExtension, logLevel, message, force);
    }

    /**
     * Compares the two given images and if there is a difference then it will
     * create the diff image in the respective folder
     * 
     * @param baselineImagePath
     * @param actualImagePath
     * @param diffImageName
     * @return true if same images. false if different images or other issues
     * @throws Exception
     */
    @SuppressWarnings("finally")
    public static boolean compareImages(String baselineImagePath,
	    String actualImagePath, String diffImageName) throws Exception {
	if (!FileHelper.isFileExists(baselineImagePath)) {
	    throw new FileNotFoundException(
		    "Given baseline image file is not found. "
			    + "If this is the first time you are running this test, "
			    + "make sure you have taken baseline image for this platform "
			    + "by following instructions given in ScreenshotUtil.java "
			    + "documentation. Also make sure screenshotsRootDirectory "
			    + "is correctly set in sgconfig.properties file: "
			    + baselineImagePath);
	}
	if (!FileHelper.isFileExists(actualImagePath)) {
	    throw new FileNotFoundException(
		    "given actual image file is not found. "
			    + "This usually means we are not able to take screenshot. "
			    + "Check you have permissions to ScreenshotsRootdirectory/actual folder: "
			    + baselineImagePath);
	}
	// ... Validations completed.

	Driver driver = Driver.getInstance();
	String diffImage = driver.sgCapabilities.getDiffImageDirectory()
		+ diffImageName + "."
		+ SgConfig.getInstance().getImageExtension();
	if (!driver.sgCapabilities.getPlatformOS().equalsIgnoreCase("LINUX")) {
	    IMOperation cmpOperation = new IMOperation();
	    // run the diff
	    CompareCmd cmpCommand = new CompareCmd();
	    if (driver.sgCapabilities.getPlatformOS().equalsIgnoreCase("MAC")) {
		String locationOfImageMagic = SgConfig.getInstance()
			.getImageMagickLocation();
		cmpCommand.setSearchPath(locationOfImageMagic + ":"
			+ locationOfImageMagic + "/bin:" + locationOfImageMagic
			+ "/lib");

	    } else {
		cmpCommand.setSearchPath(SgConfig.getInstance()
			.getImageMagickLocation());
	    }
	    // For metric-output
	    cmpOperation.addImage();
	    cmpOperation.addImage();
	    cmpOperation.metric(SgConfig.getInstance()
		    .getImageComparisionMertic());
	    // cmpOperation.subimageSearch();
	    cmpOperation.addImage();
	    try {
		new File(driver.sgCapabilities.getDiffImageDirectory())
			.mkdirs();
		// Running the compare command against the two given images
		// and it writes diff image to the given path
		try {
		    cmpCommand.run(cmpOperation, baselineImagePath,
			    actualImagePath, diffImage);
		} finally {
		    // This part of the code is useful for identifying the
		    // different
		    // images when the ImageMagik version is less than 6.8.6
		    // using
		    // the
		    // error test returned from the executed command
		    ArrayList<String> list = cmpCommand.getErrorText();
		    String dissimilarityValue = (list.get(0).split(" ")[0]);
		    SgLog.info(list.toString());
		    SgLog.info("The difference in pixels: "
			    + dissimilarityValue);
		    return compareDiffValue(list.get(0));
		}
	    } catch (IM4JavaException e) {
		SgLog.printStackTrace(e);
		SgLog.error("Images are different or ImagicMagik is not installed");
		return false;
	    }
	} else {
	    diffImage = driver.sgCapabilities.getDiffImageDirectory()
		    + diffImageName + "_diff" + "."
		    + SgConfig.getInstance().getImageExtension();
	    String diffValue = "";
	    try {
		diffValue = Common.executeCommandWithConsoleOPReturn("compare"
			+ " " + baselineImagePath + " " + actualImagePath + " "
			+ diffImage);
		return compareDiffValue(diffValue);
	    } catch (IM4JavaException e) {
		SgLog.printStackTrace(e);
		SgLog.error("Images are different or ImagicMagik is not installed");
		SgLog.printStackTrace(e);
		return false;
	    }
	}
    }

    public static boolean compareDiffValue(String diffValue) throws Exception {
	String dissimilarityValue1 = (diffValue.split(" ")[1]);
	if (dissimilarityValue1.contains("(")
		|| dissimilarityValue1.contains(")")) {
	    dissimilarityValue1 = dissimilarityValue1.replace("(", " ");
	    dissimilarityValue1 = dissimilarityValue1.replace(")", " ");
	    dissimilarityValue1 = dissimilarityValue1.trim();
	}
	SgLog sgLog = SgLog.getInstance();
	sgLog.insertLogs("DEBUG", "The difference in % ratio :"
		+ dissimilarityValue1, true);
	double val;
	try {
	    val = Double.parseDouble(dissimilarityValue1);
	} catch (Exception e) {
	    // SgLog.printStackTrace(e);
	    SgLog.error("Images Size not same or image not same or imagemagick not installled. Most probably image size differ");
	    return false;
	}
	double threshold = SgConfig.getInstance().getImageMagickDiffThreshold();
	if (!dissimilarityValue1.matches("0")) {
	    SgLog.warn("The difference is not 0, but still we are continuing");
	}
	if (val >= threshold) {
	    throw new IM4JavaException("Images are different");
	}
	return true;
    }

    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares. isFullWidth parameter if
     * true takes screenshot without any cropping width wise, if false crops
     * accordingly.
     * 
     * @param imageName
     * @param topElement
     * @param bottomElement
     * @param isFullWidth
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, SgElement bottomElement, boolean isFullWidth)
	    throws Exception {
	boolean excludeBoundaryElements = false;
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		bottomElement, isFullWidth, excludeBoundaryElements);
    }
    
    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares. isFullWidth parameter if
     * true takes screenshot without any cropping width wise, if false crops
     * accordingly.
     * 
     * @param imageName
     * @param topElement
     * @param bottomElement
     * @param isFullWidth
     * @param thresholdValue
     * @throws Exception
     */
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,double threasholdValue)
    	    throws Exception {
    	boolean excludeBoundaryElements = false;
    	ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, topElement,
    		bottomElement, isFullWidth, excludeBoundaryElements,threasholdValue);
        }

    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
	    boolean excludeBoundaryElements) throws Exception {
	boolean isComparisonInBothOrientations = false;
	isComparisonInBothOrientations = SgConfig.getInstance()
		.isComparisonInBothOrientations();
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		bottomElement, isFullWidth, excludeBoundaryElements,
		isComparisonInBothOrientations);
    }
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
    	    boolean excludeBoundaryElements,double threadsholdValue) throws Exception {
    	boolean isComparisonInBothOrientations = false;
    	isComparisonInBothOrientations = SgConfig.getInstance()
    		.isComparisonInBothOrientations();
    	ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, topElement,
    		bottomElement, isFullWidth, excludeBoundaryElements,
    		isComparisonInBothOrientations,threadsholdValue);
        }
    

    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares.
     * 
     * @param iamgename
     *            , topElement and bottomElement
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, SgElement bottomElement) throws Exception {
	boolean isFullWidth = false;
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		bottomElement, isFullWidth);
    }

    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares.
     * isComparisonInBothOrientations is parameter if it is true the comparison
     * will be done in other orientation also, with corresponding baseline
     * image.
     * 
     * @param imageName
     * @param topElement
     * @param bottomElement
     * @param isComparisonInBothOrientations
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
	    boolean excludeBoundaryElements,
	    boolean isComparisonInBothOrientations) throws Exception {
	String orientation = Driver.getInstance().getOrientation();
	// taking screenshot and comparing in current orientation.
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		bottomElement, isFullWidth, excludeBoundaryElements,
		orientation);
	if (isComparisonInBothOrientations) {
	    // Now let us change orientation and perform screenshot and
	    // compare again.
	    if (orientation.equalsIgnoreCase("portrait")) {
		Gestures.setOrientation("landscape", true);
		takeScreenshotAndCompare(imageName, topElement, bottomElement,
			isFullWidth, excludeBoundaryElements, "landscape");
		// reverting the orientation to previous one.
		Gestures.setOrientation("portrait", true);
	    } else if (orientation.equalsIgnoreCase("landscape")) {
		Gestures.setOrientation("portrait", true);
		takeScreenshotAndCompare(imageName, topElement, bottomElement,
			isFullWidth, excludeBoundaryElements, "portrait");
		Gestures.setOrientation("landscape", true);
	    } else {
		throw new StargateException("excepting portrait and landscape "
			+ "as orientation values.current orientation is"
			+ orientation);
	    }
	}
    }
    
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
    	    boolean excludeBoundaryElements,
    	    boolean isComparisonInBothOrientations,double thresholdValue) throws Exception {
    	String orientation = Driver.getInstance().getOrientation();
    	// taking screenshot and comparing in current orientation.
    	ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, topElement,
    		bottomElement, isFullWidth, excludeBoundaryElements,
    		orientation,thresholdValue);
    	if (isComparisonInBothOrientations) {
    	    // Now let us change orientation and perform screenshot and
    	    // compare again.
    	    if (orientation.equalsIgnoreCase("portrait")) {
    		Gestures.setOrientation("landscape", true);
    		takeScreenshotAndCompareWithThreshold(imageName, topElement, bottomElement,
    			isFullWidth, excludeBoundaryElements, "landscape",thresholdValue);
    		// reverting the orientation to previous one.
    		Gestures.setOrientation("portrait", true);
    	    } else if (orientation.equalsIgnoreCase("landscape")) {
    		Gestures.setOrientation("portrait", true);
    		takeScreenshotAndCompareWithThreshold(imageName, topElement, bottomElement,
    			isFullWidth, excludeBoundaryElements, "portrait",thresholdValue);
    		Gestures.setOrientation("landscape", true);
    	    } else {
    		throw new StargateException("excepting portrait and landscape "
    			+ "as orientation values.current orientation is"
    			+ orientation);
    	    }
    	}
        }

    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares. according to orientation
     * the parameters are called.
     * 
     * @param imageName
     * @param topElement
     * @param bottomElement
     * @param isFullWidth
     * @param orientation
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
	    boolean excludeBoundaryElements, String orientation)
	    throws Exception {
	Point startLocation = topElement.getLocation();
	Point endLocation = bottomElement.getLocation();
	int startY, endY;

	// This variable is only used if platform is IOS , as in Ios the
	// resolution what appium is returning is different than the original
	// resolution of iphone and is same for Ipad. So better to create a
	// variable to store the factor

	if (excludeBoundaryElements) {

	    startY = startLocation.y + topElement.getSize().height;
	    endY = Driver.getScreenResolution().height - endLocation.y;

	} else {
	    startY = startLocation.y;
	    endY = Driver.getScreenResolution().height
		    - (endLocation.y + bottomElement.getSize().height);
	}

	if (isFullWidth) {
	    if (orientation.equalsIgnoreCase("PORTRAIT")) {
		ScreenshotUtil.takeScreenshotAndCompare(imageName, 0, startY,
			0, endY);
	    } else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
		ScreenshotUtil.takeScreenshotAndCompare(imageName, startY, 0,
			endY, 0);
	    }
	} else {
	    int startX = startLocation.x;

	    if (orientation.equalsIgnoreCase("PORTRAIT")) {
		ScreenshotUtil.takeScreenshotAndCompare(imageName, startX,
			startY, 0, endY);
	    } else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
		ScreenshotUtil.takeScreenshotAndCompare(imageName, startY, 0,
			endY, startX);
	    }

	}

    }
    
    /**
     * Takes screenshot from given top element to given bottom element including
     * both top and bottom elements and then compares. according to orientation
     * the parameters are called.
     * 
     * @param imageName
     * @param topElement
     * @param bottomElement
     * @param isFullWidth
     * @param orientation
     * @param excludeBoundaryElements
     * @param thresholdValue
     * @throws Exception
     */
    public static void takeScreenshotAndCompareWithThreshold(String imageName,
    	    SgElement topElement, SgElement bottomElement, boolean isFullWidth,
    	    boolean excludeBoundaryElements, String orientation,double thresholdValue)
    	    throws Exception {
    	Point startLocation = topElement.getLocation();
    	Point endLocation = bottomElement.getLocation();
    	int startY, endY;

    	// This variable is only used if platform is IOS , as in Ios the
    	// resolution what appium is returning is different than the original
    	// resolution of iphone and is same for Ipad. So better to create a
    	// variable to store the factor

    	if (excludeBoundaryElements) {

    	    startY = startLocation.y + topElement.getSize().height;
    	    endY = Driver.getScreenResolution().height - endLocation.y;

    	} else {
    	    startY = startLocation.y;
    	    endY = Driver.getScreenResolution().height
    		    - (endLocation.y + bottomElement.getSize().height);
    	}

    	if (isFullWidth) {
    	    if (orientation.equalsIgnoreCase("PORTRAIT")) {
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, 0, startY,
    			0, endY,thresholdValue);
    	    } else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, startY, 0,
    			endY, 0,thresholdValue);
    	    }
    	} else {
    	    int startX = startLocation.x;

    	    if (orientation.equalsIgnoreCase("PORTRAIT")) {
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, startX,
    			startY, 0, endY,thresholdValue);
    	    } else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
    		ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, startY, 0,
    			endY, startX,thresholdValue);
    	    }

    	}

        }
   

    public static void takeScreenshotOfPopUp(String imagename, String PopUp)
	    throws Exception {
	SgElement testImageElement = SgElement.getSgElement("class",
		"android.widget.FrameLayout");
	try {
	    testImageElement.takeScreenshotAndCompare(imagename);
	} catch (Exception e) {
	    SgLog.printStackTrace(e);
	    try {
		Gestures.clickOnPopUp(PopUp);
	    } catch (Exception e1) {
		SgLog.printStackTrace(e1);
		try {
		    Gestures.clickOnPopUp("Yes");
		} catch (Exception e2) {
		    SgLog.printStackTrace(e2);
		    Gestures.clickOnPopUp("Dismiss");
		}
	    }
	    Assert.fail("PopUP screenshots are not same !!");
	}
	return;
    }

    /**
     * crops the image above the given topElement
     * 
     * @param imageName
     * @param topElement
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement) throws Exception {
	boolean isComparisonInBothOrientations = false;
	isComparisonInBothOrientations = SgConfig.getInstance()
		.isComparisonInBothOrientations();
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		isComparisonInBothOrientations);
    }
    
    /**
     * crops the image above the given topElement with threshold
     * 
     * @param imageName
     * @param topElement
     * @param thresholdValue
     * @throws Exception
     */
    public static void takeScreenshotAndCompareWithThresholdValue(String imageName,
	    SgElement topElement,double thresholdValue) throws Exception {
	boolean isComparisonInBothOrientations = false;
	isComparisonInBothOrientations = SgConfig.getInstance()
		.isComparisonInBothOrientations();
	ScreenshotUtil.takeScreenshotAndCompareWithThresholdValue(imageName, topElement,
		isComparisonInBothOrientations,thresholdValue);
    }
    
    

    /**
     * crops the image above the given topElement.
     * isComparisonInBothOrientations is parameter if it is true the comparison
     * will be done in other orientation also, with corresponding baseline
     * image.
     * 
     * @param imageName
     * @param topElement
     * @param isComparisonInBothOrientations
     * @throws Exception
     */

    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, boolean isComparisonInBothOrientations)
	    throws Exception {
	String orientation = Driver.getInstance().getOrientation();
	// taking screenshot and comparing in current orientation.
	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
		orientation);
	if (isComparisonInBothOrientations) {
	    // Now let us change orientation and perform screenshot and
	    // compare again.
	    if (orientation.equalsIgnoreCase("portrait")) {
		Gestures.setOrientation("landscape", true);
		takeScreenshotAndCompare(imageName, topElement, "landscape");
		// reverting the orientation to previous one.
		Gestures.setOrientation("portrait", true);
	    } else if (orientation.equalsIgnoreCase("landscape")) {
		Gestures.setOrientation("portrait", true);
		takeScreenshotAndCompare(imageName, topElement, "portrait");
		Gestures.setOrientation("landscape", true);
	    } else {
		throw new StargateException("excepting portrait and landscape "
			+ "as orientation values.current orientation is"
			+ orientation);
	    }
	}
    }
    /**
     * crops the image above the given topElement.
     * isComparisonInBothOrientations is parameter if it is true the comparison
     * will be done in other orientation also, with corresponding baseline
     * image with thresholdValue.
     * 
     * @param imageName
     * @param topElement
     * @param thresholdValue
     * @param isComparisonInBothOrientations
     * @throws Exception
     */
    public static void takeScreenshotAndCompareWithThresholdValue(String imageName,
    	    SgElement topElement, boolean isComparisonInBothOrientations,double thresholdValue)
    	    throws Exception {
    	String orientation = Driver.getInstance().getOrientation();
    	// taking screenshot and comparing in current orientation.
    	ScreenshotUtil.takeScreenshotAndCompare(imageName, topElement,
    		orientation);
    	if (isComparisonInBothOrientations) {
    	    // Now let us change orientation and perform screenshot and
    	    // compare again.
    	    if (orientation.equalsIgnoreCase("portrait")) {
    		Gestures.setOrientation("landscape", true);
    		takeScreenshotAndCompareWithThresholdValue(imageName, topElement, "landscape",thresholdValue);
    		// reverting the orientation to previous one.
    		Gestures.setOrientation("portrait", true);
    	    } else if (orientation.equalsIgnoreCase("landscape")) {
    		Gestures.setOrientation("portrait", true);
    		takeScreenshotAndCompareWithThresholdValue(imageName, topElement, "portrait",thresholdValue);
    		Gestures.setOrientation("landscape", true);
    	    } else {
    		throw new StargateException("excepting portrait and landscape "
    			+ "as orientation values.current orientation is"
    			+ orientation);
    	    }
    	}
        }
    
    
    
    /**
     * crops the image above the given topElement. according to orientation the
     * parameters are called.
     * 
     * @param imageName
     * @param topElement
     * @param orientation
     * @throws Exception
     */
    public static void takeScreenshotAndCompare(String imageName,
	    SgElement topElement, String orientation) throws Exception {
	Point startLocation = topElement.getLocation();
	if (orientation.equalsIgnoreCase("PORTRAIT")) {

	    ScreenshotUtil.takeScreenshotAndCompare(imageName, startLocation.x,
		    startLocation.y, 0, 0);

	} else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
	    ScreenshotUtil.takeScreenshotAndCompare(imageName, startLocation.y,
		    0, 0, startLocation.x);
	}
    }

   /*
    * crops the image above the given topElement. according to orientation the
    * parameters are called with threshol;sd
    * 
    * @param imageName
    * @param topElement
    * @param orientation
    * @throws Exception
    */
   public static void takeScreenshotAndCompareWithThresholdValue(String imageName,
	    SgElement topElement, String orientation,double thresholdValue) throws Exception {
	Point startLocation = topElement.getLocation();
	if (orientation.equalsIgnoreCase("PORTRAIT")) {

	    ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, startLocation.x,
		    startLocation.y, 0, 0,thresholdValue);

	} else if (orientation.equalsIgnoreCase("LANDSCAPE")) {
	    ScreenshotUtil.takeScreenshotAndCompareWithThreshold(imageName, startLocation.y,
		    0, 0, startLocation.x,thresholdValue);
	}
   }
    /**
     * Executes appium driver's TakesScreenshot and copy the file into the given
     * filePath
     * 
     * @param filePath
     * @throws Exception
     */
    public static void getScreenshot(File filePath) throws Exception {
	Driver driver = Driver.getInstance();
	WebDriver aug1 = (WebDriver) (new Augmenter().augment(driver.appy));
	File screenshot = ((TakesScreenshot) aug1)
		.getScreenshotAs(OutputType.FILE);
	// Copy the element screenshot to disk
	FileUtils.copyFile(screenshot, filePath, true);
    }
}