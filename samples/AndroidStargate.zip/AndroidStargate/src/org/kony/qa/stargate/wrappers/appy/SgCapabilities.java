/**
 * 
 */
package org.kony.qa.stargate.wrappers.appy;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;

import org.kony.qa.stargate.common.FileHelper;
import org.kony.qa.stargate.common.ImageCropper;
import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.common.StargateException;
import org.kony.qa.stargate.helpers.Common;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;

/**
 * SgCapabilities here lies the deciding params for AppiumDriver (e.g. Android
 * Vs iOS)
 * 
 * @author Kiran.Chava
 * 
 *         Why are we calling this SgCapabilities? why not simply capabilities?
 *         AppiumDriver inherently calls selenium DesiredCapabilities. But
 *         AppiumDriver java client some times calls Capabilities, some times
 *         calls DesiredCapabilities Not to add to flame to confusion we are
 *         calling this SgCapabilities.
 * 
 *         Driver.Init() requires this classes instance. Every test case needs
 *         to call this Driver.Init() - of course most of the times it is taken
 *         care by baseTest. We want to make as less painful as possible for the
 *         test case. Thus test case need to give only apk name as input - and
 *         rest of the inputs are automatically filled here in this
 *         SgCapabilities from SgConfig class.
 * 
 */
public class SgCapabilities {
	// Start of desired capabilities variables.
	// General advice, guidelines for future additions to this list of
	// variables.
	// We read most of them from sgconfig.properties via SgConfig.java
	// Keep same variable name in all three places to avoid confusion.
	// 1) this file 2) sgconfig.java 3) sgconfig.properties
	/*
	 * Note for future edits Make sure equals overridden function is handled
	 * after making changes to this variable set
	 */
	private boolean isAlwaysRunOnDevice;
	private String url;
	private String appWithRelativePath;
	private String pathToApkRootDir;
	private String mobileOS = "Android";
	private String platformOS;
	private String mobilePlatformName;
	private String androidDeviceName;
	private String udid;
	private String androidVersion;
	private String packageName;
	private String activityName;
	private String bundleId;
	private String optionalIntentArguments;
	private String defaultOrientation;
	// End of desired capabilities variables.

	// ScreenshotUtil related variables
	private String baselineFolderPath;
	private String actualFolderPath;
	private String diffFolderPath;
	private String errorFolderPath;
	// This is where we store deviceName based upon other inputs.
	private String deviceName;

	// when isForce = true, then we always init AppiumDriver inspite of same
	// capabilities for next testcase
	private boolean force = false;
	// Dynamically taking the extension without waiting for user to send. eg:
	// .apk or .app or .ipa or .zip
	private String appExtension = null;
	private boolean autoLaunch = true;
	private boolean noReset = false;
	private boolean fullReset = false;

	public static int iosScreenResolutionFactor = 1;

	public String getIOSDeviceType() {
		return "none";
	}

	public boolean isAndroid() {
		return true;
	}

	// Public variables.
	/**
	 * ideally this must be same as screen resolution returned by AppiumDriver.
	 * Alas, we are not living in an ideal world. SPA this is size of inner
	 * browser. iOS emulator there is no relationship. screenShot size is way
	 * bigger.
	 */
	public int screenshotFullImageWidth, screenshotFullImageHeight;

	// Constructor
	/**
	 * Constructor 2 This is parameter less constructor. Except
	 * appWithRelativePath, packageName, activityName - we initialize other
	 * variables from sgconfig.properties file. A test case can overwrite them
	 * if required via setters. If we are initializing via this constructor make
	 * sure you use setters to set required params (if not read by this class
	 * from SgConfig). Recommended to use other constructor for all UI tests.
	 */
	public SgCapabilities() throws Exception {
		this.init();
	}

	public static boolean amIWindowsRC() {
		return false;
	}

	public static boolean amIOnBrowser() {
		return false;
	}

	public static boolean amIOnAndroidRichClient() {
		return true;
	}

	public boolean isWindowsRC() {
		return false;
	}

	public String getBrowser() {
		return "none";
	}

	public static boolean amIOnRichClient() {
		return true;
	}

	public static boolean amIAndroid() {
		return true;
	}

	public static boolean amIOnIOSRichClient() {
		return false;
	}

	public boolean isDesktop() {
		return false;
	}

	public boolean isIOS() {
		return false;
	}

	public boolean isSPA() {
		return false;
	}

	public boolean isSPAAndroid() {
		return false;
	}

	/**
	 * Extra variable init goes here. This must be called post Driver init
	 * 
	 * @throws Exception
	 */
	private void extraInit() throws Exception {
		// This is where we initialize some extra variables.
		// Initialize screenshotFullImageSizes
		try {
			String imageName = "testScreenshotFromSgCapabilities";

			String inputFileLocation;

			inputFileLocation = FileHelper.combinePaths(SgConfig.getInstance().getScreenshotsRootDirectory(),
					imageName + "." + SgConfig.getInstance().getImageExtension());
			File inputFile = new File(inputFileLocation);

			ScreenshotUtil.getScreenshot(inputFile);
			BufferedImage originalImage = ImageCropper.readImage(inputFileLocation);
			screenshotFullImageWidth = originalImage.getWidth();
			screenshotFullImageHeight = originalImage.getHeight();

		} catch (Exception e) {
			// We don't want all tests fail, if we cannot take a screenshot
			// Let us put a warning and continue
			SgLog.warn("Unable to test Screenshot. If your test is using screenshot functionality it may fail");
		}
	}

	// Constructor with params (overloaded)
	/**
	 * Constructor 1 Use this for all UI testing. Apart from the three params
	 * here, we will read rest of params from sgconfig.properties file. A test
	 * case can overwrite them if required, via setters.
	 * 
	 * @param appWithRelativePath
	 * @param packageName
	 * @param activityName
	 */
	public SgCapabilities(String appWithRelativePath, String packageName, String activityName, String bundleId,
			String alwaysRunOnIosDevice) throws Exception {

		// Validations.
		if (appWithRelativePath == null) {
			throw new Exception(
					"appWithRelativePath cannot be null. If you are not using this varialble then call other constructor");
		}
		// Validations completed.
		// Set given params.
		this.mobileOS = "Android";
		this.mobilePlatformName = "Android";
		this.setappWithRelativePath(appWithRelativePath);
		this.setPackageName(packageName);
		this.setActivityName(activityName);
		this.setBundleId(bundleId);
		this.setIsAlwaysRunOnDevice(alwaysRunOnIosDevice);
		// Init rest of params from SgConfig
		this.init();
	}

	/*
	 * Why are we reading these values from sgconfig? why not directly from
	 * sgconfig.properties? SgConfig is a singleton class. But this
	 * SgCapabilities instances are created everytime a new test is about to
	 * start. Going to IO for sgconfig.properties file is a bad idea for
	 * performance. Moreover we could have other Stargate specific configuration
	 * parameters not required by this class. sgconfig will be one place to go
	 * for all user-specific-config varialbles.
	 */
	private void init() throws Exception {

		SgConfig sgConfig = SgConfig.getInstance();
		this.setUrl(sgConfig.getUrl());
		this.pathToApkRootDir = sgConfig.getPathToApkRootDir();
		this.platformOS = sgConfig.getPlatformOS();
		this.androidDeviceName = sgConfig.getAndroidDeviceName();
		this.udid = sgConfig.getUdid();
		this.androidVersion = sgConfig.getAndroidVersion();
		this.force = sgConfig.isForce();
		this.autoLaunch = sgConfig.getAutoLaunch();
		this.noReset = sgConfig.getNoReset();
		this.fullReset = sgConfig.getFullReset();
		initDefaultOrientation();
		initDeviceName();
		this.optionalIntentArguments = sgConfig.getOptionalIntentArguments();

	}

	/**
	 * We need driver instance to initialize these values. For example to get
	 * Screen resolution.
	 * 
	 * @throws Exception
	 */
	public void initPostDriver() throws Exception {
		this.setToDefaultOrientation();
		this.extraInit();
		// ScreenshotUtil params.
		this.setErrorimageDirectory();
		this.setBaselineImageDirectory();
		this.setActualImageDirectory();
		this.setDiffImageDirectory();

	}

	public void getPageSource() throws Exception {
		PrintStream out = new PrintStream(new FileOutputStream("output.txt"));
		System.setOut(out);
		WebDriver driver = Driver.getInstance().appy;
		System.out.println(driver.getPageSource());
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	}

	public void setToDefaultOrientation() throws Exception {
		// sets the display to default orinetation given by the user in sgconfig
		// properties.
		if (this.defaultOrientation.equalsIgnoreCase("NULL")) {
			return;
		}
		Gestures.setOrientation(this.defaultOrientation);
	}

	private void initDefaultOrientation() throws Exception {
		String orientation = SgConfig.getInstance().getDefaultOrientation();
		switch (orientation.toUpperCase()) {
		case "NULL":
			this.defaultOrientation = orientation;
			break;
		case "LANDSCAPE":
			this.defaultOrientation = orientation;
			break;
		case "PORTRAIT":
			this.defaultOrientation = orientation;
			break;
		default:
			throw new StargateException("NULL,PORTRAIT,LANDSCAPE" + " are the valid values for orientation");
		}
	}

	private void initDeviceName() {
		this.deviceName = this.androidDeviceName;
	}

	public DesiredCapabilities getDesiredCapabilities() throws Exception {

		File app = null;
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		// We are mobile, not desktop or Windows Phone
		// Thou shalt not trust any input! Validate them.
		this.appExtension = ".apk";

		app = new File(FileHelper.combinePaths(pathToApkRootDir, appWithRelativePath + appExtension));
		if (!FileHelper.isFileExists(app.getAbsolutePath().toString())) {
			this.appExtension = ".app";
			app = new File(FileHelper.combinePaths(pathToApkRootDir, appWithRelativePath + appExtension));

		}

		mobileOS = "Android";

		desiredCapabilities.setCapability("platformName", mobileOS);
		// checking if androidCodeCoverage value is set to true
		// if the value is set then we are adding a capability
		if (SgConfig.getInstance().getAndroidCodeCoverage()) {
			desiredCapabilities.setCapability("androidCoverage", SgConfig.getInstance().getAndroidCoverage());
		}
		desiredCapabilities.setCapability(CapabilityType.PLATFORM, platformOS.toUpperCase());
		desiredCapabilities.setCapability("newCommandTimeout", 60000);
		desiredCapabilities.setCapability("autoLaunch", autoLaunch);
		desiredCapabilities.setCapability("noReset", noReset);
		desiredCapabilities.setCapability("fullReset", fullReset);

		desiredCapabilities.setCapability("deviceName", androidDeviceName);
		desiredCapabilities.setCapability("platformVersion", androidVersion);
		desiredCapabilities.setCapability("app", app.getAbsolutePath());
		desiredCapabilities.setCapability("appPackage", packageName);
		desiredCapabilities.setCapability("appActivity", activityName);
		desiredCapabilities.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY, activityName);
		// If optionalIntentArguments are not NONE then pass them
		if (!optionalIntentArguments.toUpperCase().equals("NONE")) {
			desiredCapabilities.setCapability("optionalIntentArguments", optionalIntentArguments);
		}
		return desiredCapabilities;
	}

	public boolean isReInitRequired(SgCapabilities sgCapabilitiesNew) throws Exception {
		try {
			boolean isCodeCoverageRequired = SgConfig.getInstance().androidCodeCoverage;
			if (sgCapabilitiesNew.isForce() == true) {
				// When force is set we always reinit
				if (isCodeCoverageRequired) {
					// ((AppiumDriver) Driver.getInstance().appy).closeApp();
					((AppiumDriver) Driver.getInstance().appy).sendKeyEvent(AndroidKeyCode.HOME);
				}
				return true;
			}
			if (sgCapabilitiesNew.fullReset == true) {
				// When force is set we always reinit
				if (isCodeCoverageRequired) {
					// ((AppiumDriver) Driver.getInstance().appy).closeApp();
					((AppiumDriver) Driver.getInstance().appy).sendKeyEvent(AndroidKeyCode.HOME);
				}
				return true;
			}
			if (!this.equals(sgCapabilitiesNew)) {
				if (isCodeCoverageRequired) {
					// ((AppiumDriver) Driver.getInstance().appy).closeApp();
					((AppiumDriver) Driver.getInstance().appy).sendKeyEvent(AndroidKeyCode.HOME);
				}
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return true;
		}
	}

	@Override
	public boolean equals(Object other) {
		// SgLog throws we cannot mark equals as throws thus try catch is forced
		try {
			if (other == null) {
				return false;
			}
			if (this == other) {

				return true; // Same instance reference.
			}
			if (!(other instanceof SgCapabilities)) {
				return false;
			}
			// proceed to caste
			SgCapabilities sgCapabilitiesNew = (SgCapabilities) other;

			// Check each variable

			if (!this.appWithRelativePath.equals(sgCapabilitiesNew.getappWithRelativePath())) {
				return false;
			}
			if (!this.activityName.equals(sgCapabilitiesNew.getActivityName())) {
				return false;
			}
			if (!this.pathToApkRootDir.equals(sgCapabilitiesNew.getPathToApkRootDir())) {
				return false;
			}
			if (!this.url.equals(sgCapabilitiesNew.getUrl())) {
				return false;
			}
			if (!this.mobileOS.equals(sgCapabilitiesNew.getMobileOS())) {
				return false;
			}
			if (!this.platformOS.equals(sgCapabilitiesNew.getPlatformOS())) {
				return false;
			}
			if (!this.mobilePlatformName.equals(sgCapabilitiesNew.getMobilePlatformName())) {
				return false;
			}

			if (!this.androidDeviceName.equals(sgCapabilitiesNew.getAndroidDeviceName())) {
				return false;
			}

			if (!this.udid.equals(sgCapabilitiesNew.getUdid())) {
				SgLog.info("udid is not equal. ");
				return false;
			}
			if (!this.androidVersion.equals(sgCapabilitiesNew.getAndroidVersion())) {
				return false;
			}

			if (!this.packageName.equals(sgCapabilitiesNew.getPackageName())) {
				return false;
			}

		} catch (Exception e) {
			// SgLog thrown an exception.
			return false;
		}

		return true;
	}

	/**
	 * returns true if capabilities are set to SPA. Otherwise false. We do not
	 * actually know what the given app is built for what device we run. We only
	 * depend upon Sgconfig properties we received.
	 * 
	 * @return true if SPA else false.
	 */

	// Region getters and setters start
	/**
	 * @return the appWithRelativePath
	 */
	public String getappWithRelativePath() {
		return appWithRelativePath;
	}

	/**
	 * @param appWithRelativePath
	 *            the appWithRelativePath to set
	 */
	public void setappWithRelativePath(String appWithRelativePath) {
		this.appWithRelativePath = appWithRelativePath;
	}

	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * @param packageName
	 *            the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * @return the activityName
	 */
	public String getActivityName() {
		return activityName;
	}

	/**
	 * @param activityName
	 *            the activityName to set
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * 
	 * @param bundleId
	 *            --- It should be something like com.kony.*
	 */
	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getBundleId() {
		return bundleId;
	}

	/**
	 * 
	 * @param isAlwaysRunOnDevice
	 */
	public void setIsAlwaysRunOnDevice(String isAlwaysRunOnDevice) {
		if (isAlwaysRunOnDevice.toUpperCase().equals("TRUE")) {
			setIsAlwaysRunOnDevice(true);
		} else if (isAlwaysRunOnDevice.toUpperCase().equals("FALSE")) {
			setIsAlwaysRunOnDevice(false);
		} else {
			System.out.println(
					"Warn:: isAlwaysRunOnDevice parametre is neither true nor false,cotinuing with default false value");
			setIsAlwaysRunOnDevice(false);
		}
	}

	/**
	 * 
	 * @param isAlwaysRunOnDevice
	 */
	public void setIsAlwaysRunOnDevice(boolean isAlwaysRunOnDevice) {
		this.isAlwaysRunOnDevice = isAlwaysRunOnDevice;
	}

	public boolean getIsAlwaysRunOnDevice() {
		return isAlwaysRunOnDevice;
	}

	// Region getters and setters End
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the pathToApkRootDir
	 */
	public String getPathToApkRootDir() {
		return pathToApkRootDir;
	}

	/**
	 * @param pathToApkRootDir
	 *            the pathToApkRootDir to set
	 */
	public void setPathToApkRootDir(String pathToApkRootDir) {
		this.pathToApkRootDir = pathToApkRootDir;
	}

	/**
	 * @return the mobileOS
	 */
	public String getMobileOS() {
		return mobileOS;
	}

	/**
	 * @param mobileOS
	 *            the mobileOS to set
	 */
	public void setMobileOS(String mobileOS) {
		this.mobileOS = mobileOS;
	}

	/**
	 * @return the platformOS
	 */
	public String getPlatformOS() {
		return platformOS;
	}

	/**
	 * @param platformOS
	 *            the platformOS to set
	 */
	public void setPlatformOS(String platformOS) {
		this.platformOS = platformOS;
	}

	/**
	 * @return the mobilePlatformName
	 */
	public String getMobilePlatformName() {
		return mobilePlatformName;
	}

	/**
	 * @param mobilePlatformName
	 *            the mobilePlatformName to set
	 */
	public void setMobilePlatformName(String mobilePlatformName) {
		this.mobilePlatformName = mobilePlatformName;
	}

	/**
	 * @return the androidDeviceName
	 */
	public String getAndroidDeviceName() {
		return androidDeviceName;
	}

	/**
	 * @param androidDeviceName
	 *            the androidDeviceName to set
	 */
	public void setAndroidDeviceName(String androidDeviceName) {
		this.androidDeviceName = androidDeviceName;
	}

	/**
	 * @return the androidVersion
	 */
	public String getAndroidVersion() {
		return androidVersion;
	}

	/**
	 * @param androidVersion
	 *            the androidVersion to set
	 */
	public void setAndroidVersion(String androidVersion) {
		this.androidVersion = androidVersion;
	}

	/**
	 * @return the isForce
	 */
	public boolean isForce() {
		return force;
	}

	/**
	 * @param isForce
	 *            the isForce to set
	 */
	public void setForce(boolean force) {
		this.force = force;
	}

	/**
	 * returns baselineFolderPath
	 * 
	 * @return baselineFolderPath
	 * @throws Exception
	 */
	public String getBaselineImageDirectory() throws Exception {
		return baselineFolderPath;
	}

	/**
	 * returns actualFolderPath
	 * 
	 * @return actualFolderPath
	 * @throws Exception
	 */
	public String getActualImageDirectory() {
		return actualFolderPath;
	}

	/**
	 * returns diffFolderPath
	 * 
	 * @return diffFolderPath
	 * @throws Exception
	 */
	public String getDiffImageDirectory() throws Exception {
		return diffFolderPath;
	}

	/**
	 * returns errorFolderPath
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getErrorImageDirectory() throws Exception {
		return errorFolderPath;
	}

	/**
	 * Creates and sets the actual images directory to the actualFolderPath
	 * 
	 * @throws Exception
	 */
	public void setActualImageDirectory() throws Exception {
		SgConfig sgConf = SgConfig.getInstance();
		if (sgConf.getPlatformOS().toUpperCase() != "LINUX") {
			Dimension resolution = Driver.getScreenResolution();
			this.actualFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator + "actual" + File.separator
					+ mobilePlatformName + File.separator + deviceName + File.separator;

			this.actualFolderPath += appWithRelativePath + File.separator + resolution.width + "By" + resolution.height;
			String Orientation = Driver.getInstance().getOrientation();
			if (Orientation.equalsIgnoreCase("landscape")) {
				this.actualFolderPath += File.separator + "Landscape";
			}
			this.actualFolderPath += File.separator + sgConf.getScreenshotPrefixFolder() + File.separator;

		} else {
			sgConf.setScreenshotsRootDirectory(
					System.getProperty("appium.screenshots.dir", System.getProperty("java.io.tmpdir", "")));
			this.actualFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator;
		}
	}

	/**
	 * Creates and sets the diff images directory to the diffFolderPath
	 * 
	 * @throws Exception
	 */
	public void setDiffImageDirectory() throws Exception {
		SgConfig sgConf = SgConfig.getInstance();
		if (sgConf.getPlatformOS().toUpperCase() != "LINUX") {
			Dimension resolution = Driver.getScreenResolution();
			this.diffFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator + "diff" + File.separator
					+ mobilePlatformName + File.separator + deviceName + File.separator;

			this.diffFolderPath += appWithRelativePath + File.separator + resolution.width + "By" + resolution.height;
			String Orientation = Driver.getInstance().getOrientation();
			if (Orientation.equalsIgnoreCase("landscape")) {
				this.diffFolderPath += File.separator + "Landscape";
			}
			this.diffFolderPath += File.separator + sgConf.getScreenshotPrefixFolder() + File.separator;

		} else {
			sgConf.setScreenshotsRootDirectory(
					System.getProperty("appium.screenshots.dir", System.getProperty("java.io.tmpdir", "")));
			this.diffFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator;
		}
	}

	/**
	 * Creates and sets the error/skip images directory to errorFolderPath
	 * 
	 * @throws Exception
	 */
	public void setErrorimageDirectory() throws Exception {
		SgConfig sgConf = SgConfig.getInstance();
		Dimension resolution = Driver.getScreenResolution();
		this.errorFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator + "error" + File.separator
				+ mobilePlatformName + File.separator + deviceName + File.separator;

		this.errorFolderPath += appWithRelativePath + File.separator + resolution.width + "By" + resolution.height;
		String Orientation = Driver.getInstance().getOrientation();
		if (Orientation.equalsIgnoreCase("landscape")) {
			this.errorFolderPath += File.separator + "Landscape";
		}
		this.errorFolderPath += File.separator + sgConf.getScreenshotPrefixFolder() + File.separator;

	}

	/**
	 * Creates and sets the baseline images directory to the baselineFolderPath
	 * 
	 * @throws Exception
	 */
	public void setBaselineImageDirectory() throws Exception {
		SgConfig sgConf = SgConfig.getInstance();
		if (sgConf.getPlatformOS().toUpperCase() != "LINUX") {
			Dimension resolution = Driver.getScreenResolution();
			this.baselineFolderPath = sgConf.getScreenshotsRootDirectory() + File.separator + "baseline"
					+ File.separator + mobilePlatformName + File.separator + deviceName + File.separator;

			this.baselineFolderPath += appWithRelativePath + File.separator + resolution.width + "By"
					+ resolution.height;
			String Orientation = Driver.getInstance().getOrientation();
			if (Orientation.equalsIgnoreCase("landscape")) {
				this.baselineFolderPath += File.separator + "Landscape";
			}
			this.baselineFolderPath += File.separator + sgConf.getScreenshotPrefixFolder() + File.separator;

		} else {
			String baseAddress = Common.executeCommandWithConsoleOPReturn("pwd");
			this.baselineFolderPath = baseAddress + File.separator + sgConf.getScreenshotPrefixFolder()
					+ File.separator;
		}
	}

	/**
	 * @return the optionalIntentArguments
	 */
	public String getOptionalIntentArguments() {
		return optionalIntentArguments;
	}

	/**
	 * @param optionalIntentArguments
	 *            the optionalIntentArguments to set
	 */
	public void setOptionalIntentArguments(String optionalIntentArguments) {
		this.optionalIntentArguments = optionalIntentArguments;
	}

	public String getUdid() {
		return udid;
	}

	public void setUdid(String udid) {
		this.udid = udid;
	}

	/**
	 * returns true on real device. that is not simulator, not emulator note:
	 * for android we depend upon sgconfig.androidDeviceType and for iOS we
	 * depend upon udid = null or not
	 * 
	 * @return
	 * @throws Exception
	 */
	public static boolean amIRealDevice() throws Exception {
		Driver driver = Driver.getInstance();
		if (driver.sgCapabilities.getAndroidDeviceName().equalsIgnoreCase("Real Device")) {
			return true;
		}
		return false;
	}
}