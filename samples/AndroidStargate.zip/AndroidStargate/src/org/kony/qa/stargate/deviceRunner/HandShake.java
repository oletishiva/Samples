/**
 * 
 */
package org.kony.qa.stargate.deviceRunner;

import java.util.List;

import org.kony.qa.stargate.common.Constants;
import org.kony.qa.stargate.logger.SgLog;
import org.kony.qa.stargate.wrappers.appy.Gestures;
import org.kony.qa.stargate.wrappers.appy.Keyboard;
import org.kony.qa.stargate.wrappers.appy.SgElement;
import org.kony.qa.stargate.common.StargateException;

/*
 * HOW TO INCLUDE REGSUITE COUNTERPART  (in kony studio) 
 * 1. copy paste the form : frmSgRun (to mobile, tablet, Desktop)  (do not edit this)
 * 2. copy paste sgdrRunHandle.js in modules (do not edit this) 
 * 3. copy paste sgdrRuntests.js (This is where we write our tests) 
 * 4. Add SgDR menuItem on clicking it it must take us to frmSgRun
 */
/**
 * This is platform side (Windows/Mac) for our StargateDeviceRunner
 * 
 * There are two primary ways we can test a test case scenario.
 * 
 * a) Perform something on device and validate it from Platform. (Either by
 * screenshot comparison or some other way)
 * 
 * b) Perform something on device and also validate the same on device. Platform
 * will simply read Log and result (pass/fail/notrun/not applicable)
 * 
 * This deviceRunner package and Trigger class are going to be counterparts for
 * StargateDeviceRunner regsuite counterpart.
 * 
 * This class will 1) <strong>Initiate</strong> given automation ID, 2)
 * <strong>Waits</strong> for StargateDeviceRunner to complete test or for
 * timeout 3) <strong> Updates result </strong> and updates Log.
 * 
 * @author Kiran.Chava
 *
 */
public class HandShake {

    private String automationID = null;
    private int timeout = 5 * 60 * 60 * 1000; // in milliseconds (five minutes)
    private SgElement statusElement = null;
    private SgElement logElement = null;

    public HandShake(String automationID) {
	this.automationID = automationID;
    }

    /**
     * How this works? Look at StargateDeviceRunner screenshot at
     * Java\doc\StargateDeviceRunnerScreenshotv1DotZero.jpeg 1) We click on
     * Reset (In case the fields are used by previous test case we reset them)
     * 2) We fill automation ID in first textbox - 3) click on run button 4) We
     * wait for the result to complete. (Result is updated in a label Not
     * Started --> In Progress --> Completed) or the timeout. 5) Read result
     * from radio buttons. Read Log from text area.
     * 
     */
    public void Go() throws Exception {
	beOnStargateDeviceRunnerForm();
	reset(); // step 1
	enterAutomationID(); // step2
	runTheTest(); // step3
	waitForCompletion(); // step4
	getResultFromDevice(); // step5
    }

    private void beOnStargateDeviceRunnerForm() throws Exception {
	if (amIOnStartgateDeviceRunnerForm()) {
	    return; // We are already on StargateDeviceRunner form.
	}
	// Click menu and then click SgDR
	Gestures.pressMenuItem("SgDR");
    }

    /*
     * How this works? We check whether we have a title "Stargate Device Runner
     * v1.0" or not.
     */
    private boolean amIOnStartgateDeviceRunnerForm() throws Exception {
	return SgElement
		.isElementVisible("name", "Stargate Device Runner v1.0");
    }

    // Simply clicks on Run button.
    // rest is taken care by StargateDeviceRunner
    private void runTheTest() throws Exception {
	Gestures.clickByName("Run");
    }

    /*
     * How this works? We check status from label (textview) a) Not Started b)
     * In Progress c) Completed
     */
    private void waitForCompletion() throws Exception {
	do {
	    Thread.sleep(Constants.SHORT_DELAY); // 1sec ?
	    timeout -= 1000;
	    // Do few more tasks if we are on StargateDeviceRunner form.
	    if (amIOnStartgateDeviceRunnerForm()) {
		// getLogFromDevice(); // ideally we should get log from time to
		// time
		// but for some reason we are failing if we do this more than
		// once
		// Let the test fail.
		if (isTestCompleted()) {
		    getLogFromDevice(); // final log
		    return;
		}
	    }
	} while (timeout > 0);
	SgLog.error("Timeout reached when we are waiting StargateDeviceRunner to complete test execution.");
	// Anyhow we are going to fail the test case - just check if by
	// any chance The regsuite completed running but failed to move the form
	// back.
	SgLog.info("Moving the form to StargateDeviceRunner to get Log, if any");
	beOnStargateDeviceRunnerForm();
	// getLogFromDevice(); // ideally we should get log from time to time
	// but for some reason we are failing if we do this more than once
	// Let the test fail.
	throw new StargateException(
		"Timeout reached when we are waiting for StargateDeviceRunner to complete test execution");
    }

    private void getResultFromDevice() throws Exception {
	if (!amIOnStartgateDeviceRunnerForm()) {
	    throw new StargateException(
		    "getResultFromDevice is called. But we are not on StargateDeviceRunner form on regsuite.");
	}
	List<SgElement> radioButtonElements = SgElement.getSgElements("class",
		"android.widget.RadioButton");
	for (SgElement sgEle : radioButtonElements) {
	    String resultFromDevice = sgEle.getText();
	    // Android doesn't support isSelected?
	    if (!sgEle.isChecked()) {
		SgLog.verbose(resultFromDevice
			+ " is not selected. Trying next one");
		continue;
	    } else {
		SgLog.info("Result is " + resultFromDevice);
	    }
	    // If pass - then we don't throw exception.
	    // For all results, we throw
	    // assuming testNG is going be sole client?
	    switch (resultFromDevice.toUpperCase()) {
	    case "PASS":
		// Nothing to be done.
		return;
	    case "FAIL":
		throw new StargateException("FAIL");
	    case "NOT RUN":
		throw new StargateException("NOT RUN");
	    case "NOT APPLICABLE":
		throw new StargateException("NOT APPLICABLE");
	    default:
		throw new StargateException(
			"Unexpected radio button on Stargate Device Runner. Only pass/fail/not run /not applicable are expected. Current one: "
				+ resultFromDevice);
	    }

	}
	throw new StargateException(
		"getResultFromDevice is called. But none of pass/fail/not run/ not applicable radio buttons are selected");
    }

    private boolean isTestCompleted() throws Exception {
	String currentStatus = statusElement.getText();
	SgLog.info("StargateDeviceRunner current status is : " + currentStatus);
	if (currentStatus.toUpperCase().equals("COMPLETED")) {
	    return true;
	}
	return false;
    }

    private void enterAutomationID() throws Exception {
	Keyboard.typeText("class", "android.widget.EditText", automationID);

    }

    private void reset() throws Exception {
	// All we do is click on a button named Reset.
	// This button click event will call a JS function in regusite built
	// from Kony Studio. That will take care of actual reset. This reset
	// will make sure previous test case results are wiped out from
	// StargateDeviceRunner widgets.

	Gestures.clickByName("Reset");

	// Initialize elements again
	initStatusElement();
	// Now status must be Not Started.
	String status = statusElement.getText();
	if (!status.equalsIgnoreCase("NOT STARTED")) {
	    throw new StargateException(
		    "Something is wrong! After resetting, "
			    + "the status label is not as, expected = Not Started. Actual = "
			    + status);
	}

	// Initialize Log Element
	logElement = SgElement.getSgElementMultiLocator("class",
		"android.widget.TextView", "name", "Log comes here");

    }

    private void initStatusElement() throws Exception {
	List<SgElement> sgElements = SgElement.getSgElements("class",
		"android.widget.TextView");
	for (SgElement sgEle : sgElements) {
	    String text = sgEle.getText();
	    if (text.equalsIgnoreCase("NOT STARTED")
		    || text.equalsIgnoreCase("IN PROGRESS")
		    || text.equalsIgnoreCase("COMPLETED")) {
		statusElement = sgEle;
		return;
	    }
	}

	throw new StargateException("Unable to find status label element");
    }

    private void getLogFromDevice() throws Exception {
	SgLog.info(logElement.getText());
	// Known Issue: We might loose some log in between above and below
	// lines. These are not atomic. Any better way to do this?
    }

    /**
     * @return the automationID
     */
    public String getAutomationID() {
	return automationID;
    }

    /**
     * @param automationID
     *            the automationID to set
     */
    public void setAutomationID(String automationID) {
	this.automationID = automationID;
    }

    /**
     * @return the timeout
     */
    public int getTimeout() {
	return timeout;
    }

    /**
     * @param timeout
     *            the timeout to set
     */
    public void setTimeout(int timeout) {
	this.timeout = timeout;
    }
}
