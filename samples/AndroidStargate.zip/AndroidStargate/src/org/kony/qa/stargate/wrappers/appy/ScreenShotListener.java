/**Modified by Rahul.kumar on : 2014/09/19 
 * 			Modified <function>takeScreenshotOnError</function> .Screenshot will be taken on Skip/Failure
 *         of test case , images will go to Error folder of Screenshots
 */

package org.kony.qa.stargate.wrappers.appy;

import java.io.File;
import java.util.Calendar;

import org.kony.qa.stargate.common.SgConfig;
import org.kony.qa.stargate.logger.SgLog;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.annotations.Test;

/**
 * 
 * @author venkat.saddala
 *
 * 
 */
public class ScreenShotListener extends TestListenerAdapter implements
	WebDriverEventListener {

    /**
     * It takes a Screenshot On faiure/Skip of Any test case
     * 
     * @param testName
     */
    public static void takeScreenshotOnError(String testName) {
	try {
	    if (Driver.isDriverInitialized() == false) {
		SgLog.warn("taking screenshot is not supported, as driver is not yet "
			+ "initialized. Most probably test case failed in config");
		return;
	    }
	    Driver driver = Driver.getInstance();
	    // Image Name of error Image
	    String errorImage = driver.sgCapabilities.getErrorImageDirectory()
		    + testName + "."
		    + SgConfig.getInstance().getImageExtension();
	    new File(driver.sgCapabilities.getErrorImageDirectory()).mkdir();
	    ScreenshotUtil.executeTakeScreenshot(errorImage);
	    // upload error image to budha
	    SgLog.logImageToBudha(1, errorImage, testName + "."
		    + SgConfig.getInstance().getImageExtension(),
		    "ERROR image on FAIL");
	} catch (Exception e) {
	    // Driver.getinstance() being called before launch of App , no
	    // Screenshot to take
	    SgLog.error("Cannot take Screenshot onError ,Calling Driver before launch of the app");
	    SgLog.printStackTrace(e);
	}
    }

    public void onConfigurationFailure(ITestResult result) {
	/*
	 * String fileName = generateFilename(result);
	 * takeScreenshotOnError("CONFIGURATIONMETHOD_" + fileName);
	 */
    }

    /**
     * This method is called on failure of test case
     */
    @Override
    public void onTestFailure(ITestResult result) {
	// Getting filenName from the method the fail has occured
	String fileName = generateFilename(result);
	takeScreenshotOnError(fileName);
    }

    /**
     * This method is called on Skip of test case
     */
    @Override
    public void onTestSkipped(ITestResult result) {
	String fileName = generateFilename(result);
	takeScreenshotOnError("SKIPPED_" + fileName);
    }

    @Override
    public void onException(Throwable exe, WebDriver driver) {
	String fileName = generateExceptionFilename(exe);
	takeScreenshotOnError(fileName);
    }

    private String generateExceptionFilename(Throwable arg0) {
	Calendar c = Calendar.getInstance();
	String filename = arg0.getMessage();
	int i = filename.indexOf('\n');
	filename = filename.substring(0, i).replaceAll("\\s", "_")
		.replaceAll(":", "");

	filename = "" + c.get(Calendar.YEAR) + "-" + c.get(Calendar.MONTH)
		+ "-" + c.get(Calendar.DAY_OF_MONTH) + "-"
		+ c.get(Calendar.HOUR_OF_DAY) + "-" + c.get(Calendar.MINUTE)
		+ "-" + c.get(Calendar.SECOND) + "-" + filename;
	return filename;
    }

    /**
     * This method generate a fileName cotaining , GroupId , method Name and
     * DateTime *Caution* : If there will be mutiple group Id for one method ,
     * we'll have to modify this function , for now single group Id is given
     * 
     * @param result
     * @return
     */
    private String generateFilename(ITestResult result) {
	Calendar c = Calendar.getInstance();
	// Getting all the groups from the called method
	String[] groupsOfTheTestCase = result.getMethod()
		.getConstructorOrMethod().getMethod().getAnnotation(Test.class)
		.groups();
	String filename = "";
	// Currently we are using just one group in each method
	for (String group : groupsOfTheTestCase) {
	    filename = group + "_" + result.getMethod().getMethodName();
	    filename = filename + "_" + c.get(Calendar.YEAR) + "-"
		    + c.get(Calendar.MONTH) + "-"
		    + c.get(Calendar.DAY_OF_MONTH) + "-"
		    + c.get(Calendar.HOUR_OF_DAY) + "-"
		    + c.get(Calendar.MINUTE) + "-" + c.get(Calendar.SECOND);
	}
	// filename will contain the groupId_methodName_DateTime
	return filename;
    }

    @Override
    public void afterChangeValueOf(WebElement arg0, WebDriver arg1) {

    }

    @Override
    public void afterClickOn(WebElement arg0, WebDriver arg1) {

    }

    @Override
    public void afterFindBy(By arg0, WebElement arg1, WebDriver arg2) {

    }

    @Override
    public void afterNavigateBack(WebDriver arg0) {

    }

    @Override
    public void afterNavigateForward(WebDriver arg0) {

    }

    @Override
    public void afterNavigateTo(String arg0, WebDriver arg1) {

    }

    @Override
    public void afterScript(String arg0, WebDriver arg1) {

    }

    @Override
    public void beforeChangeValueOf(WebElement arg0, WebDriver arg1) {

    }

    @Override
    public void beforeClickOn(WebElement arg0, WebDriver arg1) {

    }

    @Override
    public void beforeFindBy(By arg0, WebElement arg1, WebDriver arg2) {

    }

    @Override
    public void beforeNavigateBack(WebDriver arg0) {

    }

    @Override
    public void beforeNavigateForward(WebDriver arg0) {

    }

    @Override
    public void beforeNavigateTo(String arg0, WebDriver arg1) {

    }

    @Override
    public void beforeScript(String arg0, WebDriver arg1) {

    }
}
