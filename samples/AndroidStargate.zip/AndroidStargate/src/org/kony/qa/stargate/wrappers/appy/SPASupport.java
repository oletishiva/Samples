package org.kony.qa.stargate.wrappers.appy;

public class SPASupport {

    public static void getCroppedTopYValue() {

    }
}
