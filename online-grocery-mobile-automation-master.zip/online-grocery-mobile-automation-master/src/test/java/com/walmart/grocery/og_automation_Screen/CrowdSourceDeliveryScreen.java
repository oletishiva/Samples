package com.walmart.grocery.og_automation_Screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.walmart.grocery.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSTouchAction;

public class CrowdSourceDeliveryScreen extends ScreenBase {
	Dimension size = driver.manage().window().getSize();
	int x = size.getWidth() / 2;
	int starty = (int) (size.getHeight() / 2);
	int endy = (int) (size.getHeight() * 0.10);

	public CrowdSourceDeliveryScreen(AppiumDriver driver) {
		super(driver);
	}

	public void searchBeer()  {
		CrowdSourceDeliveryObjects csd = new CrowdSourceDeliveryObjects(driver);
		csd.Search.clear();
		csd.Search.sendKeys("beer" + "\n");
	}

	public void beerIncreaseDecreaseQuantity() {
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Plus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Plus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Minus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Minus\"]").click();
	}

	public void clickOnCart() {
		driver.findElementByAccessibilityId("Cart").click();
	}

	public void proceedForCheckout() {
		driver.findElementByAccessibilityId("Checkout").click();
		if (!driver.findElements(By.id("What if we’re out of an item?")).isEmpty()) {
			driver.findElementByAccessibilityId("icnCloseWht").click();

		} else if (!driver.findElements(By.name("Reservation Expired")).isEmpty()) {
			driver.findElementByName("OK").click();

		} else {
			System.out.println("passed");
		}
	}

	public void selectPickupSlot() {
		if (!driver.findElements(By.id("31")).isEmpty()) {
			driver.findElementByXPath(
					"//XCUIElementTypeOther[@name=\"BookSlot/SelectBookSlot\"]/XCUIElementTypeTable/XCUIElementTypeCell[1]")
					.click();
			driver.findElementByAccessibilityId("ContinueShoppingButton").click();

		} else if (!driver.findElements(By.name("Oops!")).isEmpty()) {
			driver.findElementByName("OK").click();
		} else if (!driver.findElements(By.id("Checkout")).isEmpty()) {
			driver.findElementByAccessibilityId("Checkout").click();
		} else if (!driver.findElements(By.id("What if we’re out of an item?")).isEmpty()) {
			driver.findElementByAccessibilityId("icnCloseWht").click();
		} else {
			System.out.println("passed");
		}
	}

	public void checkAlcoholDisclosure() {

		driver.performTouchAction(new IOSTouchAction(driver).press(x, starty).moveTo(x, -400).release());
		driver.findElementByAccessibilityId("ViewAlcoholDisclosureButton").click();
		driver.findElementByXPath("//XCUIElementTypeNavigationBar[@name=\"Alcohol Disclosure\"]/XCUIElementTypeButton")
				.click();
	}

	public void checkRadioButtonForBagAndAlochol(){
		driver.performTouchAction(new IOSTouchAction(driver).press(x, starty).moveTo(x, -400).release());
		driver.findElementByXPath("(//XCUIElementTypeButton[@name=\"cell unselected\"])[1]").click();
		driver.findElementByXPath("(//XCUIElementTypeButton[@name=\"cell unselected\"])[2]").click();
		// driver.findElementByClassName("XCUIElementTypeTextField").sendKeys("2222");
		// driver.findElementByAccessibilityId("OK").click();
	}
	
	public void placeOrder() throws InterruptedException {
		driver.findElementByAccessibilityId("PlaceOrderButton").click();
		Thread.sleep(2000);
	}

	
	public void orderConfirmation() {
		driver.findElementByAccessibilityId("Thanks for shopping with us!").isDisplayed();
		driver.findElementByAccessibilityId("close").click();
		System.out.println("Closing the order confirmation page !!!");
		

	}
	public void cancelThePlacedOrder() {
		driver.findElementByAccessibilityId("Account").click();
		driver.findElementByXPath("//XCUIElementTypeTable[@name=\"Account/Account\"]/XCUIElementTypeCell[3]").click();
		driver.findElementByAccessibilityId("Placed").click();
		driver.performTouchAction(new IOSTouchAction(driver).press(x, starty).moveTo(x, -400).release());
		driver.performTouchAction(new IOSTouchAction(driver).press(x, starty).moveTo(x, -400).release());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByAccessibilityId("Cancel Order").click();
		driver.findElementByAccessibilityId("Yes").click();
		System.out.println("order is cancelled");
	}
	
	public void addAllItemsToCart() throws InterruptedException {
		driver.findElementByAccessibilityId("Add all items to cart").click();
		Thread.sleep(5000);
	}
	
	public void smokeTestSearchBeer() {
		CrowdSourceDeliveryObjects csd = new CrowdSourceDeliveryObjects(driver);
		csd.Search.click();
		csd.Search.sendKeys("Beer" + "\n");
	}
	public void smokeTestIncreaseDecreaseQuantity() {
		CrowdSourceDeliveryObjects csd = new CrowdSourceDeliveryObjects(driver);
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Plus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Plus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Minus\"]").click();
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Amount/Minus\"]").click();
	}

	public void smokeTestClickOnCart() {
		driver.findElementByAccessibilityId("Cart").click();
	}

	public void smokeTestCheckoutAlcohol() {
		driver.findElementByAccessibilityId("Checkout").click();
		if (!driver.findElements(By.id("What if we’re out of an item?")).isEmpty()) {
			driver.findElementByAccessibilityId("icnCloseWht").click();

		} else if (!driver.findElements(By.name("Reservation Expired")).isEmpty()) {
			driver.findElementByName("OK").click();

		} else {
			System.out.println("passed");
		}

	}

	public void smokeTestSelectSlot() {
		if (!driver.findElements(By.id("4")).isEmpty()) {
			driver.findElementByXPath("//XCUIElementTypeOther[@name=\"Sunday, the 4th, \"]").click();
			driver.findElementByXPath("//XCUIElementTypeOther[@name=\"BookSlot/SelectBookSlot\"]/XCUIElementTypeTable/XCUIElementTypeCell[1]").click();
			driver.findElementByAccessibilityId("ContinueShoppingButton").click();

		} else if (!driver.findElements(By.name("Oops!")).isEmpty()) {
			driver.findElementByName("OK").click();
		} else if (!driver.findElements(By.id("Checkout")).isEmpty()) {
			driver.findElementByAccessibilityId("Checkout").click();
		} else if (!driver.findElements(By.id("What if we’re out of an item?")).isEmpty()) {
			driver.findElementByAccessibilityId("icnCloseWht").click();
		} else {
			System.out.println("passed");
		}
	}
	public  void smokeTestcheckForCoachScreen() {
		if (!driver.findElements(By.id("What if we’re out of an item?")).isEmpty()) {
			driver.findElementByAccessibilityId("icnCloseWht").click();
		} else {
			System.out.println("passed");
		}
	}

}
