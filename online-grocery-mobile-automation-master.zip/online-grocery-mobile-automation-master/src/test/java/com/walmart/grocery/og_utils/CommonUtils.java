package com.walmart.grocery.og_utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.sun.jna.CallbackParameterContext;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSTouchAction;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

public class CommonUtils {

	public static int IMPLICIT_WAIT;
	public static int APPIUM_SERVER_PORT;
	public static String APPLICATION_APP;
	public static String UDID;
	public static String AUTOMATION_XCUITEST;
	public static String BROWSER_NAME;
	public static String PLATFORM_NAME;
	public static String DEVICE_NAME;
	public static String PLATFORM_VERSION;
	public static Properties prop = new Properties();
	public static DesiredCapabilities capabilities = new DesiredCapabilities();
	public static URL serverURl;
	public static AppiumDriver driver;
	
	
	public static void loadIOSConfigProp(String propertyFileName) throws IOException {
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/properties/" + propertyFileName);
		prop.load(fis);
		IMPLICIT_WAIT = Integer.parseInt(prop.getProperty("implicit.wait"));
		APPIUM_SERVER_PORT = Integer.parseInt(prop.getProperty("appium.server.port"));
		APPLICATION_APP = prop.getProperty("application.app");
		DEVICE_NAME = prop.getProperty("device.name");
		AUTOMATION_XCUITEST = prop.getProperty("AutomationName.IOS_XCUI_TEST");
		BROWSER_NAME = prop.getProperty("browser.name");
		PLATFORM_NAME = prop.getProperty("platform.name");
	}
	
	public static void setIOSCapabilities() {
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,CommonUtils.DEVICE_NAME);                      // settings for running locally
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,CommonUtils.PLATFORM_NAME);           
		capabilities.setCapability(MobileCapabilityType.APP,CommonUtils.APPLICATION_APP);
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, CommonUtils.AUTOMATION_XCUITEST);           
    		//capabilities.setCapability("noReset", "true");
       
		/*capabilities.setCapability("appiumVersion", "1.7.2");                            //settings for sauce labs
		capabilities.setCapability("deviceName","iPhone 8 Simulator");
		capabilities.setCapability("deviceOrientation", "portrait");
		capabilities.setCapability("platformVersion","11.2");
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("browserName", "");
		capabilities.setCapability("app","sauce-storage:grocery_app.zip");*/
	}
	
	public static AppiumDriver getIOSDriver() throws MalformedURLException {
		
		serverURl = new URL("http://0.0.0.0:" + APPIUM_SERVER_PORT + "/wd/hub");
		//driver = new IOSDriver<> (new URL("http://MRAO0212:589ba358-a888-430b-98c7-1858c5edef83@ondemand.saucelabs.com:80/wd/hub"),capabilities);// running  on saucelabs 

		driver = new IOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities); // running locally
		//mustangprodenv=testing;SENV=prodb;$1
		//driver.manage().addCookie(new Cookie("mustangprodenv", "testing"));
		//driver.manage().addCookie(new Cookie("SENV", "prodb"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
		
	}
	
}

