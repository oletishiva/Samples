package com.walmart.grocery.og_smokeTests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.CrowdSourceDeliveryScreen;
import com.walmart.grocery.og_automation_Screen.SignInUserScreenOriginal;
import com.walmart.grocery.og_base.TestBase;

public class Smoke_CrowdSourceDelivery extends TestBase {

	@BeforeTest
	public void init() {
		csd = new CrowdSourceDeliveryScreen(driver);
		sis = new SignInUserScreenOriginal(driver);
	}
	@Test(priority= 1)
	public void IntroductionScreen(){
	sis.localMockServerSetup();
	}
	@Test(priority= 2)
	public void SignInUserTest() throws InterruptedException {
	sis.signInUser();
	}
	@Test (priority = 3)
	public void smokeTestSearchForBeer() throws InterruptedException{
		sis.searchScreen();
		csd.smokeTestSearchBeer();
	}
	@Test (priority = 4)
	public void smokeTestIncreaseDecreaseQuantity() {
		csd.smokeTestIncreaseDecreaseQuantity();
	}
	/*
	@Test (priority = 5)
	public void smokeTestClickOnCart(){
		csd.smokeTestClickOnCart();
	}
	@Test (priority = 6)
	public void smokeTestCheckoutAlcohol() throws InterruptedException{
		csd.smokeTestCheckoutAlcohol();
	}
	@Test (priority = 7)
	public void smokeTestSelectSlot() {
		csd.smokeTestSelectSlot();
	}
	@Test (priority = 8)
	public void smokeTestcheckForCoachScreen() {
		csd.smokeTestcheckForCoachScreen();
	}
	@Test (priority = 9)
	public void checkAlcoholDisclosure(){
		csd.checkAlcoholDisclosure();
	}
	@Test (priority = 10)
	public void checkRadioButtonForBagAndAlochol(){
		csd.checkRadioButtonForBagAndAlochol();
	}
	@Test (priority = 11)
	public void placeOrder() throws InterruptedException{
		csd.placeOrder();
	}
	@Test (priority = 12)
	public void orderConfirmation(){
		csd.orderConfirmation();
	}
	@Test (priority = 13)
	public void cancelThePlacedOrder(){
		csd.cancelThePlacedOrder();;
	}
	@Test (priority = 14)
	public void addAllItemsToCart() throws InterruptedException{
		csd.addAllItemsToCart();
	}
	
	*/
	
}
