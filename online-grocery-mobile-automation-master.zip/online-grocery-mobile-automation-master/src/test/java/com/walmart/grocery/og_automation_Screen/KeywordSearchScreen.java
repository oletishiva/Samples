package com.walmart.grocery.og_automation_Screen;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.springframework.util.SystemPropertyUtils;
import org.testng.Assert;

import com.walmart.grocery.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.ios.IOSElement;

public class KeywordSearchScreen extends ScreenBase {

	public KeywordSearchScreen(AppiumDriver driver) {
		super(driver);
	}
	
	public void SignInUser(){
		SignInUserScreen SignInObj = new SignInUserScreen(driver);
		SignInObj.SignInButton.click();
		SignInObj.Username.sendKeys("smoketestuser@mail.com");
		SignInObj.Password.sendKeys("password");
		SignInObj.SignInButton.click();
		SignInObj.Search.click();
	}
	public void  KeywordSearch() throws InterruptedException {
		KeywordScreenObjects kso = new KeywordScreenObjects(driver);
		kso.Search.sendKeys("apples"+"\n");
		kso.Search.clear();
		kso.Search.sendKeys("banana"+"\n");
		Thread.sleep(2000);

	}
	public void CheckTabbarItems() throws InterruptedException {
	Assert.assertEquals(	driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Home\"]").getText(),"Home", "Found Home button in tabbar");
	Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Favorites\"]").getText(),"Favorites","Found Favourites button in tabbar");
	Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Departments\"]").getText(), "Departments", "Found Departments button in the tabbar");
	//Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Search\"]").getText(), "Search", "Found Search button in tabbar");
	Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").getText(), "Account", "Found Account button in the tabbar");	
	}
	
	
}
