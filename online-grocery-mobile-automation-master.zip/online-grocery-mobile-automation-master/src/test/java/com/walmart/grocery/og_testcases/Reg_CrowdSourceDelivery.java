package com.walmart.grocery.og_testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.CrowdSourceDeliveryScreen;
import com.walmart.grocery.og_base.TestBase;

public class Reg_CrowdSourceDelivery extends TestBase {

	@BeforeTest
	public void init() {
		csd = new CrowdSourceDeliveryScreen(driver);
	}

	@Test (priority = 9)
	public void searchForBeer1() throws InterruptedException{
		csd.searchBeer();
		Thread.sleep(5000);
	}
	@Test (priority = 10)
	public void beerIncreaseDecreaseQuantity () {
		csd.beerIncreaseDecreaseQuantity();
	}
	@Test (priority = 11)
	public void clickOnCart(){
		csd.clickOnCart();
	}
	@Test (priority = 12)
	public void proceedForCheckout() {
		csd.proceedForCheckout();
	}
	@Test (priority = 13)
	public void selectPickupSlot(){
		csd.selectPickupSlot();
	}
	
	@Test (priority = 14)
	public void checkAlcoholDisclosure(){
		csd.checkAlcoholDisclosure();
	}
	@Test (priority = 15)
	public void checkRadioButtonForBagAndAlochol(){
		csd.checkRadioButtonForBagAndAlochol();
	}
	@Test (priority = 16)
	public void placeOrder() throws InterruptedException{
		csd.placeOrder();
	}
	@Test (priority = 17)
	public void orderConfirmation(){
		csd.orderConfirmation();
	}
	
	@Test (priority = 18)
	public void cancelThePlacedOrder(){
		csd.cancelThePlacedOrder();
	}
	
	@Test (priority = 19)
	public void addAllItemsToCart() throws InterruptedException{
		csd.addAllItemsToCart();
	}
}
