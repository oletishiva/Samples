package com.walmart.grocery.og_testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.walmart.grocery.og_automation_Screen.BrowseDepartmentScreen;
import com.walmart.grocery.og_base.TestBase;

public class Reg_BrowseDepartment extends TestBase {

	@BeforeTest
	public void init() {
		bds = new BrowseDepartmentScreen(driver);	
	}
	
	@Test (priority = 8)
	public void departmentCategoriesDisplayed() throws InterruptedException{
		bds.departmentListAvailable();
		Thread.sleep(5000);
		bds.searchScreen();
	}
}
