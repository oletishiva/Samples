package com.walmart.grocery.og_base;

import java.io.IOException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import io.appium.java_client.AppiumDriver;

import com.walmart.grocery.og_automation_Screen.BrowseDepartmentScreen;
import com.walmart.grocery.og_automation_Screen.CrowdSourceDeliveryScreen;
import com.walmart.grocery.og_automation_Screen.KeywordSearchScreen;
import com.walmart.grocery.og_automation_Screen.SignInUserScreenOriginal;
import com.walmart.grocery.og_utils.CommonUtils;

public class TestBase {
	public static AppiumDriver driver;
	public static SignInUserScreenOriginal sis;
	public static KeywordSearchScreen kss;
	public static BrowseDepartmentScreen bds;
	public static CrowdSourceDeliveryScreen csd;
 	public static String loadPropertyFile = "og_walmart.properties";
	
	@BeforeSuite
	public void setup() throws IOException {
		if(driver ==null)
		{
			if(loadPropertyFile.startsWith("og")) {
			CommonUtils.loadIOSConfigProp(loadPropertyFile);
			CommonUtils.setIOSCapabilities();
			driver = CommonUtils.getIOSDriver();
			}
			else if(loadPropertyFile.startsWith("Android")){
				
			}
		}
		
	}
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}
