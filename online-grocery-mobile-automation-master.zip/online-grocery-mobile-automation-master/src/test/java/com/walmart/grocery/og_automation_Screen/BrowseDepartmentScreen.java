package com.walmart.grocery.og_automation_Screen;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.walmart.grocery.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSElement;

public class BrowseDepartmentScreen extends ScreenBase{

	public BrowseDepartmentScreen(AppiumDriver driver) {
		super(driver);
	}

	public void departmentListAvailable() throws InterruptedException {
		System.out.println("I am in the Deapartment Screen");

		List<IOSElement> list = driver.findElementsByClassName("XCUIElementTypeStaticText");
        ArrayList<String> arrl = new ArrayList<String>();
		for (IOSElement st : list) {
			System.out.println(st.getText());
			arrl.add(st.getText());
		}
		assertTrue(arrl.contains("Baby"));
		assertTrue(arrl.contains("Kitchen & Dining"));
		assertTrue(arrl.contains("Pets"));	
		
		
	}		
	//XCUIElementTypeButton[@name="Add Item to Cart"])[1]
	//XCUIElementTypeButton[@name="Add Item to Cart"])[1]
}
