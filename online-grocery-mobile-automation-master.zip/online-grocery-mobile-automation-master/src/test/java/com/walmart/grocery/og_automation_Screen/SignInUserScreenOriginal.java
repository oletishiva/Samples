package com.walmart.grocery.og_automation_Screen;

import java.net.URL;

import org.openqa.selenium.Dimension;
import org.testng.Assert;

import com.walmart.grocery.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSTouchAction;
import io.appium.java_client.remote.MobileCapabilityType;

public class SignInUserScreenOriginal extends ScreenBase {

	public SignInUserScreenOriginal(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void localMockServerSetup() {
		driver.findElementByAccessibilityId("Allow").click();
		driver.findElementByName("NEXT").click();
		driver.findElementByName("NEXT").click();
		driver.findElementByName("NEXT").click();
	}
	
	public void signInUser() throws InterruptedException {
		SignInUserScreen signinObj = new SignInUserScreen(driver);
		System.out.println("starting signin-----------");
		signinObj.SignInButton.click();
		Thread.sleep(4000);
		signinObj.SignInButton.click();
		
		//click the sigIn button
		System.out.println("TESTTING"+ driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter your email address.\"]").getText());
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter your email address.\"]").getText(),
				"Please enter your email address.", "The error is displayed..");
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter your password.\"]").getText(),
				"Please enter your password.", "The error message for password is displayed..");
		
		//enter the user name  error message for password
		signinObj.Username.sendKeys("1234");
		signinObj.SignInButton.click();
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter your password.\"]").getText(),
				"Please enter your password.", "The error message for password is displayed..");
		signinObj.Username.clear();
		
		//entering a invalid email address
		/*signinObj.Username.sendKeys("1234");
		signinObj.Password.sendKeys("password");
		signinObj.SignInButton.click();
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter a valid email address.\"]").getText(),
		"Please enter a valid email address.", "The error message for invalis email displayed..");
		*/
	
		signinObj.Username.clear();
		signinObj.Password.clear();
		signinObj.Username.sendKeys("smoketestuser@mail.com");
		signinObj.Password.sendKeys("password");
		signinObj.SignInButton.click();
		System.out.println("passedd signin-----------");
		
	}
	
	public void signOutUser() {
		System.out.println("starting signout-----------");
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").click();
		driver.findElementByAccessibilityId("Sign out").click();
		driver.findElementByAccessibilityId("Continue").click();
		System.out.println("passed signout-----------");
	}
}
