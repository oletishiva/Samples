package com.wmg.automation.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.wmg.automation.pages.HomeScreen;
import com.wmg.automation.pages.SignInUserScreenOriginal;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import com.wmg.automation.og_base.TestBase;;

public class Reg_SignInExistingUser extends TestBase{
	@BeforeTest
	public void init() {
		sis = new SignInUserScreenOriginal(driver);
	//	hs=new HomeScreen(driver);
	}
	@Test(priority= 1)
	public void IntroductionScreen(){
	sis.localMockServerSetup();
	}
	@Test(priority= 2)
	public void SignInUserTest() throws InterruptedException{
		sis.signInUser();
	}
	@Test(priority=3)
	public void toolBarButtonsDisplayed() {
	sis.verifyAreWeInHomePage();
	}
	@Test(priority=4)
	public void SignOutUserTest() {
		//sis.signOutUser();
	}
	
}
