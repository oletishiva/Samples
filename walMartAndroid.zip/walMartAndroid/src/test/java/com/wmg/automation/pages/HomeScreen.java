package com.wmg.automation.pages;


import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.condition.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.wmg.automation.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomeScreen  extends ScreenBase{
	
	
	@AndroidFindBy(xpath ="//android.widget.ImageButton[@content-desc='Open navigation drawer']")
	MobileElement navDrawer;
	private AppiumDriver driver;
	
	public HomeScreen(AppiumDriver driver) {
		super(driver);
		 PageFactory.initElements(new AppiumFieldDecorator(driver, 30, TimeUnit.SECONDS), this);
	}
	
	public WebElement getnavDrawer() {
		return navDrawer;
		
	} 
	
	public void menuBarItemsDisplayed(){
		{
			waitForVisibilityOf(By.xpath("//android.widget.ImageButton[@content-desc='Open navigation drawer']"));
			getnavDrawer().click();
		}
	}
	
	 protected void waitForVisibilityOf(By loc) {
	       WebDriverWait wait = new WebDriverWait(driver, 60);
	       
	       wait.until(ExpectedConditions.visibilityOfElementLocated(loc));
	    		
	        
	    }
}
