package com.wmg.automation.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class CommonUtils {

	public static int IMPLICIT_WAIT;
	public static int APPIUM_SERVER_PORT;
	public static String APPLICATION_APP;
	public static String UDID;
	public static String AUTOMATION_ANDROIDTEST;
	public static String BROWSER_NAME;
	public static String PLATFORM_NAME;
	public static String DEVICE_NAME;
	public static String PLATFORM_VERSION;
	public static Properties prop = new Properties();
	public static DesiredCapabilities capabilities = new DesiredCapabilities();
	public static URL serverURl;
	public static AndroidDriver<?> driver;
	public static  String APPPACKAGE ;
	public static  String APPACTIVITY ;
	
	
	public static void loadAndroidConfigProp(String propertyFileName) throws IOException {
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/properties/" + propertyFileName);
		prop.load(fis);
		IMPLICIT_WAIT = Integer.parseInt(prop.getProperty("implicit.wait"));
		APPIUM_SERVER_PORT = Integer.parseInt(prop.getProperty("appium.server.port"));
		APPLICATION_APP = prop.getProperty("application.app");
		DEVICE_NAME = prop.getProperty("device.name");
		AUTOMATION_ANDROIDTEST = prop.getProperty("AutomationName.AndroidName");
		BROWSER_NAME = prop.getProperty("browser.name");
		PLATFORM_NAME = prop.getProperty("platform.name");
		APPPACKAGE=prop.getProperty("Android.appPackage");
		APPACTIVITY=prop.getProperty("Android.appActivity");
	}
	
	public static void setAndroidCapabilities() {
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,CommonUtils.DEVICE_NAME);                      // settings for running locally
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,CommonUtils.PLATFORM_NAME);           
		//capabilities.setCapability(MobileCapabilityType.APP,CommonUtils.APPLICATION_APP);
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, CommonUtils.AUTOMATION_ANDROIDTEST);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, CommonUtils.APPPACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, CommonUtils.APPACTIVITY);
    		//capabilities.setCapability("noReset", "true");
       
		/*capabilities.setCapability("appiumVersion", "1.7.2");                            //settings for sauce labs
		capabilities.setCapability("deviceName","iPhone 8 Simulator");
		capabilities.setCapability("deviceOrientation", "portrait");
		capabilities.setCapability("platformVersion","11.2");
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("browserName", "");
		capabilities.setCapability("app","sauce-storage:grocery_app.zip");*/
	}
	
	public static AppiumDriver<?> getAndroidDriver() throws MalformedURLException {
		
		serverURl = new URL("http://0.0.0.0:" + APPIUM_SERVER_PORT + "/wd/hub");
		//driver = new IOSDriver<> (new URL("http://MRAO0212:589ba358-a888-430b-98c7-1858c5edef83@ondemand.saucelabs.com:80/wd/hub"),capabilities);// running  on saucelabs 

		driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities); // running locally
		//mustangprodenv=testing;SENV=prodb;$1
		//driver.manage().addCookie(new Cookie("mustangprodenv", "testing"));
		//driver.manage().addCookie(new Cookie("SENV", "prodb"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
		
	}
	
}

