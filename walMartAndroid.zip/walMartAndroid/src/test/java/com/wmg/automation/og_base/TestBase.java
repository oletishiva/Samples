package com.wmg.automation.og_base;

import java.io.IOException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.wmg.automation.pages.HomeScreen;
import com.wmg.automation.pages.SignInUserScreenOriginal;
import com.wmg.automation.utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;




public class TestBase {
	public static AppiumDriver driver;
	public static SignInUserScreenOriginal sis;
	public static HomeScreen hs;
	
 	public static String loadPropertyFile = "android_walmart.properties";
	
	@BeforeSuite
	public void setup() throws IOException {
		if(driver ==null)
		{
			if(loadPropertyFile.startsWith("android")) {
			CommonUtils.loadAndroidConfigProp(loadPropertyFile);
			CommonUtils.setAndroidCapabilities();
			driver =  CommonUtils.getAndroidDriver();
			}
			
		}
		
	}
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}
