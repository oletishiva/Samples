package com.wmg.automation.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.wmg.automation.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AndroidFindBys;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SignInUserScreenOriginal extends ScreenBase {
	
	By btnNext=By.xpath("//*[@text='NEXT']");
	

	@FindBys( {
		   @FindBy(id ="com.walmart.grocery:id/textinput_error")
		   
		} )
	private List<MobileElement> inpurErrorTxt;
	
	
	
	
	public SignInUserScreenOriginal(AppiumDriver driver) {
		super(driver);
		 PageFactory.initElements(new AppiumFieldDecorator(driver, 30, TimeUnit.SECONDS), this);
	}

	public static SignInUserScreen signinObj;
	public void localMockServerSetup() {
	//	driver.findElementByAccessibilityId("Allow").click();
		driver.findElement(btnNext).click();
		driver.findElement(btnNext).click();
		driver.findElement(btnNext).click();
	}
	
	public void signInUser() throws InterruptedException {
		signinObj = new SignInUserScreen((AndroidDriver) driver);
		System.out.println("starting signin-----------");
		//signinObj.clickSignInButton();
		signinObj.getSignInButton().click();
		Thread.sleep(4000);
		signinObj.getSignInButton().click();
		Thread.sleep(4000);
		signinObj.getSignInButton().click();
		
		//click the sigIn button
		System.err.println(inpurErrorTxt.get(0).getText());
		Assert.assertEquals(inpurErrorTxt.get(0).getText(),
				"Please enter your email address", "The error is displayed..");
		
		
		
		//enter the user name  error message for password
		signinObj.getUsername().sendKeys("smoketestuser@mail.com");
	//	signinObj.getPassword().click();
		signinObj.getSignInButton().click();
		Assert.assertEquals(inpurErrorTxt.get(0).getText(),
				"Please enter a password", "The error message for password is displayed..");
		signinObj.getUsername().clear();
		
		//entering a invalid email address
		/*signinObj.Username.sendKeys("1234");
		signinObj.Password.sendKeys("password");
		signinObj.SignInButton.click();
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter a valid email address.\"]").getText(),
		"Please enter a valid email address.", "The error message for invalis email displayed..");
		*/
	
		Thread.sleep(4000);
		signinObj.getUsername().sendKeys("smoketestuser@mail.com");
		driver.hideKeyboard();
		signinObj.getPassword().click();
		signinObj.getPassword().sendKeys("password");
		Thread.sleep(4000);
		driver.hideKeyboard();
		Thread.sleep(4000);
		System.err.println(signinObj.getSignInButton().isDisplayed());
		//signinObj.getSignInButton().wait(2000);
		signinObj.getSignInButton().click();
		//signinObj.getSignInButton().click();
		
		System.out.println("passedd signin-----------");
		
	}
	
	public void verifyAreWeInHomePage()
	{
		
		signinObj.menuBarItemsDisplayed();
	}
	public void signOutUser() {
		System.out.println("starting signout-----------");
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").click();
		driver.findElementByAccessibilityId("Sign out").click();
		driver.findElementByAccessibilityId("Continue").click();
		System.out.println("passed signout-----------");
	}
	
	
}
