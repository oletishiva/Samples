package com.wmg.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SignInUserScreen {
	private AndroidDriver driver;		
	
	@AndroidFindBy(xpath ="//*[@text='SIGN IN' or @text='Sign In']")
	MobileElement SignInButton1;
	@FindBy( xpath ="//*[@id='sign_in_email_field']" )
	WebElement Username;
	@FindBy( xpath ="//*[@id='sign_in_password_field']" )
	WebElement Password;
	@FindBy(name = "Search")
	WebElement Search;
	
	public SignInUserScreen(AndroidDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(new AppiumFieldDecorator(driver, 30, TimeUnit.SECONDS), this);
	}
	
	By SignInButton=By.xpath("//*[@text='SIGN IN' or @text='Sign In']");
	By userName=By.xpath("//*[@id='sign_in_password_field']");
	By passWord=By.xpath("//*[@id='sign_in_password_field']");
	
	public WebElement getSignInButton() {
		return driver.findElement(SignInButton);
		
	}
	public WebElement getUsername() {
	//	return Username;
		return driver.findElement(userName);
	}
	public WebElement getPassword() {
		//return Password;
		
		return driver.findElement(passWord);
	}
	
	public void clickSignInButton() {
		driver.findElement(SignInButton).click();;
		
	}
	
	public WebElement getSignInButton1() {
		return SignInButton1;
		
	}

}
