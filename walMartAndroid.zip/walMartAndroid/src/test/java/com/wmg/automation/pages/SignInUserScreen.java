package com.wmg.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SignInUserScreen {
	private AndroidDriver driver;		

	@AndroidFindBy(xpath ="//*[@text='SIGN IN' or @text='Sign In']")
	MobileElement SignInButton;
	@AndroidFindBy( id ="com.walmart.grocery:id/sign_in_email_field" )
	MobileElement userName;
	@AndroidFindBy( id ="com.walmart.grocery:id/sign_in_password_field" )
	MobileElement passWord;
	
	@AndroidFindBy(xpath ="//android.widget.ImageButton[@content-desc='Open navigation drawer']")
	MobileElement navDrawer;
	
	public SignInUserScreen(AndroidDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(new AppiumFieldDecorator(driver, 30, TimeUnit.SECONDS), this);
	}
	
	
	
	public WebElement getSignInButton() {
		return SignInButton;
		
	}
	public WebElement getUsername() {
	//	return Username;
		return userName;
	}
	public WebElement getPassword() {
		//return Password;
		
		return passWord;
	}
	
	public WebElement getnavDrawer() {
		return navDrawer;
		
	} 
	
	public void menuBarItemsDisplayed(){
		{
			waitForVisibilityOf(By.xpath("//android.widget.ImageButton[@content-desc='Open navigation drawer']"));
			getnavDrawer().click();
		}
	}
	
	 protected void waitForVisibilityOf(By loc) {
	       WebDriverWait wait = new WebDriverWait(driver, 60);
	       
	       wait.until(ExpectedConditions.visibilityOfElementLocated(loc));
	    		
	        
	    }
}
