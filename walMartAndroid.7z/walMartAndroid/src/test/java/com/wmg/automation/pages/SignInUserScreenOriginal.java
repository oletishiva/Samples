package com.wmg.automation.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wmg.automation.og_base.ScreenBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SignInUserScreenOriginal extends ScreenBase {
	
	By btnNext=By.xpath("//*[@text='NEXT']");
	
	public SignInUserScreenOriginal(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	public void localMockServerSetup() {
	//	driver.findElementByAccessibilityId("Allow").click();
		driver.findElement(btnNext).click();
		driver.findElement(btnNext).click();
		driver.findElement(btnNext).click();
	}
	
	public void signInUser() throws InterruptedException {
		SignInUserScreen signinObj = new SignInUserScreen(driver);
		System.out.println("starting signin-----------");
		signinObj.clickSignInButton();
		Thread.sleep(4000);
		signinObj.clickSignInButton();
		signinObj.getSignInButton().click();
		
		//click the sigIn button
		System.out.println("TESTTING"+ driver.findElementByXPath("(//*[@id='textinput_error'])[1]").getText());
		Assert.assertEquals(driver.findElementByXPath("(//*[@id='textinput_error'])[1]").getText(),
				"Please enter your email address.", "The error is displayed..");
		
		//enter the user name  error message for password
		signinObj.getUsername().sendKeys("hello@1234@");
		driver.hideKeyboard();
		signinObj.getSignInButton().click();
		Assert.assertEquals(driver.findElementByXPath("(//*[@id='textinput_error'])[2]").getText(),
				"Please enter a password", "The error message for password is displayed..");
		signinObj.getUsername().clear();
		
		//entering a invalid email address
		/*signinObj.Username.sendKeys("1234");
		signinObj.Password.sendKeys("password");
		signinObj.SignInButton.click();
		Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeStaticText[@name=\"Please enter a valid email address.\"]").getText(),
		"Please enter a valid email address.", "The error message for invalis email displayed..");
		*/
	
		signinObj.getUsername().clear();
		signinObj.getPassword().clear();
		signinObj.getUsername().sendKeys("smoketestuser@mail.com");
		signinObj.getPassword().sendKeys("password");
		signinObj.getSignInButton().click();
		System.out.println("passedd signin-----------");
		
	}
	
	public void signOutUser() {
		System.out.println("starting signout-----------");
		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").click();
		driver.findElementByAccessibilityId("Sign out").click();
		driver.findElementByAccessibilityId("Continue").click();
		System.out.println("passed signout-----------");
	}
}
