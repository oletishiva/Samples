package com.wmg.automation.og_base;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

	public class ScreenBase {
		public static AppiumDriver driver;
		
		public ScreenBase(AppiumDriver  driver) {
			this.driver =  driver;
		}
		public void toolBarButtonsDisplayed(){	
			//Assert.assertEquals(	driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Home\"]").getText(),"Home", "Found Home button in tabbar");
			Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Favorites\"]").getText(),"Favorites","Found Favourites button in tabbar");
			Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Departments\"]").getText(), "Departments", "Found Departments button in the tabbar");
			Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Search\"]").getText(), "Search", "Found Search button in tabbar");
			Assert.assertEquals(driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").getText(), "Account", "Found Account button in the tabbar");
		}
		public void homeScreen() {
			driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Home\"]").click();
		}
		public void favoritesScreen() {
			driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Favorites\"]").click();
		}
		public void searchScreen() {
			driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Search\"]").click();
		}
		public void departmentsScreen() {
			driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Departments\"]").click();
		}
		public void accountScreen() {
			driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Account\"]").click();
		}
		public void hideKeyboard(){
			driver.hideKeyboard();
		}
}
