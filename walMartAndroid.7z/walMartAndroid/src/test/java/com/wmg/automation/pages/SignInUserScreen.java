package com.wmg.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInUserScreen {
	WebDriver driver;		
	
	/*@FindBy(xpath ="//*[@text='SIGN IN' or @text='Sign In']")
	WebElement SignInButton;
	@FindBy( xpath ="//*[@id='sign_in_email_field']" )
	WebElement Username;
	@FindBy( xpath ="//*[@id='sign_in_password_field']" )
	WebElement Password;
	@FindBy(name = "Search")
	WebElement Search;*/
	
	public SignInUserScreen(WebDriver driver) {
		this.driver = driver;
	//	PageFactory.initElements(driver, this);
	}
	
	By SignInButton=By.xpath("//*[@text='SIGN IN' or @text='Sign In']");
	By userName=By.xpath("//*[@id='sign_in_password_field']");
	By passWord=By.xpath("//*[@id='sign_in_password_field']");
	
	public WebElement getSignInButton() {
		return driver.findElement(SignInButton);
		
	}
	public WebElement getUsername() {
	//	return Username;
		return driver.findElement(userName);
	}
	public WebElement getPassword() {
		//return Password;
		
		return driver.findElement(passWord);
	}
	
	public void clickSignInButton() {
		driver.findElement(SignInButton).click();;
		
	}

}
